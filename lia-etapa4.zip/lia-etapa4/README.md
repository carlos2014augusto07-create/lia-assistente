# Lia — Etapa 4: pronta para o GitHub Actions

Novidades desta etapa
1. **Voz mais natural** (pt-BR): escolhe a melhor voz instalada, fala frase por frase e corrige "Wi-Fi", "TV" e "ESP32".
2. **50 s de inatividade** depois de cada interação (vídeo tocando: a Lia some; menus: fica só a bolinha no canto).
3. **Modo escola / pausa**: por voz ("Lia, descansar"), pelo botão rápido, ou pela notificação. Desliga o microfone e esconde a bolinha na hora.
4. **Workflow do GitHub Actions** que gera os dois APKs (`app-debug.apk` do celular e `tv-debug.apk` da Aiwa).

```
lia-etapa4/
├── app/                       app do CELULAR (com.lia.assistant)
├── tv/                        app da AIWA TV (com.lia.tv)
├── esp32/lia_esp32/           firmware do ESP32
├── tools/fake_tv.py           TV de mentira para testes
├── .github/workflows/build-apk.yml           build (projeto completo no repositório)
└── github-modo-celular/build-from-zip.yml    build a partir do ZIP (só pelo celular)
```

> **Ainda não foi compilado** (não existe Android SDK onde eu trabalho). Se o primeiro build no GitHub falhar, abra o log da etapa
> "Compilar", copie as linhas com `e:` (erros do Kotlin) ou `FAILED` e me mande: corrijo na hora.

## Gerar o APK no GitHub

### Modo celular (só com o navegador do celular)
1. Crie uma conta e um repositório **privado** em github.com (ex.: `lia`).
2. **Add file → Upload files** e envie o `lia-etapa4.zip` *sem extrair*. (Opcional: envie também o `lia_android.ppn`.)
3. **Add file → Create new file**. No nome digite `.github/workflows/build-from-zip.yml` e cole o conteúdo de `github-modo-celular/build-from-zip.yml`. Salve (commit).
4. Aba **Actions** → "Build APKs (a partir do ZIP)" → **Run workflow**. Leva uns 5 a 10 minutos.
5. Abra o build concluído → **Artifacts → lia-apks** → baixe, extraia e você terá `app-debug.apk` e `tv-debug.apk`.

### Modo computador
Extraia o ZIP e envie **tudo** para o repositório (a pasta `.github` precisa ir junto). O build roda sozinho a cada envio.
Não use os dois modos no mesmo repositório.

### Segredos (opcional, em Settings → Secrets and variables → Actions)
`LIA_TOKEN` (igual no firmware do ESP32), `LIA_PICOVOICE_KEY`, `LIA_TV_HOST`, `LIA_ESP_HOST`, `LIA_TTS_VOICE`.
Se não criar nenhum, vale o padrão do `gradle.properties` (token `troque-este-token`; funciona, mas troque).
O arquivo `lia_android.ppn` (palavra "Lia") vai na **raiz do repositório**; o workflow o coloca dentro do app.

### Instalar
- **Celular:** abra o `app-debug.apk` e permita "instalar de fontes desconhecidas". Abra o app uma vez e aceite microfone e notificações.
- **TV:** instale o `tv-debug.apk` por pendrive, por um app de arquivos na TV, ou `adb install tv-debug.apk`.
  Abra **Lia TV** e libere sobreposição e acesso a notificações (ou use os comandos `adb` que aparecem na própria tela).
- Celular e TV no mesmo Wi-Fi. O resto (token, descoberta da TV, ESP32) está no README da Etapa 3, que continua valendo.

## 1. Voz mais natural
- O app escolhe a melhor voz pt-BR: dá preferência às vozes de rede do Google quando há internet, e às locais quando não há.
- **O que mais melhora:** Configurações do Android → Idioma → Saída de texto para voz → motor **Google** → Instalar dados de voz → Português (Brasil) → baixar a voz de alta qualidade e escolher a variante que preferir.
- Os nomes das vozes aparecem no Logcat (filtro `Lia`: "Vozes pt-BR disponíveis…"). Para fixar uma: `LIA_TTS_VOICE=<nome>`.
- Ritmo e tom: `setSpeechRate(0.95f)` e `setPitch(1.0f)` em `voice/Speaker.kt`.
- Limite: o app usa a voz do sistema. Não existe voz "humana" garantida; a qualidade final depende das vozes instaladas no seu celular.

## 2. Inatividade de 50 segundos (na TV)
A contagem começa quando a interação termina e reinicia se você falar de novo.
| Situação na TV | Depois de 50 s sem voz |
|---|---|
| Vídeo tocando | a Lia some por completo |
| Menus / nada tocando | o painel recolhe e fica só a **bolinha discreta** no canto superior direito |
- A bolinha de repouso só aparece depois da primeira fala (ou ao acordar). Se um vídeo começar com a bolinha na tela, ela some; se o vídeo acabar, ela volta.
- Para mudar o tempo: `IDLE_TIMEOUT_MS` no topo de `tv/.../LiaTvService.kt`.
- Teste sem TV: `FAKE_REST=5 python3 tools/fake_tv.py` usa 5 s no lugar de 50 s.

## 3. Modo escola / pausa
Desliga o microfone e esconde a bolinha da TV na hora.
- **Voz:** "Lia, descansar" (também funciona "modo escola", "desativar", "dormir", "tchau").
- **Notificação:** botão **Descansar** (e **Acordar** quando pausada).
- **Botão rápido:** puxe a barra superior → editar (lápis) → arraste o bloco **Lia**. Um toque pausa ou acorda.
- **Acordar:** pelo botão rápido, pela notificação (toque ou "Acordar") ou abrindo o app. **Não dá para acordar por voz**, porque o microfone está desligado de propósito.
- O estado de descanso é lembrado mesmo se o celular reiniciar o serviço. O serviço fica vivo (sem ouvir nada) para o botão rápido acordar a Lia sem abrir o app; o consumo é mínimo. "Parar" na notificação encerra o serviço de vez.
- Se o celular estiver sem Wi-Fi ao pausar, o aviso à TV não chega; a bolinha some sozinha pelo temporizador (ou no vídeo).

## Limites que continuam valendo
Ícone verde de microfone enquanto escuta; depois de reiniciar o celular, abra o app uma vez; reconhecimento de fala pelo serviço do Android/Google;
sobreposição na TV pode exigir `adb`; segurança por token em rede doméstica. Detalhes na Etapa 3.
