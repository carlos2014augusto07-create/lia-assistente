package com.lia.assistant

import com.lia.assistant.esp.Esp32Manager
import com.lia.assistant.net.TvMode
import com.lia.assistant.tv.TvManager

/** [sleep] = depois de falar, a Lia entra em descanso (microfone desligado, bolinha some). */
data class Reply(val text: String, val sleep: Boolean = false)

/** Recebe o texto do comando e decide o que a Lia vai falar e fazer. */
class CommandRouter(private val tv: TvManager, private val esp: Esp32Manager) {

    suspend fun handle(raw: String): Reply {
        val t = normalize(raw)

        // Modo escola / pausa: "Lia, descansar", "modo escola", "desativar", "tchau"...
        if (SLEEP_WORDS.any { it in t }) return Reply("Tá bom, até logo!", sleep = true)

        val app = APPS.firstOrNull { it.first in t }
        val text = when {
            "abrir" in t && app != null -> {
                tv.openApp(app.first)
                "Abrindo ${app.second} na TV."
            }
            "automatico" in t -> { tv.setMode(TvMode.AUTO); "Modo automático ligado." }
            "tela cheia" in t -> { tv.setMode(TvMode.FULLSCREEN); "Tela cheia." }
            "canto" in t || "discreto" in t -> { tv.setMode(TvMode.CORNER_BUBBLE); "Modo discreto no canto." }
            "status" in t -> tv.status()
            else -> esp.handle(t) ?: "Ainda não sei fazer isso."
        }
        return Reply(text)
    }

    private companion object {
        val SLEEP_WORDS = listOf("descans", "modo escola", "desativ", "dormir", "tchau", "ate logo")

        // chave enviada à TV → como a Lia fala
        val APPS = listOf(
            "youtube" to "o YouTube",
            "netflix" to "a Netflix",
            "prime" to "o Prime Video"
        )
    }
}
