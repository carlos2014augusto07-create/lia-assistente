package com.lia.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/**
 * Activity sem interface: pede as permissões, liga o serviço e se fecha.
 * No Android 14+ o serviço de microfone só pode nascer com o app visível.
 * Abrir o app também acorda a Lia, se ela estiver descansando.
 */
class MainActivity : ComponentActivity() {

    private val askPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.RECORD_AUDIO] == true) {
                startLia()
            } else {
                Toast.makeText(this, "A Lia precisa do microfone para ouvir.", Toast.LENGTH_LONG).show()
            }
            finish()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val missing = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT >= 37) add("android.permission.ACCESS_LOCAL_NETWORK")
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }

        if (missing.isEmpty()) {
            startLia()
            finish()
        } else {
            askPermissions.launch(missing.toTypedArray())
        }
    }

    private fun startLia() {
        // RESUME: abrir o app (ou tocar na notificação) também tira a Lia do descanso.
        ContextCompat.startForegroundService(
            this, Intent(this, LiaService::class.java).setAction(LiaService.ACTION_RESUME)
        )
    }
}
