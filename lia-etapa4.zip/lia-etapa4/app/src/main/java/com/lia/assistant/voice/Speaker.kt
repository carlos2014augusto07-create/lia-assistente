package com.lia.assistant.voice

import android.content.Context
import android.media.AudioAttributes
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.lia.assistant.BuildConfig
import java.util.Locale

private const val TAG = "Lia"

/**
 * A Lia falando pelo alto-falante do CELULAR (nunca pela TV: assim não pede foco de áudio nela).
 *
 * Por que soa menos robótica:
 *  1. escolhe sozinha a melhor voz pt-BR instalada (vozes de rede do Google, quando há internet, são as mais naturais);
 *  2. fala frase por frase, com uma pausa curta entre elas, como uma pessoa;
 *  3. ritmo um pouco mais calmo e canal de áudio de "assistente";
 *  4. corrige palavras que o motor lê mal (Wi-Fi, TV, ESP32).
 * Para fixar uma voz específica, veja o nome no Logcat (filtro "Lia") e ponha em LIA_TTS_VOICE.
 */
class Speaker(ctx: Context) {

    private val appCtx = ctx.applicationContext
    private lateinit var tts: TextToSpeech
    @Volatile private var ready = false
    @Volatile private var failed = false
    private var pending: Pair<String, () -> Unit>? = null
    @Volatile private var finalId: String? = null
    @Volatile private var onFinished: (() -> Unit)? = null
    private var counter = 0

    init {
        tts = TextToSpeech(appCtx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                configure()
                ready = true
            } else {
                Log.w(TAG, "Voz do Android (TTS) indisponível")
                failed = true
            }
            pending?.let { (text, done) ->
                pending = null
                speak(text, done)
            }
        }
    }

    private fun configure() {
        tts.language = Locale.forLanguageTag("pt-BR")
        tts.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        tts.setSpeechRate(0.95f)
        tts.setPitch(1.0f)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { finish(utteranceId, force = false) }

            @Deprecated("Exigido pela API antiga", ReplaceWith("onError(utteranceId, -1)"))
            override fun onError(utteranceId: String?) { finish(utteranceId, force = true) }
        })
        val names = brVoices().joinToString { "${it.name} (q=${it.quality}${if (it.isNetworkConnectionRequired) ", rede" else ""})" }
        Log.d(TAG, "Vozes pt-BR disponíveis: $names")
    }

    private fun finish(id: String?, force: Boolean) {
        if (force || id == finalId) {
            val cb = onFinished
            onFinished = null
            finalId = null
            cb?.invoke()
        }
    }

    private fun isOnline(): Boolean {
        val cm = appCtx.getSystemService(ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun brVoices(): List<Voice> =
        (runCatching { tts.voices }.getOrNull() ?: emptySet<Voice>())
            .filter { it.locale?.language == "pt" && it.locale?.country.equals("BR", ignoreCase = true) }
            .filter { it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true }

    private fun pickVoice(): Voice? {
        val online = isOnline()
        val candidates = brVoices().filter { online || !it.isNetworkConnectionRequired }
        val wanted = BuildConfig.LIA_TTS_VOICE
        return candidates.firstOrNull { wanted.isNotBlank() && it.name == wanted }
            ?: candidates.maxByOrNull { it.quality + if (it.isNetworkConnectionRequired) 100 else 0 }
    }

    /** [done] é chamado quando terminar de falar (ou se não for possível falar). */
    fun speak(text: String, done: () -> Unit) {
        if (failed) { done(); return }
        if (!ready) { pending = text to done; return }

        pickVoice()?.let { runCatching { tts.voice = it } }

        val sentences = Pronunciation.fix(text)
            .split(Regex("(?<=[.!?…])\\s+"))
            .filter { it.isNotBlank() }
        if (sentences.isEmpty()) { done(); return }

        val id = "lia-${++counter}"
        finalId = "$id-fim"
        onFinished = done

        sentences.forEachIndexed { i, sentence ->
            val last = i == sentences.lastIndex
            val queue = if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            val result = tts.speak(sentence, queue, null, if (last) "$id-fim" else "$id-$i")
            if (result != TextToSpeech.SUCCESS) { finish(null, force = true); return }
            if (!last) tts.playSilentUtterance(140, TextToSpeech.QUEUE_ADD, "$id-p$i")
        }
    }

    /** Corta a fala na hora (usado ao pausar a Lia). Não chama o "done". */
    fun stop() {
        onFinished = null
        finalId = null
        runCatching { tts.stop() }
    }

    fun shutdown() {
        stop()
        runCatching { tts.shutdown() }
    }
}

/** Palavras que os motores de voz em português costumam ler errado. */
private object Pronunciation {
    private val FIXES = listOf(
        Regex("wi-?fi", RegexOption.IGNORE_CASE) to "uai-fai",
        Regex("\\bTV\\b") to "tevê",
        Regex("ESP32", RegexOption.IGNORE_CASE) to "ésse pê trinta e dois",
        Regex("youtube", RegexOption.IGNORE_CASE) to "iutúbi"
    )

    fun fix(text: String): String = FIXES.fold(text) { acc, (rx, to) -> rx.replace(acc, to) }
}
