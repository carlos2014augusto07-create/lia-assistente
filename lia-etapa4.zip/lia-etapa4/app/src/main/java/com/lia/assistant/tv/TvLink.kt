package com.lia.assistant.tv

import android.util.Log
import com.lia.assistant.net.TvCommand
import com.lia.assistant.net.toJson
import kotlinx.coroutines.delay

/** Canal até a TV. Versão real: TvSocketLink. Versão de teste: FakeTvLink. */
interface TvLink {
    suspend fun send(command: TvCommand): Boolean
    fun close() {}
}

/** Só escreve no Logcat. Útil para testar o celular sem TV. */
class FakeTvLink : TvLink {
    override suspend fun send(command: TvCommand): Boolean {
        Log.d("Lia", "→ TV (simulado): ${command.toJson()}")
        delay(50)
        return true
    }
}
