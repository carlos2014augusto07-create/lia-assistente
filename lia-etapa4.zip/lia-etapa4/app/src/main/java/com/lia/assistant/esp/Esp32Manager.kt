package com.lia.assistant.esp

import android.os.SystemClock
import com.lia.assistant.net.Esp32Link
import com.lia.assistant.normalize

/**
 * Entende frases como "liga a luz" / "desliga o ventilador".
 * Os nomes dos dispositivos vêm do próprio ESP32 (/status), então ao
 * adicionar um dispositivo no firmware não é preciso mexer no app.
 */
class Esp32Manager(private val link: Esp32Link) {

    private var cache: Map<String, Boolean>? = null
    private var cachedAt = 0L

    /** Recebe o texto já normalizado. Devolve a resposta falada, ou null se não for comando do ESP32. */
    suspend fun handle(text: String): String? {
        val words = text.split(Regex("[^a-z0-9]+")).toSet()
        val off = words.any { it in OFF_WORDS }
        val on = !off && words.any { it in ON_WORDS }
        if (!off && !on) return null

        val devices = devices() ?: return "Não consegui falar com o ESP32."
        val name = devices.keys.firstOrNull { normalize(it) in text } ?: return null

        val ok = link.set(name, on)
        cache = null
        return if (ok) "Pronto, ${if (on) "liguei" else "desliguei"} o dispositivo $name."
        else "O ESP32 não respondeu."
    }

    private suspend fun devices(): Map<String, Boolean>? {
        val now = SystemClock.elapsedRealtime()
        cache?.let { if (now - cachedAt < 30_000) return it }
        return link.devices()?.also { cache = it; cachedAt = now }
    }

    private companion object {
        // Palavras inteiras: "desligar" não pode ser confundido com "ligar".
        val ON_WORDS = setOf("liga", "ligar", "ligue", "acende", "acender", "acenda")
        val OFF_WORDS = setOf("desliga", "desligar", "desligue", "apaga", "apagar", "apague")
    }
}
