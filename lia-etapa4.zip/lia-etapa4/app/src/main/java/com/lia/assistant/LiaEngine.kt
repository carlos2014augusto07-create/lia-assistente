package com.lia.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.lia.assistant.LiaLog as Log
import com.lia.assistant.esp.Esp32Manager
import com.lia.assistant.net.ESP_SERVICE_TYPE
import com.lia.assistant.net.Esp32Link
import com.lia.assistant.net.LanDiscovery
import com.lia.assistant.net.LiaState
import com.lia.assistant.net.TV_SERVICE_TYPE
import com.lia.assistant.net.TvSocketLink
import com.lia.assistant.tv.TvManager
import com.lia.assistant.voice.CommandListener
import com.lia.assistant.voice.Speaker
import com.lia.assistant.wake.WakeWordEngine
import com.lia.assistant.wake.WakeWordFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

private const val TAG = "Lia"
private const val SESSION_TIMEOUT_MS = 25_000L

/**
 * Fluxo de uma interação:
 *   escutando "Lia" → (libera o microfone) → escuta a frase → decide → mostra na TV + fala no celular
 *   → volta a escutar "Lia".
 *
 * Modo escola / pausa: pause() desliga o microfone e esconde a Lia da TV na hora.
 * O serviço continua vivo (para o botão rápido conseguir acordar a Lia sem abrir o app),
 * mas sem ouvir nada: consumo praticamente zero.
 *
 * Tudo que mexe em microfone roda na thread principal; a rede roda numa fila única,
 * para as mensagens chegarem à TV na ordem certa.
 */
class LiaEngine(
    private val ctx: Context,
    private val onPausedChanged: (Boolean) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default.limitedParallelism(1))
    private val discovery = LanDiscovery(ctx)

    private lateinit var tv: TvManager
    private lateinit var router: CommandRouter
    private val listener = CommandListener(ctx)
    private val speaker = Speaker(ctx)
    private var wake: WakeWordEngine? = null
    private var busy = false

    @Volatile var paused: Boolean = LiaPrefs.isPaused(ctx)
        private set

    private val watchdog = Runnable {
        Log.w(TAG, "Interação demorou demais: reiniciando a escuta")
        end()
    }

    init {
        val tvLink = TvSocketLink(
            findHost = { force -> discovery.find(TV_SERVICE_TYPE, BuildConfig.LIA_TV_HOST, "tv", force) },
            token = BuildConfig.LIA_TOKEN
        ) { event -> tv.onEvent(event) }
        tv = TvManager(ctx, tvLink)

        val espLink = Esp32Link(
            findHost = { force -> discovery.find(ESP_SERVICE_TYPE, BuildConfig.LIA_ESP_HOST, "esp", force) },
            token = BuildConfig.LIA_TOKEN
        )
        router = CommandRouter(tv, Esp32Manager(espLink))
    }

    /** Thread principal. */
    fun start() {
        if (wake == null) wake = WakeWordFactory.create(ctx) { onWake() }
        if (paused) Log.d(TAG, "Iniciada em descanso: microfone desligado") else wake?.start()
    }

    /** Pode ser chamado de qualquer thread (o Porcupine chama da thread dele). */
    fun onWake() { main.post { if (!busy && !paused) begin(null) } }

    /** Executa um comando sem passar pela voz (testes por adb). */
    fun runText(text: String) { main.post { if (!busy && !paused) begin(text) } }

    // ----- modo escola / pausa -----

    fun pause() { main.post { doPause(null) } }
    fun resume() { main.post { doResume() } }
    fun togglePause() { main.post { if (paused) doResume() else doPause(null) } }

    /** Thread principal. [goodbye] = frase falada depois de já ter calado o microfone. */
    private fun doPause(goodbye: String?) {
        if (paused && goodbye == null) return
        paused = true
        LiaPrefs.setPaused(ctx, true)
        main.removeCallbacks(watchdog)
        busy = false
        listener.cancel()
        wake?.stop()                                // solta o microfone na hora
        scope.launch { tv.sleep() }                 // some a bolinha da TV na hora
        if (goodbye != null) speaker.speak(goodbye) {} else speaker.stop()
        LiaStatus.set(LiaState.IDLE, "")
        onPausedChanged(true)
    }

    private fun doResume() {
        if (!paused) return
        paused = false
        LiaPrefs.setPaused(ctx, false)
        busy = false
        scope.launch { tv.wake() }                  // a TV mostra só a bolinha discreta
        wake?.start()
        LiaStatus.set(LiaState.IDLE, "")
        onPausedChanged(false)
    }

    fun stop() {
        main.removeCallbacks(watchdog)
        wake?.release()
        wake = null
        listener.cancel()
        speaker.shutdown()
        tv.close()
        scope.cancel()
    }

    // ----- sessão (thread principal) -----

    private fun begin(preset: String?) {
        busy = true
        LiaStatus.set(LiaState.LISTENING, "")
        main.postDelayed(watchdog, SESSION_TIMEOUT_MS)
        wake?.stop()                                // libera o microfone
        scope.launch { tv.show(LiaState.LISTENING) }

        if (preset != null) {
            scope.launch { respond(preset) }
            return
        }
        // pequena folga para o microfone ser liberado de verdade antes do reconhecimento
        main.postDelayed({
            if (!paused) listener.listen(
                onText = { text -> scope.launch { respond(text) } },
                onFail = { scope.launch { reply("Não entendi. Pode repetir?") } }
            )
        }, 200)
    }

    private suspend fun respond(text: String) {
        LiaStatus.set(LiaState.LISTENING, "“$text”")
        tv.show(LiaState.LISTENING, "“$text”")
        val r = router.handle(text)
        if (r.sleep) main.post { doPause(r.text) } else reply(r.text)
    }

    private suspend fun reply(text: String) {
        if (paused) return
        LiaStatus.set(LiaState.RESPONDING, text)
        tv.show(LiaState.RESPONDING, text)
        speaker.speak(text) { end() }
    }

    private fun end() {
        main.removeCallbacks(watchdog)
        if (paused) return
        LiaStatus.set(LiaState.IDLE, "")
        // O IDLE inicia, na TV, a contagem de 50 s de inatividade.
        scope.launch { tv.show(LiaState.IDLE) }
        main.post {
            listener.cancel()
            busy = false
            if (!paused) wake?.start()
        }
    }
}
