package com.lia.assistant.tv

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import com.lia.assistant.net.LiaState
import com.lia.assistant.net.MediaState
import com.lia.assistant.net.TvCommand
import com.lia.assistant.net.TvEvent
import com.lia.assistant.net.TvMode

/**
 * Lado do celular. Ele NÃO decide canto ou tela cheia: quem sabe se há vídeo tocando é a TV
 * (ela lê as sessões de mídia), então a troca automática acontece lá, sem atraso de rede.
 * O celular só diz o estado da Lia (ouvindo/respondendo + texto) e, se pedido, força um modo.
 */
class TvManager(private val context: Context, private val link: TvLink) {

    @Volatile private var media: MediaState? = null   // null = ainda sem informação da TV
    @Volatile private var mode = TvMode.AUTO

    /** Eventos que chegam da TV. */
    fun onEvent(e: TvEvent) {
        when (e) {
            is TvEvent.HelloOk -> { media = e.media; mode = e.mode }
            is TvEvent.Media -> media = e.state
            is TvEvent.Error -> Log.w("Lia", "TV respondeu erro: ${e.reason}")
            TvEvent.Pong -> {}
        }
    }

    /** Só mexe na rede se o celular estiver no Wi-Fi. */
    fun isOnWifi(): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    suspend fun show(state: LiaState, text: String = ""): Boolean =
        isOnWifi() && link.send(TvCommand.Show(state, text))

    suspend fun setMode(newMode: TvMode) {
        mode = newMode
        if (isOnWifi()) link.send(TvCommand.SetMode(newMode))
    }

    suspend fun openApp(app: String) {
        if (isOnWifi()) link.send(TvCommand.OpenApp(app))
    }

    /** Modo escola: a bolinha some da TV na hora. */
    suspend fun sleep() {
        if (isOnWifi()) link.send(TvCommand.Sleep)
    }

    /** Volta do descanso: a TV mostra só a bolinha discreta. */
    suspend fun wake() {
        if (isOnWifi()) link.send(TvCommand.Wake)
    }

    fun status(): String {
        val wifi = if (isOnWifi()) "Wi-Fi conectado" else "sem Wi-Fi"
        val tv = when (media) {
            null -> "sem informação da TV ainda"
            MediaState.PLAYING -> "vídeo tocando"
            MediaState.PAUSED -> "vídeo pausado"
            MediaState.NONE -> "nada tocando"
        }
        val m = when (mode) {
            TvMode.AUTO -> "automático"
            TvMode.FULLSCREEN -> "tela cheia"
            TvMode.CORNER_BUBBLE -> "canto"
        }
        return "$wifi. TV: $tv. Modo $m."
    }

    fun close() = link.close()
}
