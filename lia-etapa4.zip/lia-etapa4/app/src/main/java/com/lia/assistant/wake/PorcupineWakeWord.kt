package com.lia.assistant.wake

import ai.picovoice.porcupine.PorcupineManager
import android.content.Context
import android.util.Log
import com.lia.assistant.BuildConfig

/**
 * Detecção da palavra "Lia" no próprio aparelho (Porcupine, da Picovoice).
 * É leve porque só procura UMA palavra, sem enviar áudio para a internet.
 * O Porcupine abre o microfone e roda numa thread própria; o app não grava nem guarda áudio.
 */
class PorcupineWakeWord(
    private val context: Context,
    private val onWake: () -> Unit
) : WakeWordEngine {

    private var manager: PorcupineManager? = null

    override fun start() {
        try {
            if (manager == null) {
                manager = PorcupineManager.Builder()
                    .setAccessKey(BuildConfig.PICOVOICE_ACCESS_KEY)
                    .setKeywordPath(WakeWordFactory.KEYWORD_ASSET)
                    .setSensitivity(0.6f)           // 0 a 1: maior = pega mais, mas erra mais
                    .build(context) { _ -> onWake() }
            }
            manager?.start()
        } catch (e: Exception) {
            Log.e("Lia", "Porcupine não iniciou: ${e.message}")
        }
    }

    override fun stop() {
        try { manager?.stop() } catch (e: Exception) { Log.w("Lia", "Porcupine stop: ${e.message}") }
    }

    override fun release() {
        stop()
        try { manager?.delete() } catch (_: Exception) {}
        manager = null
    }
}
