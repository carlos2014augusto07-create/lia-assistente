// AGP 8.13 + Kotlin 2.2 + Gradle 8.13 (JDK 17). Combinação estável escolhida de propósito:
// o AGP 9 mudou o DSL (Kotlin embutido) e fica para quando o projeto já estiver compilando.
plugins {
    id("com.android.application") version "8.13.0" apply false
    id("org.jetbrains.kotlin.android") version "2.2.20" apply false
}
