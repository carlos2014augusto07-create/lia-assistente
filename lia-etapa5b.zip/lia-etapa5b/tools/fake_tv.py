#!/usr/bin/env python3
"""
TV de mentira para testar o app do celular SEM a Aiwa.
Roda em qualquer computador (ou Termux) ligado no mesmo Wi-Fi do celular:

    python3 fake_tv.py [token]            # token padrão: lia-dev

Depois, no gradle.properties do app: LIA_TV_HOST=<IP deste computador>
(o anúncio automático por mDNS só existe no app real da TV).
Digite  p  + Enter para simular "vídeo tocando",  n  para "nada tocando".
FAKE_REST=5 python3 fake_tv.py  → usa 5 s em vez de 50 s de inatividade (teste rápido).
"""
import json, os, socket, sys, threading

TOKEN = sys.argv[1] if len(sys.argv) > 1 else "lia-dev"
PORT = 8765
REST = float(os.environ.get("FAKE_REST", "50"))   # segundos de inatividade (padrão do app: 50)
media = "NONE"
mode = "AUTO"
clients = []
timer = None


def effective():
    if mode != "AUTO":
        return mode
    return "CORNER_BUBBLE" if media == "PLAYING" else "FULLSCREEN"


def rest_view():
    return "(some)" if media == "PLAYING" else "(só a bolinha)"


def arm_rest():
    global timer
    if timer:
        timer.cancel()
    timer = threading.Timer(REST, lambda: print(f"  >>> {REST:g}s sem voz: Lia recolhe {rest_view()}"))
    timer.daemon = True
    timer.start()


def send(conn, obj):
    conn.sendall((json.dumps(obj) + "\n").encode())


def serve(conn, addr):
    global mode
    f = conn.makefile("r", encoding="utf-8")
    try:
        hello = json.loads(f.readline() or "{}")
        if hello.get("type") != "HELLO" or hello.get("token") != TOKEN:
            send(conn, {"type": "ERROR", "reason": "token"})
            print(f"[{addr[0]}] token recusado")
            return
        clients.append(conn)
        send(conn, {"type": "HELLO_OK", "mode": mode, "media": media})
        print(f"[{addr[0]}] celular conectado")
        for line in f:
            try:
                msg = json.loads(line)
            except ValueError:
                continue
            t = msg.get("type")
            if t == "PING":
                send(conn, {"type": "PONG"})
            elif t == "SET_MODE":
                mode = msg.get("mode", "AUTO")
                print(f"  modo forçado: {mode}  (efetivo agora: {effective()})")
            elif t == "SHOW":
                print(f"  [{effective():13}] {msg.get('state'):10} {msg.get('text', '')}")
                if timer:
                    timer.cancel()
                if msg.get("state") == "IDLE":
                    arm_rest()
            elif t == "SLEEP":
                if timer:
                    timer.cancel()
                print("  >>> SLEEP: a Lia some da tela na hora (modo escola)")
            elif t == "WAKE":
                print("  >>> WAKE: volta só a bolinha discreta")
            else:
                print("  recebido:", msg)
    except OSError:
        pass            # o celular fechou a conexão (acontece após 45 s sem uso)
    finally:
        if conn in clients:
            clients.remove(conn)
        conn.close()
        print(f"[{addr[0]}] desconectou")


def keyboard():
    global media
    for line in sys.stdin:
        media = {"p": "PLAYING", "n": "NONE"}.get(line.strip().lower(), media)
        print(f"  mídia agora: {media}  (modo efetivo: {effective()})")
        for c in list(clients):
            try:
                send(c, {"type": "MEDIA", "state": media, "app": "com.google.android.youtube.tv"})
            except OSError:
                pass


srv = socket.socket()
srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.bind(("0.0.0.0", PORT))
srv.listen(1)
print(f"TV falsa ouvindo na porta {PORT} (token: {TOKEN}). 'p' = tocando, 'n' = nada.")
threading.Thread(target=keyboard, daemon=True).start()
while True:
    c, a = srv.accept()
    threading.Thread(target=serve, args=(c, a), daemon=True).start()
