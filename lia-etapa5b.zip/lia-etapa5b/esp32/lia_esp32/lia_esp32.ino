/*
  Lia — ESP32 (receptor de comandos pela rede Wi-Fi local)

  O que faz:
    - conecta no seu Wi-Fi e se anuncia na rede como "lia-esp32" (mDNS, serviço _liaesp._tcp);
      assim o app da Lia acha o ESP32 sozinho, sem você digitar IP;
    - GET /status                       -> {"devices":{"luz":true,"ventilador":false}}
    - GET /cmd?device=luz&state=on|off  -> liga/desliga o pino do dispositivo
    - todo pedido precisa do cabeçalho  X-Lia-Token  igual ao LIA_TOKEN do app.

  Como usar (Arduino IDE): placa "ESP32 Dev Module", abra este arquivo, edite a seção
  CONFIGURE AQUI e envie. Para adicionar um dispositivo, acrescente uma linha em devices[].
  O app descobre os nomes sozinho: diga "Lia, liga a luz" / "desliga o ventilador".

  ATENÇÃO: o ESP32 aguenta só ~12 mA por pino. Para lâmpada, ventilador etc. use um módulo
  de relé e NUNCA ligue a rede elétrica direto no ESP32.
*/

#include <WiFi.h>
#include <ESPmDNS.h>
#include <WebServer.h>

// ===================== CONFIGURE AQUI =====================
const char* WIFI_SSID = "NOME_DO_SEU_WIFI";
const char* WIFI_PASS = "SENHA_DO_SEU_WIFI";
const char* LIA_TOKEN = "troque-este-token";   // o mesmo LIA_TOKEN do app
const char* HOSTNAME  = "lia-esp32";

struct Device {
  const char* name;   // como você fala: "luz", "ventilador"
  uint8_t pin;        // GPIO ligado ao relé/LED
  bool activeHigh;    // true: HIGH liga | false: LOW liga (comum em módulos de relé)
  bool on;            // estado atual
};

Device devices[] = {
  {"luz",        2, true, false},   // GPIO2 = LED azul da placa, ótimo para testar
  {"ventilador", 4, true, false},
};
// ==========================================================

const size_t NUM_DEVICES = sizeof(devices) / sizeof(devices[0]);
WebServer server(80);

void applyDevice(Device& d, bool on) {
  d.on = on;
  digitalWrite(d.pin, (on == d.activeHigh) ? HIGH : LOW);
}

bool authorized() {
  return server.header("X-Lia-Token") == LIA_TOKEN;
}

void handleStatus() {
  if (!authorized()) {
    server.send(401, "application/json", "{\"error\":\"token\"}");
    return;
  }
  String json = "{\"devices\":{";
  for (size_t i = 0; i < NUM_DEVICES; i++) {
    if (i > 0) json += ",";
    json += "\"";
    json += devices[i].name;
    json += "\":";
    json += devices[i].on ? "true" : "false";
  }
  json += "}}";
  server.send(200, "application/json", json);
}

void handleCmd() {
  if (!authorized()) {
    server.send(401, "application/json", "{\"error\":\"token\"}");
    return;
  }
  String name = server.arg("device");
  String state = server.arg("state");
  for (size_t i = 0; i < NUM_DEVICES; i++) {
    if (name == devices[i].name) {
      applyDevice(devices[i], state == "on");
      server.send(200, "application/json", "{\"ok\":true}");
      return;
    }
  }
  server.send(404, "application/json", "{\"error\":\"dispositivo\"}");
}

void connectWifi() {
  WiFi.mode(WIFI_STA);
  WiFi.setHostname(HOSTNAME);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  unsigned long t0 = millis();
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    if (millis() - t0 > 20000) ESP.restart();   // não conectou em 20 s: tenta de novo do zero
  }
  Serial.print("Wi-Fi ok, IP: ");
  Serial.println(WiFi.localIP());
}

void setup() {
  Serial.begin(115200);
  for (size_t i = 0; i < NUM_DEVICES; i++) {
    pinMode(devices[i].pin, OUTPUT);
    applyDevice(devices[i], false);   // tudo desligado ao ligar o ESP32
  }

  connectWifi();

  if (MDNS.begin(HOSTNAME)) {
    MDNS.addService("liaesp", "tcp", 80);   // o app procura por _liaesp._tcp
  }

  const char* headers[] = {"X-Lia-Token"};
  server.collectHeaders(headers, 1);
  server.on("/status", HTTP_GET, handleStatus);
  server.on("/cmd", HTTP_GET, handleCmd);
  server.begin();
}

void loop() {
  server.handleClient();

  static unsigned long lastTry = 0;
  if (WiFi.status() != WL_CONNECTED && millis() - lastTry > 10000) {
    lastTry = millis();
    WiFi.reconnect();   // o roteador reiniciou? tenta voltar sozinho
  }
  delay(2);             // deixa o ESP32 respirar (menos consumo)
}
