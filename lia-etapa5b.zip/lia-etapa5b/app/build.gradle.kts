import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Lê do ambiente (GitHub Secrets) ou do gradle.properties; usa o padrão se estiver vazio.
fun setting(name: String, default: String = ""): String =
    System.getenv(name)?.takeIf { it.isNotBlank() }
        ?: (project.findProperty(name) as String?)?.takeIf { it.isNotBlank() }
        ?: default

android {
    namespace = "com.lia.assistant"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.lia.assistant"
        minSdk = 26
        targetSdk = 36
        versionCode = 7
        versionName = "0.5.1"

        buildConfigField("String", "LIA_TOKEN", "\"${setting("LIA_TOKEN", "lia-dev")}\"")
        buildConfigField("String", "LIA_TV_HOST", "\"${setting("LIA_TV_HOST")}\"")
        buildConfigField("String", "LIA_ESP_HOST", "\"${setting("LIA_ESP_HOST")}\"")
        buildConfigField("String", "PICOVOICE_ACCESS_KEY", "\"${setting("LIA_PICOVOICE_KEY")}\"")
        buildConfigField("String", "LIA_TTS_VOICE", "\"${setting("LIA_TTS_VOICE")}\"")
        // Plano B (não recomendado): a chave do Google dentro do APK. O normal é colar a chave no app.
        buildConfigField("String", "LIA_AI_KEY", "\"${setting("LIA_AI_KEY")}\"")
        buildConfigField("String", "LIA_AI_MODEL", "\"${setting("LIA_AI_MODEL")}\"")
    }

    signingConfigs {
        // Chave de debug FIXA (debug.keystore na raiz): todo build sai com a mesma assinatura,
        // então o APK novo instala por cima do antigo sem precisar desinstalar.
        getByName("debug") {
            storeFile = rootProject.file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildFeatures { buildConfig = true }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    // Palavra de ativação. "+" pega a versão mais nova (combina com o .ppn que o Console gera).
    // Quando compilar, troque "+" pela versão que o Gradle resolveu.
    implementation("ai.picovoice:porcupine-android:+")
}
