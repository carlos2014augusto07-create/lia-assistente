package com.lia.assistant.net

import com.lia.assistant.LiaLog as Log
import com.lia.assistant.tv.TvLink
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedWriter
import java.io.IOException
import java.io.OutputStreamWriter
import java.net.InetSocketAddress
import java.net.Socket

private const val TAG = "Lia"
private const val IDLE_CLOSE_MS = 45_000L

/**
 * Conexão TCP com a Aiwa TV.
 * Economia de bateria: conecta só quando há algo a enviar e fecha após 45 s sem uso.
 * Não precisa de "ping" constante, porque a TV decide sozinha o modo (canto/tela cheia).
 */
class TvSocketLink(
    private val findHost: suspend (forceRefresh: Boolean) -> String?,
    private val token: String,
    private val onEvent: (TvEvent) -> Unit
) : TvLink {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    @Volatile private var socket: Socket? = null
    @Volatile private var writer: BufferedWriter? = null
    private var idleJob: Job? = null

    override suspend fun send(command: TvCommand): Boolean = withContext(Dispatchers.IO) {
        mutex.withLock {
            for (attempt in 1..2) {
                try {
                    val w = connectIfNeeded(forceRefresh = attempt > 1)
                    w.write(command.toJson())
                    w.write("\n")
                    w.flush()
                    armIdleClose()
                    return@withLock true
                } catch (e: IOException) {
                    Log.w(TAG, "TV: tentativa $attempt falhou (${e.message})")
                    closeQuietly()
                }
            }
            false
        }
    }

    private suspend fun connectIfNeeded(forceRefresh: Boolean): BufferedWriter {
        writer?.let { w -> if (socket?.isClosed == false) return w }

        val host = findHost(forceRefresh) ?: throw IOException("TV não encontrada na rede")
        val s = Socket()
        s.connect(InetSocketAddress(host, TV_PORT), 2500)
        s.tcpNoDelay = true
        s.keepAlive = true

        val w = BufferedWriter(OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8))
        w.write(TvCommand.Hello(token).toJson())
        w.write("\n")
        w.flush()

        socket = s
        writer = w
        startReader(s)
        return w
    }

    private fun startReader(s: Socket) {
        scope.launch {
            try {
                s.getInputStream().bufferedReader(Charsets.UTF_8).forEachLine { line ->
                    parseEvent(line)?.let(onEvent)
                }
            } catch (_: IOException) {
            } finally {
                if (socket === s) closeQuietly()
            }
        }
    }

    private fun armIdleClose() {
        idleJob?.cancel()
        idleJob = scope.launch {
            delay(IDLE_CLOSE_MS)
            mutex.withLock { closeQuietly() }
        }
    }

    private fun closeQuietly() {
        try { socket?.close() } catch (_: IOException) {}
        socket = null
        writer = null
    }

    override fun close() {
        idleJob?.cancel()
        scope.cancel()
        closeQuietly()
    }
}
