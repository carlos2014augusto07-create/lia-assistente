package com.lia.assistant

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Botão rápido nas Configurações rápidas (puxe a barra de cima): um toque pausa ou acorda a Lia.
 * Para adicionar: puxe a barra → ícone de lápis/editar → arraste o bloco "Lia".
 */
class LiaTileService : TileService() {

    override fun onStartListening() = refresh()

    override fun onClick() {
        if (LiaService.running) {
            startService(Intent(this, LiaService::class.java).setAction(LiaService.ACTION_TOGGLE_PAUSE))
        } else {
            // Serviço desligado: abrir o app o liga (no Android 14+ o microfone só inicia com o app visível).
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (Build.VERSION.SDK_INT >= 34) {
                startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(i)
            }
        }
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val paused = LiaPrefs.isPaused(this)
        val listening = LiaService.running && !paused
        tile.state = if (listening) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "Lia"
        if (Build.VERSION.SDK_INT >= 29) {
            tile.subtitle = when {
                !LiaService.running -> "Desligada"
                paused -> "Descansando"
                else -> "Ouvindo"
            }
        }
        tile.updateTile()
    }
}
