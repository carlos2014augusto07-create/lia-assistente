package com.lia.assistant

import java.text.Normalizer

/** minúsculas, sem acentos, sem pontuação, sem espaços sobrando: facilita comparar o que a pessoa falou. */
fun normalize(s: String): String =
    Normalizer.normalize(s.lowercase().trim(), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9 ]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
