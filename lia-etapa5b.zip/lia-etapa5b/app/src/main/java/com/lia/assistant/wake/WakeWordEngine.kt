package com.lia.assistant.wake

import android.content.Context
import com.lia.assistant.LiaLog as Log

/** Qualquer motor de palavra de ativação implementa isto. */
interface WakeWordEngine {
    /** Começa (ou volta) a escutar o microfone. */
    fun start()
    /** Para de escutar e LIBERA o microfone (para o reconhecimento de fala usar). */
    fun stop()
    /** Descarta o motor de vez. */
    fun release() {}
}

/** Motor vazio: não abre o microfone. Usado quando faltam a chave ou o arquivo .ppn. */
class IdleWakeWord : WakeWordEngine {
    override fun start() { Log.d("Lia", "IdleWakeWord: sem microfone (use o botão Testar da notificação)") }
    override fun stop() {}
}

object WakeWordFactory {
    const val KEYWORD_ASSET = "lia_android.ppn"   // app/src/main/assets/lia_android.ppn

    fun create(context: Context, onWake: () -> Unit): WakeWordEngine {
        val hasKey = com.lia.assistant.BuildConfig.PICOVOICE_ACCESS_KEY.isNotBlank()
        val hasModel = runCatching { context.assets.open(KEYWORD_ASSET).close() }.isSuccess
        return if (hasKey && hasModel) {
            com.lia.assistant.LiaStatus.wakeInfo = "Palavra “Lia”: ativa (Porcupine)"
            PorcupineWakeWord(context, onWake)
        } else {
            com.lia.assistant.LiaStatus.wakeInfo =
                "Palavra “Lia”: desligada (falta chave ou arquivo .ppn). Use o botão Ouvir agora."
            Log.w("Lia", "Porcupine desligado: falta LIA_PICOVOICE_KEY (=$hasKey) ou $KEYWORD_ASSET (=$hasModel)")
            IdleWakeWord()
        }
    }
}
