package com.lia.assistant.ai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Responde o que as regras locais não cobrem, lembrando das últimas trocas da conversa. */
class AiAssistant(ctx: Context) {

    private val settings = AiSettings(ctx)
    private val client = AiClient()
    private val history = ArrayList<Turn>()
    private var lastAt = 0L

    fun isConfigured() = settings.apiKey.isNotBlank()

    /** Chame assim que a Lia começar a ouvir: prepara a conexão segura enquanto você ainda fala. */
    suspend fun warmUp() {
        if (isConfigured()) withContext(Dispatchers.IO) { client.warmUp() }
    }

    /** [onSentence] é chamado a cada frase pronta (streaming), em outra thread. */
    suspend fun answer(question: String, onSentence: (String) -> Unit): AiResult {
        val key = settings.apiKey
        if (key.isBlank()) {
            return AiResult.Fail(
                "Para eu responder perguntas, cadastre a chave do Google na tela principal do app.", "sem chave"
            )
        }
        val now = System.currentTimeMillis()
        if (now - lastAt > CONVERSATION_MEMORY_MS) history.clear()   // 10 min parada: conversa nova

        val result = withContext(Dispatchers.IO) {
            client.ask(key, settings.modelsToTry(), history.toList(), question, onSentence) { settings.lastGood = it }
        }
        if (result is AiResult.Ok) {
            history.add(Turn("user", question))
            history.add(Turn("model", result.text))
            while (history.size > MAX_TURNS) { history.removeAt(0); history.removeAt(0) }
            lastAt = now
        }
        return result
    }

    private companion object {
        const val MAX_TURNS = 12                       // 6 trocas de ida e volta
        const val CONVERSATION_MEMORY_MS = 10 * 60_000L
    }
}
