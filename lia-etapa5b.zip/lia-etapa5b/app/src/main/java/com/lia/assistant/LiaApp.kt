package com.lia.assistant

import android.app.Application

class LiaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
    }
}
