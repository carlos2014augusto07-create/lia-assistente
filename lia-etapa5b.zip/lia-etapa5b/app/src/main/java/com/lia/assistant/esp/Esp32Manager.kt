package com.lia.assistant.esp

import android.content.Context
import android.os.SystemClock
import com.lia.assistant.net.Esp32Link
import com.lia.assistant.normalize

/**
 * Entende frases curtas como "liga a luz" / "desliga o ventilador".
 * Os nomes dos dispositivos vêm do próprio ESP32 (/status) e ficam guardados no celular.
 *
 * Só trata a frase como comando do ESP32 se ela citar o nome de um dispositivo. Assim, perguntas comuns
 * ("como apagar uma mensagem?") passam direto para a IA, e quem não tem ESP32 não é atrapalhado
 * (a procura por um ESP32 inexistente é feita no máximo a cada 5 minutos).
 */
class Esp32Manager(ctx: Context, private val link: Esp32Link) {

    private val prefs = ctx.applicationContext.getSharedPreferences("lia_esp", Context.MODE_PRIVATE)
    private var cache: Map<String, Boolean>? = null
    private var cachedAt = 0L
    private var failedAt = 0L

    /** Recebe o texto já normalizado. Devolve a resposta falada, ou null se não for comando do ESP32. */
    suspend fun handle(text: String): String? {
        val words = text.split(" ").filter { it.isNotEmpty() }
        if (words.size > 6) return null                      // frase longa: é conversa, não comando

        val off = words.any { it in OFF_WORDS }
        val on = !off && words.any { it in ON_WORDS }
        if (!off && !on) return null

        val names = knownNames().ifEmpty { devices()?.keys ?: return null }
        val name = names.firstOrNull { normalize(it) in text } ?: return null

        val ok = link.set(name, on)
        cache = null
        return if (ok) "Pronto, ${if (on) "liguei" else "desliguei"} o dispositivo $name."
        else "O ESP32 não respondeu."
    }

    private fun knownNames(): Set<String> = prefs.getStringSet("names", emptySet()) ?: emptySet()

    private suspend fun devices(): Map<String, Boolean>? {
        val now = SystemClock.elapsedRealtime()
        cache?.let { if (now - cachedAt < 30_000) return it }
        if (failedAt != 0L && now - failedAt < 5 * 60_000L) return null   // sem ESP32 por perto: não insiste
        val d = link.devices()
        if (d == null) { failedAt = now; return null }
        failedAt = 0L
        cache = d
        cachedAt = now
        prefs.edit().putStringSet("names", d.keys.toSet()).apply()
        return d
    }

    private companion object {
        // Palavras inteiras: "desligar" não pode ser confundido com "ligar".
        val ON_WORDS = setOf("liga", "ligar", "ligue", "acende", "acender", "acenda")
        val OFF_WORDS = setOf("desliga", "desligar", "desligue", "apaga", "apagar", "apague")
    }
}
