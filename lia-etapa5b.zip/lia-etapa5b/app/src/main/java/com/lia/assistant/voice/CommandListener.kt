package com.lia.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.lia.assistant.LiaLog as Log

/**
 * Escuta UMA frase depois da palavra de ativação, usando o reconhecimento de fala do Android.
 * Prefere o reconhecimento no próprio aparelho (sem internet, mais rápido e privado).
 * Precisa ser chamado na thread principal.
 */
class CommandListener(private val ctx: Context) {

    private var recognizer: SpeechRecognizer? = null

    fun listen(onText: (String) -> Unit, onFail: () -> Unit) {
        cancel()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            Log.w("Lia", "Sem serviço de reconhecimento de fala neste aparelho")
            onFail()
            return
        }

        val r = if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx)) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
        } else {
            SpeechRecognizer.createSpeechRecognizer(ctx)
        }
        recognizer = r

        var finished = false   // evita responder duas vezes (onError + onResults)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                if (finished) return
                finished = true
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) onFail() else onText(text)
            }

            override fun onError(error: Int) {
                if (finished) return
                finished = true
                Log.w("Lia", "Reconhecimento de fala falhou (código $error)")
                onFail()
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        r.startListening(intent)
    }

    fun cancel() {
        recognizer?.let {
            runCatching { it.cancel() }
            runCatching { it.destroy() }
        }
        recognizer = null
    }
}
