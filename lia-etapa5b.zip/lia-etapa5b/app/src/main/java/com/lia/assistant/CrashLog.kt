package com.lia.assistant

import android.app.Application
import android.content.Context
import android.util.Log
import java.io.File
import java.util.Date

/**
 * Se o app fechar por erro, o motivo fica salvo e aparece na tela principal na próxima vez que abrir.
 * Assim dá para copiar o texto e me mandar, sem computador.
 */
object CrashLog {
    private const val FILE = "ultimo_erro.txt"

    fun install(app: Application) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                File(app.filesDir, FILE).writeText(
                    "${Date()}  (thread: ${thread.name})\n${Log.getStackTraceString(error)}"
                )
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun read(ctx: Context): String? =
        File(ctx.filesDir, FILE).takeIf { it.exists() }?.readText()?.takeIf { it.isNotBlank() }

    fun clear(ctx: Context) {
        File(ctx.filesDir, FILE).delete()
    }
}
