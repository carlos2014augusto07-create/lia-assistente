package com.lia.assistant

import android.os.Handler
import android.os.Looper
import com.lia.assistant.net.LiaState
import java.util.concurrent.CopyOnWriteArraySet

/** O serviço escreve aqui; a tela principal lê e se atualiza. Sem bibliotecas, sem polling. */
object LiaStatus {
    @Volatile var state: LiaState = LiaState.IDLE
    @Volatile var text: String = ""
    @Volatile var wakeInfo: String = "Palavra “Lia”: ainda não iniciada"
    @Volatile var tvInfo: String = "TV: ainda sem contato"

    private val listeners = CopyOnWriteArraySet<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    fun set(newState: LiaState, newText: String) {
        state = newState
        if (newText.isNotEmpty()) text = newText
        notifyChanged()
    }

    fun add(l: () -> Unit) { listeners.add(l) }
    fun remove(l: () -> Unit) { listeners.remove(l) }
    fun notifyChanged() { main.post { listeners.forEach { it() } } }
}
