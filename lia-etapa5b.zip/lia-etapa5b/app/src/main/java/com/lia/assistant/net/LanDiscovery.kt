package com.lia.assistant.net

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.net.Inet4Address
import kotlin.coroutines.resume

/**
 * Acha a TV e o ESP32 na rede sem você digitar IP.
 * Ordem: IP fixo (gradle.properties) → último IP guardado → procura por NSD/mDNS.
 * O resultado fica guardado: procurar na rede gasta bateria, então só se faz quando preciso.
 */
class LanDiscovery(context: Context) {

    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val prefs = context.getSharedPreferences("lia_hosts", Context.MODE_PRIVATE)

    suspend fun find(
        serviceType: String,
        fixedHost: String,
        cacheKey: String,
        forceRefresh: Boolean = false,
        timeoutMs: Long = 6000
    ): String? {
        if (fixedHost.isNotBlank()) return fixedHost
        if (!forceRefresh) prefs.getString(cacheKey, null)?.let { return it }
        val host = discover(serviceType, timeoutMs)
        if (host != null) prefs.edit().putString(cacheKey, host).apply()
        return host
    }

    @Suppress("DEPRECATION")
    private suspend fun discover(type: String, timeoutMs: Long): String? =
        withTimeoutOrNull(timeoutMs) {
            suspendCancellableCoroutine<String?> { cont ->
                lateinit var listener: NsdManager.DiscoveryListener

                fun finish(host: String?) {
                    if (cont.isActive) cont.resume(host)
                    runCatching { nsd.stopServiceDiscovery(listener) }
                }

                listener = object : NsdManager.DiscoveryListener {
                    override fun onDiscoveryStarted(serviceType: String) {}
                    override fun onServiceFound(info: NsdServiceInfo) {
                        runCatching {
                            nsd.resolveService(info, object : NsdManager.ResolveListener {
                                override fun onResolveFailed(i: NsdServiceInfo, errorCode: Int) {}
                                override fun onServiceResolved(i: NsdServiceInfo) {
                                    pickHost(i)?.let { finish(it) }
                                }
                            })
                        }
                    }
                    override fun onServiceLost(info: NsdServiceInfo) {}
                    override fun onDiscoveryStopped(serviceType: String) {}
                    override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { finish(null) }
                    override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
                }

                nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, listener)
                cont.invokeOnCancellation { runCatching { nsd.stopServiceDiscovery(listener) } }
            }
        }

    /** Prefere endereço IPv4: é o que funciona direto em Socket e HTTP. */
    private fun pickHost(i: NsdServiceInfo): String? {
        val all = if (Build.VERSION.SDK_INT >= 34) i.hostAddresses else listOfNotNull(i.host)
        return (all.firstOrNull { it is Inet4Address } ?: all.firstOrNull())?.hostAddress
    }
}
