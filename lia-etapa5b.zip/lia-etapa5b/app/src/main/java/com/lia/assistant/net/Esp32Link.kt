package com.lia.assistant.net

import com.lia.assistant.LiaLog as Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private const val TAG = "Lia"

/**
 * Fala com o ESP32 por HTTP simples na rede local.
 *   GET /status                      → {"devices":{"luz":true,"ventilador":false}}
 *   GET /cmd?device=luz&state=on|off → {"ok":true}
 * Todo pedido leva o cabeçalho X-Lia-Token.
 */
class Esp32Link(
    private val findHost: suspend (forceRefresh: Boolean) -> String?,
    private val token: String
) {

    suspend fun devices(): Map<String, Boolean>? {
        val body = request("/status") ?: return null
        return try {
            val o = JSONObject(body).getJSONObject("devices")
            o.keys().asSequence().associateWith { o.getBoolean(it) }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun set(device: String, on: Boolean): Boolean {
        val name = URLEncoder.encode(device, "UTF-8")
        return request("/cmd?device=$name&state=${if (on) "on" else "off"}") != null
    }

    private suspend fun request(path: String): String? = withContext(Dispatchers.IO) {
        for (attempt in 1..2) {
            val host = findHost(attempt > 1) ?: return@withContext null
            try {
                val c = URL("http://$host$path").openConnection() as HttpURLConnection
                c.requestMethod = "GET"
                c.connectTimeout = 2500
                c.readTimeout = 2500
                c.setRequestProperty("X-Lia-Token", token)
                val code = c.responseCode
                val body = (if (code in 200..299) c.inputStream else c.errorStream)
                    ?.bufferedReader()?.use { it.readText() }
                c.disconnect()
                if (code in 200..299) return@withContext body
                if (code == 401) {
                    Log.w(TAG, "ESP32 recusou o token")
                    return@withContext null
                }
            } catch (e: IOException) {
                Log.w(TAG, "ESP32: tentativa $attempt falhou (${e.message})")
            }
        }
        null
    }
}
