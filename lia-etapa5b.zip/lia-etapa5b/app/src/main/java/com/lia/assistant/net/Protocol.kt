package com.lia.assistant.net

import org.json.JSONObject

/*
 * Protocolo Lia: uma mensagem JSON por linha, via TCP (porta 8765), celular ⇄ TV.
 * Este arquivo é IGUAL no app do celular e no app da TV (só a linha "package" muda).
 * Se alterar aqui, altere nos dois.
 */

const val TV_PORT = 8765
const val TV_SERVICE_TYPE = "_liatv._tcp."
const val ESP_SERVICE_TYPE = "_liaesp._tcp."

enum class LiaState { IDLE, LISTENING, RESPONDING }

/** AUTO = a TV decide sozinha: vídeo tocando → canto; senão → tela cheia. */
enum class TvMode { AUTO, FULLSCREEN, CORNER_BUBBLE }

enum class MediaState { NONE, PAUSED, PLAYING }

/** Celular → TV. Não existe PAUSE nem PLAY: a Lia nunca controla a mídia. */
sealed interface TvCommand {
    data class Hello(val token: String) : TvCommand
    data class Show(val state: LiaState, val text: String = "") : TvCommand
    data class SetMode(val mode: TvMode) : TvCommand
    data class OpenApp(val app: String) : TvCommand
    data object Hide : TvCommand
    data object Ping : TvCommand
    /** Modo escola/pausa: a Lia some da tela na hora. */
    data object Sleep : TvCommand
    /** Volta do descanso: aparece só a bolinha discreta no canto. */
    data object Wake : TvCommand
}

/** TV → celular. */
sealed interface TvEvent {
    data class HelloOk(val mode: TvMode, val media: MediaState) : TvEvent
    data class Media(val state: MediaState, val app: String?) : TvEvent
    data class Error(val reason: String) : TvEvent
    data object Pong : TvEvent
}

inline fun <reified T : Enum<T>> String.toEnum(default: T): T =
    enumValues<T>().firstOrNull { it.name == this } ?: default

fun TvCommand.toJson(): String = when (this) {
    is TvCommand.Hello -> JSONObject().put("type", "HELLO").put("token", token)
    is TvCommand.Show -> JSONObject().put("type", "SHOW").put("state", state.name).put("text", text)
    is TvCommand.SetMode -> JSONObject().put("type", "SET_MODE").put("mode", mode.name)
    is TvCommand.OpenApp -> JSONObject().put("type", "OPEN_APP").put("app", app)
    TvCommand.Hide -> JSONObject().put("type", "HIDE")
    TvCommand.Ping -> JSONObject().put("type", "PING")
    TvCommand.Sleep -> JSONObject().put("type", "SLEEP")
    TvCommand.Wake -> JSONObject().put("type", "WAKE")
}.toString()

fun parseCommand(line: String): TvCommand? = try {
    val o = JSONObject(line)
    when (o.optString("type")) {
        "HELLO" -> TvCommand.Hello(o.optString("token"))
        "SHOW" -> TvCommand.Show(o.optString("state").toEnum(LiaState.IDLE), o.optString("text"))
        "SET_MODE" -> TvCommand.SetMode(o.optString("mode").toEnum(TvMode.AUTO))
        "OPEN_APP" -> TvCommand.OpenApp(o.optString("app"))
        "HIDE" -> TvCommand.Hide
        "PING" -> TvCommand.Ping
        "SLEEP" -> TvCommand.Sleep
        "WAKE" -> TvCommand.Wake
        else -> null
    }
} catch (e: Exception) {
    null
}

fun TvEvent.toJson(): String = when (this) {
    is TvEvent.HelloOk -> JSONObject().put("type", "HELLO_OK").put("mode", mode.name).put("media", media.name)
    is TvEvent.Media -> JSONObject().put("type", "MEDIA").put("state", state.name).put("app", app ?: "")
    is TvEvent.Error -> JSONObject().put("type", "ERROR").put("reason", reason)
    TvEvent.Pong -> JSONObject().put("type", "PONG")
}.toString()

fun parseEvent(line: String): TvEvent? = try {
    val o = JSONObject(line)
    when (o.optString("type")) {
        "HELLO_OK" -> TvEvent.HelloOk(o.optString("mode").toEnum(TvMode.AUTO), o.optString("media").toEnum(MediaState.NONE))
        "MEDIA" -> TvEvent.Media(o.optString("state").toEnum(MediaState.NONE), o.optString("app").ifBlank { null })
        "ERROR" -> TvEvent.Error(o.optString("reason"))
        "PONG" -> TvEvent.Pong
        else -> null
    }
} catch (e: Exception) {
    null
}
