package com.lia.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.service.quicksettings.TileService
import com.lia.assistant.LiaLog as Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/** Serviço leve em primeiro plano: sem tela, só uma notificação mínima. O trabalho é do LiaEngine. */
class LiaService : Service() {

    private var engine: LiaEngine? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Quem chama startForegroundService precisa chegar aqui em até 5 s.
        if (!enterForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }

        val e = engine ?: LiaEngine(applicationContext) { paused -> onPausedChanged(paused) }
            .also { engine = it; it.start() }

        when (intent?.action) {
            ACTION_SIMULATE_WAKE -> e.onWake()
            ACTION_COMMAND -> e.runText(intent.getStringExtra(EXTRA_TEXT).orEmpty())
            ACTION_PAUSE -> e.pause()
            ACTION_RESUME -> e.resume()
            ACTION_TOGGLE_PAUSE -> e.togglePause()
        }
        refreshTile()
        return START_STICKY
    }

    private fun onPausedChanged(paused: Boolean) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(paused))
        refreshTile()
    }

    private fun refreshTile() {
        runCatching {
            TileService.requestListeningState(this, ComponentName(this, LiaTileService::class.java))
        }
    }

    private fun enterForeground(): Boolean = try {
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(LiaPrefs.isPaused(this)),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
        true
    } catch (e: Exception) {
        Log.e(TAG, "Não foi possível iniciar em primeiro plano: ${e.message}")
        false
    }

    private fun createChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Lia ouvindo", NotificationManager.IMPORTANCE_MIN)
            .apply { setShowBadge(false) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(paused: Boolean): Notification {
        fun action(label: String, action: String) = NotificationCompat.Action.Builder(
            0, label,
            PendingIntent.getService(
                this, action.hashCode(),
                Intent(this, LiaService::class.java).setAction(action),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        ).build()

        // Tocar na notificação abre o app, e abrir o app acorda a Lia.
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("Lia")
            .setContentText(if (paused) "Descansando: microfone desligado" else "Aguardando “Lia”…")
            .setContentIntent(open)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)

        if (paused) {
            b.addAction(action("Acordar", ACTION_RESUME))
        } else {
            b.addAction(action("Descansar", ACTION_PAUSE))
            b.addAction(action("Testar", ACTION_SIMULATE_WAKE))
        }
        b.addAction(action("Parar", ACTION_STOP))
        return b.build()
    }

    override fun onDestroy() {
        running = false
        engine?.stop()
        engine = null
        refreshTile()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val TAG = "Lia"
        const val ACTION_STOP = "com.lia.assistant.STOP"
        const val ACTION_SIMULATE_WAKE = "com.lia.assistant.SIMULATE_WAKE"
        const val ACTION_COMMAND = "com.lia.assistant.COMMAND"
        const val ACTION_PAUSE = "com.lia.assistant.PAUSE"
        const val ACTION_RESUME = "com.lia.assistant.RESUME"
        const val ACTION_TOGGLE_PAUSE = "com.lia.assistant.TOGGLE_PAUSE"
        const val EXTRA_TEXT = "text"
        private const val CHANNEL_ID = "lia_listening"
        private const val NOTIF_ID = 1

        /** O botão rápido (outro componente do mesmo app) usa isto para saber se o serviço existe. */
        @Volatile var running = false
            private set
    }
}
