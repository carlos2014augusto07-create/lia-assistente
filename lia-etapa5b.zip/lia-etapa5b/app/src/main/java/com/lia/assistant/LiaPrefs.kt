package com.lia.assistant

import android.content.Context

/** Guarda se a Lia está descansando, para o estado sobreviver a reinícios do serviço. */
object LiaPrefs {
    private fun prefs(c: Context) = c.getSharedPreferences("lia_state", Context.MODE_PRIVATE)
    fun isPaused(c: Context): Boolean = prefs(c).getBoolean("paused", false)
    fun setPaused(c: Context, v: Boolean) = prefs(c).edit().putBoolean("paused", v).apply()
}
