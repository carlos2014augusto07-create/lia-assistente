package com.lia.assistant.ai

import android.content.Context
import com.lia.assistant.BuildConfig

/**
 * Chave do Google AI Studio (Gemini) e escolha de modelo.
 * A chave digitada no app fica só na memória privada do aparelho (não vai para o GitHub nem dentro do APK).
 * Não validamos o formato da chave: o Google já emite chaves "AIza..." e "AQ..." e pode mudar de novo.
 */
class AiSettings(ctx: Context) {
    private val prefs = ctx.applicationContext.getSharedPreferences("lia_ai", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString("gkey", null)?.trim()?.takeIf { it.isNotEmpty() } ?: BuildConfig.LIA_AI_KEY.trim()
        set(value) { prefs.edit().putString("gkey", value.trim()).apply() }

    /** Vazio = automático (usa a lista em ordem). Preenchido = só esse modelo. */
    var model: String
        get() = prefs.getString("model", null) ?: BuildConfig.LIA_AI_MODEL.trim()
        set(value) { prefs.edit().putString("model", value).apply() }

    /** Último modelo que respondeu: a Lia tenta ele primeiro da próxima vez. */
    var lastGood: String
        get() = prefs.getString("lastGood", "") ?: ""
        set(value) { prefs.edit().putString("lastGood", value).apply() }

    fun clearKey() { prefs.edit().remove("gkey").apply() }

    /** "AIzaSy…ab12" / "AQ.Ab8…ab12": o suficiente para você reconhecer a chave, sem expô-la. */
    fun masked(): String {
        val k = apiKey
        return if (k.length <= 10) "" else k.take(6) + "…" + k.takeLast(4)
    }

    /** Modelos a tentar, em ordem. */
    fun modelsToTry(): List<String> {
        val forced = model.trim()
        if (forced.isNotEmpty()) return listOf(forced)
        return (listOf(lastGood).filter { it.isNotBlank() } + CHAIN).distinct()
    }

    /** Botão "Modelo": automático → cada modelo da lista → automático. */
    fun cycleModel() {
        val cur = model.trim()
        val choices = listOf("") + CHAIN
        val i = choices.indexOf(cur)
        model = choices[(if (i < 0) 0 else i + 1) % choices.size]
    }

    companion object {
        /**
         * Do mais rápido ao mais capaz. Os modelos antigos (1.5 e 2.0) já foram desligados pelo Google e o 2.5 está
         * em desligamento em 2026, então ficam por último. Um modelo que não existir (HTTP 404) é pulado sozinho.
         */
        val CHAIN = listOf(
            "gemini-3.5-flash-lite",
            "gemini-3.1-flash-lite",
            "gemini-3-flash-preview",
            "gemini-3.5-flash",
            "gemini-2.5-flash"
        )
    }
}
