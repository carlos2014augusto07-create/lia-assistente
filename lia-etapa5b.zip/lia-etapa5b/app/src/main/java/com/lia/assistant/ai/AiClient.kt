package com.lia.assistant.ai

import com.lia.assistant.LiaLog
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/** [role] = "user" ou "model" (é assim que o Gemini chama). */
data class Turn(val role: String, val text: String)

sealed interface AiResult {
    data class Ok(val text: String) : AiResult
    /** [spoken] = o que a Lia fala; [detail] = o motivo técnico, para o registro. */
    data class Fail(val spoken: String, val detail: String) : AiResult
}

/**
 * Fala com a API REST do Google Gemini. Bloqueante: chame fora da thread principal.
 *
 * Velocidade:
 *  - STREAMING: a resposta chega em pedaços e cada frase pronta é entregue na hora ([onSentence]),
 *    então a Lia começa a falar a 1ª frase sem esperar o texto inteiro.
 *  - Limite de espera: [FIRST_TEXT_DEADLINE_MS] (10 s) até chegar o primeiro texto. Passou disso, desiste e avisa.
 *  - Pensamento mínimo (thinking) e resposta curta (instrução + maxOutputTokens).
 *  - [warmUp] abre a conexão segura enquanto você ainda está falando.
 * Se um modelo não existir (404), estiver sem cota (429) ou sobrecarregado (503), tenta o próximo da lista.
 */
class AiClient {

    /** Aquece DNS + TLS para a conexão já estar pronta quando a pergunta chegar. Erros são ignorados. */
    fun warmUp() {
        runCatching {
            val c = URL("https://generativelanguage.googleapis.com/").openConnection() as HttpURLConnection
            c.connectTimeout = 4_000
            c.readTimeout = 4_000
            (if (c.responseCode in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes() }
            // sem disconnect(): a conexão volta para o "pool" e é reaproveitada no pedido real
        }
    }

    private class CallState {
        @Volatile var current: HttpURLConnection? = null
        @Volatile var timedOut = false
        @Volatile var emitted = 0
        @Volatile var firstMs = 0L
        val full = StringBuilder()
        var guard: ScheduledFuture<*>? = null
    }

    private sealed interface Attempt {
        data class Text(val full: String) : Attempt
        data class HttpError(val code: Int, val body: String) : Attempt
        data object NoText : Attempt
    }

    fun ask(
        apiKey: String,
        models: List<String>,
        history: List<Turn>,
        question: String,
        onSentence: (String) -> Unit,
        onModelOk: (String) -> Unit = {}
    ): AiResult {
        val start = System.currentTimeMillis()
        val st = CallState()
        fun remaining(total: Long) = total - (System.currentTimeMillis() - start)
        fun arm(ms: Long) {
            st.guard?.cancel(false)
            st.guard = timer.schedule({ st.timedOut = true; runCatching { st.current?.disconnect() } }, ms, TimeUnit.MILLISECONDS)
        }

        var lastFail: AiResult.Fail? = null
        try {
            for (model in models) {
                if (remaining(FIRST_TEXT_DEADLINE_MS) < 1_500) break
                var withThinking = true
                while (true) {
                    arm(remaining(FIRST_TEXT_DEADLINE_MS))
                    val body = buildBody(model, history, question, withThinking)
                    val attempt = stream(apiKey, model, body, st, onSentence) { arm(remaining(TOTAL_DEADLINE_MS)) }
                    when (attempt) {
                        is Attempt.Text -> {
                            LiaLog.d("Lia", "IA: $model respondeu (1ª frase em ${st.firstMs} ms, total ${System.currentTimeMillis() - start} ms)")
                            onModelOk(model)
                            return AiResult.Ok(cleanForSpeech(attempt.full))
                        }
                        Attempt.NoText -> {
                            LiaLog.w("Lia", "IA: $model devolveu resposta vazia")
                            lastFail = AiResult.Fail("Não consegui montar uma resposta para isso.", "resposta vazia ($model)")
                            break
                        }
                        is Attempt.HttpError -> {
                            val msg = errorMessage(attempt.body)
                            LiaLog.w("Lia", "IA: $model, erro HTTP ${attempt.code}: $msg")
                            val mapped = mapError(attempt.code, msg)
                            when {
                                mapped.fatal -> return mapped.fail
                                attempt.code == 400 && withThinking -> { withThinking = false; continue }  // sem a opção de "pensamento"
                                else -> { lastFail = mapped.fail; break }                                // próximo modelo
                            }
                        }
                    }
                }
            }
            return lastFail ?: AiResult.Fail(
                "A internet está lenta e não consegui a resposta a tempo. Tente de novo.", "sem tempo para tentar outro modelo"
            )
        } catch (e: IOException) {
            if (st.emitted > 0) {
                LiaLog.w("Lia", "IA: conexão caiu no meio da resposta; usando o que já chegou")
                return AiResult.Ok(cleanForSpeech(st.full.toString()))
            }
            return if (st.timedOut) {
                LiaLog.w("Lia", "IA: passou de ${FIRST_TEXT_DEADLINE_MS / 1000} s sem resposta")
                AiResult.Fail("A internet está lenta e não consegui a resposta a tempo. Tente de novo.", "tempo esgotado")
            } else {
                LiaLog.w("Lia", "IA: sem conexão (${e.javaClass.simpleName}: ${e.message})")
                AiResult.Fail("Estou sem conexão com a internet agora.", "rede: ${e.message}")
            }
        } catch (e: Exception) {
            LiaLog.e("Lia", "IA: erro inesperado (${e.javaClass.simpleName}: ${e.message})")
            return AiResult.Fail("Tive um problema para pensar nisso agora. Veja o registro no app.", "${e.message}")
        } finally {
            st.guard?.cancel(false)
        }
    }

    // ---------- pedido ----------

    private fun buildBody(model: String, history: List<Turn>, question: String, withThinking: Boolean): JSONObject {
        val contents = JSONArray()
        fun add(role: String, text: String) {
            contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        history.forEach { add(it.role, it.text) }
        add("user", question)

        val gen = JSONObject().put("maxOutputTokens", 512)
        if (withThinking) {
            when {
                // Gemini 3.x: nível de pensamento. Gemini 2.5: orçamento de pensamento (0 = desligado).
                "gemini-3" in model -> gen.put("thinkingConfig", JSONObject().put("thinkingLevel", "MINIMAL"))
                "gemini-2.5" in model -> gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
            }
        }
        return JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt()))))
            .put("contents", contents)
            .put("generationConfig", gen)
    }

    /** Lê a resposta em SSE. Cada frase completa vai para [onSentence] assim que chega. */
    private fun stream(
        apiKey: String,
        model: String,
        body: JSONObject,
        st: CallState,
        onSentence: (String) -> Unit,
        onFirstText: () -> Unit
    ): Attempt {
        val c = URL("$BASE/$model:streamGenerateContent?alt=sse").openConnection() as HttpURLConnection
        st.current = c
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 5_000
            c.readTimeout = 12_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", apiKey)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            if (code !in 200..299) {
                return Attempt.HttpError(code, c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "")
            }

            val pending = StringBuilder()
            val started = System.currentTimeMillis()
            c.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                while (true) {
                    val line = reader.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val json = line.removePrefix("data:").trim()
                    if (json.isEmpty()) continue
                    val piece = extractText(json)
                    if (piece.isNullOrEmpty()) continue
                    if (st.full.isEmpty()) onFirstText()          // chegou o 1º texto: troca para o prazo total
                    st.full.append(piece)
                    pending.append(piece)
                    drain(pending, false) { sentence -> st.emitted++; if (st.firstMs == 0L) st.firstMs = System.currentTimeMillis() - started; onSentence(sentence) }
                }
            }
            drain(pending, true) { sentence -> st.emitted++; if (st.firstMs == 0L) st.firstMs = System.currentTimeMillis() - started; onSentence(sentence) }
            return if (st.full.isBlank()) Attempt.NoText else Attempt.Text(st.full.toString())
        } finally {
            st.current = null
            runCatching { c.disconnect() }
        }
    }

    /** Pega só o texto (ignora partes de "pensamento"). null = pedaço que não é JSON. */
    private fun extractText(json: String): String? = try {
        val parts = JSONObject(json).optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
        buildString {
            if (parts != null) for (i in 0 until parts.length()) {
                val p = parts.optJSONObject(i) ?: continue
                if (!p.optBoolean("thought", false)) append(p.optString("text"))
            }
        }
    } catch (e: Exception) {
        null
    }

    /**
     * Separa frases completas do texto que vai chegando. Só corta em ". " "! " "? " (pontuação + espaço),
     * então "3.5" e "10h30" ficam inteiros, e junta frases muito curtas para a voz não falar picotado.
     */
    private fun drain(pending: StringBuilder, isFinal: Boolean, emit: (String) -> Unit) {
        while (true) {
            val s = pending.toString()
            val m = BOUNDARY.findAll(s).firstOrNull { it.groups[1]!!.range.last + 1 >= MIN_SENTENCE_CHARS }
            if (m == null) break
            val sentence = cleanForSpeech(s.substring(0, m.groups[1]!!.range.last + 1))
            pending.delete(0, m.range.last + 1)
            if (sentence.isNotEmpty()) emit(sentence)
        }
        if (isFinal) {
            val rest = cleanForSpeech(pending.toString())
            pending.setLength(0)
            if (rest.isNotEmpty()) emit(rest)
        }
    }

    // ---------- erros ----------

    private class Mapped(val fail: AiResult.Fail, val fatal: Boolean)

    private fun mapError(code: Int, msg: String): Mapped {
        fun fail(spoken: String, fatal: Boolean) = Mapped(AiResult.Fail(spoken, "HTTP $code: $msg"), fatal)
        return when {
            code == 400 && (msg.contains("API key not valid", true) || msg.contains("API_KEY_INVALID", true)) ->
                fail("O Google não aceitou a minha chave. Crie uma nova no AI Studio e cole no app.", true)
            code == 401 && msg.contains("ACCESS_TOKEN_TYPE_UNSUPPORTED", true) ->
                fail("O Google recusou o tipo desta chave. Apague as chaves antigas no AI Studio e crie uma nova pelo próprio site.", true)
            code == 401 -> fail("O Google não reconheceu a minha chave. Confira a chave na tela do app.", true)
            code == 403 -> fail("O Google negou o acesso com esta chave. Confira se a API Gemini está liberada para ela.", true)
            code == 404 -> fail("Esse modelo de inteligência artificial não está disponível para a sua chave.", false)
            code == 429 -> fail("Atingi o limite gratuito da inteligência artificial por agora. Tente de novo em um minuto.", false)
            code == 503 || code >= 500 -> fail("O serviço de inteligência artificial do Google está sobrecarregado. Tente de novo daqui a pouco.", false)
            else -> fail("O pedido à inteligência artificial foi recusado. Veja o registro no app.", false)
        }
    }

    private fun errorMessage(body: String): String = try {
        JSONObject(body).getJSONObject("error").optString("message", body.take(200))
    } catch (e: Exception) {
        body.take(200)
    }

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE, d 'de' MMMM 'de' yyyy, HH:mm", Locale.forLanguageTag("pt-BR")).format(Date())
        return """
            Você é a Lia, assistente de voz pessoal. Responda sempre em português do Brasil, de forma natural, simpática e direta.
            Suas respostas são FALADAS em voz alta: no máximo 2 ou 3 frases curtas, sem markdown, listas, emojis, links ou símbolos. Vá direto ao ponto, sem introdução nem rodeios. Escreva números e horas como se fala.
            Se não souber ou não tiver como saber (por exemplo notícias de agora ou previsão do tempo), diga isso em uma frase, sem inventar.
            Você não controla a TV nem aparelhos por esta resposta. Se pedirem, diga o comando: "abrir YouTube", "liga a luz" ou "descansar".
            Agora são: $now.
        """.trimIndent()
    }

    companion object {
        private val timer = Executors.newSingleThreadScheduledExecutor { r ->
            Thread(r, "lia-ai-timeout").apply { isDaemon = true }
        }

        private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models"
        const val FIRST_TEXT_DEADLINE_MS = 10_000L   // limite para chegar o primeiro texto
        const val TOTAL_DEADLINE_MS = 20_000L        // limite para a resposta inteira
        private const val MIN_SENTENCE_CHARS = 24

        private val BOUNDARY = Regex("([.!?…]+)\\s+")
        private val LINK = Regex("\\[([^\\]]+)\\]\\([^)]*\\)")
        private val URL_RX = Regex("https?://\\S+")
        private val BULLET = Regex("(?m)^\\s*[-•]\\s+")
        private val EMOJI = Regex("[\\x{1F300}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}]")
        private val MARKS = Regex("[*_#`>~|]+")

        /** Tira o que um sintetizador leria errado (markdown, links, emojis). */
        fun cleanForSpeech(s: String): String = s
            .replace(LINK, "\$1")
            .replace(URL_RX, "")
            .replace(BULLET, "")
            .replace(EMOJI, "")
            .replace(MARKS, "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
