package com.lia.assistant.voice

import android.content.Context
import android.media.AudioAttributes
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.lia.assistant.LiaLog as Log
import com.lia.assistant.BuildConfig
import java.util.Locale

private const val TAG = "Lia"

/**
 * A Lia falando pelo alto-falante do CELULAR (nunca pela TV: assim não pede foco de áudio nela).
 *
 * Três jeitos de falar:
 *  - speak(texto, done): fala um texto e avisa quando terminar (respostas dos comandos locais);
 *  - speakAck(texto): aviso curto ("Só um segundo.") que NÃO encerra a interação;
 *  - startStream / streamSentence / endStream: fala frase por frase à medida que a IA responde.
 *
 * Voz mais natural: escolhe a melhor voz pt-BR instalada, fala frase por frase com pausa curta entre elas,
 * ritmo um pouco mais calmo e corrige palavras que o motor lê mal (Wi-Fi, TV, ESP32).
 * Para fixar uma voz, veja o nome no Logcat/Registro e ponha em LIA_TTS_VOICE.
 */
class Speaker(ctx: Context) {

    private val appCtx = ctx.applicationContext
    private lateinit var tts: TextToSpeech
    @Volatile private var ready = false
    @Volatile private var failed = false
    private var pending: Pair<String, () -> Unit>? = null
    @Volatile private var finalId: String? = null
    @Volatile private var onFinished: (() -> Unit)? = null
    @Volatile private var ackId: String? = null
    @Volatile private var streamId: String? = null
    @Volatile private var streamCount = 0
    private var counter = 0

    init {
        tts = TextToSpeech(appCtx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                configure()
                ready = true
            } else {
                Log.w(TAG, "Voz do Android (TTS) indisponível")
                failed = true
            }
            pending?.let { (text, done) ->
                pending = null
                speak(text, done)
            }
        }
    }

    private fun configure() {
        tts.language = Locale.forLanguageTag("pt-BR")
        tts.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        tts.setSpeechRate(0.97f)
        tts.setPitch(1.0f)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { handleEnd(utteranceId, error = false) }

            @Deprecated("Exigido pela API antiga", ReplaceWith("onError(utteranceId, -1)"))
            override fun onError(utteranceId: String?) { handleEnd(utteranceId, error = true) }
        })
        val names = brVoices().joinToString { "${it.name} (q=${it.quality}${if (it.isNetworkConnectionRequired) ", rede" else ""})" }
        Log.d(TAG, "Vozes pt-BR disponíveis: $names")
    }

    private fun handleEnd(id: String?, error: Boolean) {
        if (id != null && id == ackId) { ackId = null; return }       // fim do aviso: não encerra nada
        finish(id, force = error)
    }

    private fun finish(id: String?, force: Boolean) {
        if (force || id == finalId) {
            val cb = onFinished
            onFinished = null
            finalId = null
            streamId = null
            cb?.invoke()
        }
    }

    private fun isOnline(): Boolean {
        val cm = appCtx.getSystemService(ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun brVoices(): List<Voice> =
        (runCatching { tts.voices }.getOrNull() ?: emptySet<Voice>())
            .filter { it.locale?.language == "pt" && it.locale?.country.equals("BR", ignoreCase = true) }
            .filter { it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true }

    private fun pickVoice(): Voice? {
        val online = isOnline()
        val candidates = brVoices().filter { online || !it.isNetworkConnectionRequired }
        val wanted = BuildConfig.LIA_TTS_VOICE
        return candidates.firstOrNull { wanted.isNotBlank() && it.name == wanted }
            ?: candidates.maxByOrNull { it.quality + if (it.isNetworkConnectionRequired) 100 else 0 }
    }

    private fun applyVoice() { pickVoice()?.let { runCatching { tts.voice = it } } }

    // ---------- falar um texto e avisar no fim ----------

    fun speak(text: String, done: () -> Unit) {
        if (failed) { done(); return }
        if (!ready) { pending = text to done; return }

        applyVoice()
        val sentences = Pronunciation.fix(text)
            .split(Regex("(?<=[.!?…])\\s+"))
            .filter { it.isNotBlank() }
        if (sentences.isEmpty()) { done(); return }

        val id = "lia-${++counter}"
        finalId = "$id-fim"
        onFinished = done

        sentences.forEachIndexed { i, sentence ->
            val last = i == sentences.lastIndex
            val queue = if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            val result = tts.speak(sentence, queue, null, if (last) "$id-fim" else "$id-$i")
            if (result != TextToSpeech.SUCCESS) { finish(null, force = true); return }
            if (!last) tts.playSilentUtterance(140, TextToSpeech.QUEUE_ADD, "$id-p$i")
        }
    }

    // ---------- aviso rápido ("Só um segundo.") ----------

    /** Fala o aviso já, sem esperar nada. A resposta de verdade entra na fila logo depois dele. */
    fun speakAck(text: String) {
        if (failed || !ready) return
        applyVoice()
        val id = "lia-ack-${++counter}"
        ackId = id
        if (tts.speak(Pronunciation.fix(text), TextToSpeech.QUEUE_FLUSH, null, id) != TextToSpeech.SUCCESS) ackId = null
    }

    // ---------- falar enquanto a IA ainda escreve ----------

    /** Prepara uma fala em streaming. [done] é chamado depois da última frase (ou se não der para falar). */
    fun startStream(done: () -> Unit) {
        onFinished = done
        finalId = null
        streamCount = 0
        streamId = "lia-${++counter}"
    }

    /** Pode ser chamado de qualquer thread. Entra na fila atrás do aviso e das frases anteriores. */
    fun streamSentence(text: String) {
        if (failed || !ready || text.isBlank()) return
        val id = streamId ?: return
        streamCount++
        tts.speak(Pronunciation.fix(text), TextToSpeech.QUEUE_ADD, null, "$id-$streamCount")
        tts.playSilentUtterance(120, TextToSpeech.QUEUE_ADD, "$id-p$streamCount")
    }

    /** Marca o fim: quando tudo que estava na fila terminar de ser falado, chama o [done] do startStream. */
    fun endStream() {
        val id = streamId ?: return
        if (failed || !ready || streamCount == 0) { finish(null, force = true); return }   // nada para falar
        finalId = "$id-fim"
        if (tts.playSilentUtterance(30, TextToSpeech.QUEUE_ADD, "$id-fim") != TextToSpeech.SUCCESS) finish(null, force = true)
    }

    /** Corta a fala na hora (usado ao pausar a Lia). Não chama o "done". */
    fun stop() {
        onFinished = null
        finalId = null
        ackId = null
        streamId = null
        runCatching { tts.stop() }
    }

    fun shutdown() {
        stop()
        runCatching { tts.shutdown() }
    }
}

/** Palavras que os motores de voz em português costumam ler errado. */
private object Pronunciation {
    private val FIXES = listOf(
        Regex("wi-?fi", RegexOption.IGNORE_CASE) to "uai-fai",
        Regex("\\bTV\\b") to "tevê",
        Regex("ESP32", RegexOption.IGNORE_CASE) to "ésse pê trinta e dois",
        Regex("youtube", RegexOption.IGNORE_CASE) to "iutúbi"
    )

    fun fix(text: String): String = FIXES.fold(text) { acc, (rx, to) -> rx.replace(acc, to) }
}
