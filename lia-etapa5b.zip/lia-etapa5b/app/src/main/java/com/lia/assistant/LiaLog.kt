package com.lia.assistant

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Faz o mesmo que android.util.Log e também guarda as últimas mensagens na memória,
 * para a tela principal mostrar o que está acontecendo (sem precisar de computador/Logcat).
 * Os outros arquivos usam: import com.lia.assistant.LiaLog as Log
 */
object LiaLog {
    private val lines = ArrayDeque<String>()
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    private fun add(level: String, msg: String) {
        lines.addLast("${clock.format(Date())} $level $msg")
        while (lines.size > 80) lines.removeFirst()
        LiaStatus.notifyChanged()
    }

    @Synchronized
    fun snapshot(): List<String> = lines.toList()

    fun d(tag: String, msg: String): Int { add("D", msg); return android.util.Log.d(tag, msg) }
    fun w(tag: String, msg: String): Int { add("AVISO", msg); return android.util.Log.w(tag, msg) }
    fun e(tag: String, msg: String): Int { add("ERRO", msg); return android.util.Log.e(tag, msg) }
}
