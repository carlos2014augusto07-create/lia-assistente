package com.lia.tv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log

private const val TAG = "LiaTV"
private const val CHANNEL_ID = "lia_tv"
private const val NOTIF_ID = 1

/** Depois que uma interação termina, a Lia espera este tempo sem ninguém falar antes de recolher. */
private const val IDLE_TIMEOUT_MS = 50_000L

/**
 * O "cérebro" da TV: servidor TCP + leitura de mídia + janela sobreposta.
 *
 * Modo AUTO: vídeo tocando → canto superior direito; senão → tela cheia.
 *
 * Inatividade (IDLE_TIMEOUT_MS = 50 s), contada a partir do fim de cada interação:
 *   - vídeo tocando  → a Lia some por completo;
 *   - menus / nada tocando → o painel recolhe e fica só a bolinha discreta no canto.
 * Se a pessoa falar de novo antes disso, o cronômetro é reiniciado.
 *
 * Modo escola: o celular manda SLEEP e a Lia some na hora (WAKE traz de volta só a bolinha).
 */
class LiaTvService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private lateinit var overlay: OverlayController
    private lateinit var server: LiaTvServer
    private lateinit var media: MediaWatcher
    private var nsdListener: NsdManager.RegistrationListener? = null

    private var started = false
    private var mediaActive = false

    private var forcedMode = TvMode.AUTO
    private var mediaState = MediaState.NONE
    private var liaState = LiaState.IDLE
    private var liaText = ""

    private var engaged = false       // o celular já falou com a TV pelo menos uma vez
    private var sleeping = false      // modo escola: nada na tela
    private var restReached = false   // os 50 s de inatividade já passaram
    private val restTimer = Runnable {
        restReached = true
        render()
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        overlay = OverlayController(this)
        server = LiaTvServer(
            token = BuildConfig.LIA_TOKEN,
            onCommand = { cmd -> main.post { handle(cmd) } },
            onClientConnected = { main.post { server.send(TvEvent.HelloOk(forcedMode, mediaState)) } }
        )
        media = MediaWatcher(this) { state, app ->
            mediaState = state
            server.send(TvEvent.Media(state, app))
            render()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        enterForeground()
        if (!started) {
            started = true
            server.start()
            registerNsd()
        }
        // Reabrir o app depois de ativar o acesso a notificações faz esta linha funcionar.
        if (!mediaActive) mediaActive = media.start()
        return START_STICKY
    }

    // ----- regra do modo -----

    private fun effectiveMode(): TvMode = when {
        forcedMode != TvMode.AUTO -> forcedMode
        mediaState == MediaState.PLAYING -> TvMode.CORNER_BUBBLE
        else -> TvMode.FULLSCREEN
    }

    /** Decide o que aparece na tela, em um só lugar. */
    private fun render() {
        when {
            sleeping || !engaged -> overlay.hide()
            liaState != LiaState.IDLE || !restReached -> overlay.show(liaState, liaText, effectiveMode())
            mediaState == MediaState.PLAYING -> overlay.hide()   // vídeo: some por completo
            else -> overlay.showDot()                            // menus: só a bolinha discreta
        }
    }

    private fun handle(cmd: TvCommand) {
        when (cmd) {
            is TvCommand.Show -> {
                engaged = true
                sleeping = false
                liaState = cmd.state
                liaText = cmd.text
                // Qualquer fala reinicia a contagem; ela só começa quando a interação termina (IDLE).
                main.removeCallbacks(restTimer)
                restReached = false
                if (cmd.state == LiaState.IDLE) main.postDelayed(restTimer, IDLE_TIMEOUT_MS)
                render()
            }
            is TvCommand.SetMode -> { forcedMode = cmd.mode; render() }
            TvCommand.Wake -> {
                engaged = true
                sleeping = false
                liaState = LiaState.IDLE
                liaText = ""
                main.removeCallbacks(restTimer)
                restReached = true          // acordou: vai direto para a bolinha discreta
                render()
            }
            TvCommand.Sleep, TvCommand.Hide -> {
                sleeping = true
                main.removeCallbacks(restTimer)
                render()
            }
            is TvCommand.OpenApp -> openApp(cmd.app)
            is TvCommand.Hello, TvCommand.Ping -> {}
        }
    }

    private fun openApp(key: String) {
        val pkg = APPS[key.lowercase()]
        if (pkg == null) {
            server.send(TvEvent.Error("app desconhecido: $key"))
            return
        }
        val intent = packageManager.getLeanbackLaunchIntentForPackage(pkg)
            ?: packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            server.send(TvEvent.Error("app não instalado: $pkg"))
            return
        }
        // Funciona em segundo plano porque a Lia TV tem a permissão de sobreposição.
        runCatching { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { Log.w(TAG, "Não consegui abrir $pkg: ${it.message}") }
    }

    // ----- anúncio na rede (celular acha a TV sozinho) -----

    private fun registerNsd() {
        val nsd = getSystemService(Context.NSD_SERVICE) as NsdManager
        val info = NsdServiceInfo().apply {
            serviceName = "Lia TV"
            serviceType = TV_SERVICE_TYPE
            port = TV_PORT
        }
        val l = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) { Log.d(TAG, "Anunciada na rede como ${i.serviceName}") }
            override fun onRegistrationFailed(i: NsdServiceInfo, errorCode: Int) { Log.w(TAG, "NSD falhou: $errorCode") }
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, errorCode: Int) {}
        }
        nsdListener = l
        runCatching { nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, l) }
    }

    // ----- serviço em primeiro plano -----

    private fun enterForeground() {
        val n = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Não foi possível iniciar em primeiro plano: ${e.message}")
        }
    }

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Lia TV", NotificationManager.IMPORTANCE_MIN)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification =
        Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_monochrome)
            .setContentTitle("Lia TV")
            .setContentText("Pronta para receber a Lia do celular")
            .setOngoing(true)
            .build()

    override fun onDestroy() {
        main.removeCallbacks(restTimer)
        server.stop()
        media.stop()
        overlay.hide()
        nsdListener?.let { l ->
            runCatching { (getSystemService(Context.NSD_SERVICE) as NsdManager).unregisterService(l) }
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.lia.tv.STOP"

        // Nomes dos pacotes dos apps de TV mais comuns.
        val APPS = mapOf(
            "youtube" to "com.google.android.youtube.tv",
            "netflix" to "com.netflix.ninja",
            "prime" to "com.amazon.amazonvideo.livingroom"
        )
    }
}
