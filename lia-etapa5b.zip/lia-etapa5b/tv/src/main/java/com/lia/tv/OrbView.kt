package com.lia.tv

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min
import kotlin.math.sin

/**
 * A bolinha da Lia, desenhada à mão (sem imagens, sem bibliotecas).
 * Só anima enquanto estiver na tela: ao sair da janela o animador é cancelado.
 */
class OrbView(ctx: Context) : View(ctx) {

    var state: LiaState = LiaState.IDLE
        set(value) {
            if (field != value) {
                field = value
                applyState()
            }
        }

    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 2f
    }
    private var c1 = 0
    private var c2 = 0
    private var phase = 0f

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        applyState()
    }

    private fun applyState() {
        when (state) {
            LiaState.IDLE -> { c1 = 0xFF7B8CFF.toInt(); c2 = 0xFF2A3380.toInt(); anim.duration = 4500 }
            LiaState.LISTENING -> { c1 = 0xFF3EE3FF.toInt(); c2 = 0xFF0A5F8C.toInt(); anim.duration = 1600 }
            LiaState.RESPONDING -> { c1 = 0xFFFFA45C.toInt(); c2 = 0xFFA62A52.toInt(); anim.duration = 900 }
        }
        ring.color = c1
        rebuildShaders()
        invalidate()
    }

    private fun withAlpha(color: Int, alpha: Int) = (color and 0x00FFFFFF) or (alpha shl 24)

    private fun rebuildShaders() {
        if (width == 0 || height == 0) return
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.55f
        body.shader = RadialGradient(
            cx - r * 0.25f, cy - r * 0.3f, r * 1.25f,
            intArrayOf(Color.WHITE, c1, c2), floatArrayOf(0f, 0.3f, 1f), Shader.TileMode.CLAMP
        )
        glow.shader = RadialGradient(
            cx, cy, r * 1.7f,
            intArrayOf(withAlpha(c1, 110), withAlpha(c1, 0)), floatArrayOf(0.3f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuildShaders()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.55f
        val t = (phase * 2.0 * Math.PI).toFloat()
        val scale = when (state) {
            LiaState.IDLE -> 1f + 0.03f * sin(t)
            LiaState.LISTENING -> 1f + 0.10f * sin(t)
            LiaState.RESPONDING -> 1f + 0.07f * sin(t * 2f)
        }

        canvas.drawCircle(cx, cy, r * 1.7f, glow)
        canvas.save()
        canvas.scale(scale, scale, cx, cy)
        canvas.drawCircle(cx, cy, r, body)
        canvas.restore()

        if (state != LiaState.IDLE) {
            for (i in 0..1) {
                val p = (phase + i * 0.5f) % 1f
                ring.alpha = ((1f - p) * 150).toInt()
                canvas.drawCircle(cx, cy, r * (1f + 0.9f * p), ring)
            }
        }
    }
}
