package com.lia.tv

import android.content.ComponentName
import android.content.Context
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.util.Log

private const val TAG = "LiaTV"
private const val SETTLE_MS = 1_500L

/**
 * Descobre se há vídeo tocando na TV lendo as sessões de mídia dos apps (YouTube, Netflix…).
 * Funciona com Shorts e anúncios também: para o Android, o anúncio é "tocando" do mesmo jeito.
 * Para não ficar piscando entre canto e tela cheia na troca de um vídeo para o próximo,
 * sair de "tocando" só vale depois de 1,5 s estável.
 */
class MediaWatcher(
    private val ctx: Context,
    private val onChange: (MediaState, String?) -> Unit
) {
    private val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val component = ComponentName(ctx, LiaNotificationListener::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private val tracked = HashMap<MediaSession.Token, Pair<MediaController, MediaController.Callback>>()

    private var last: Pair<MediaState, String?>? = null
    private var settling = false
    private val settle = Runnable {
        settling = false
        publish(compute())
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> track(list.orEmpty()) }

    /** false = falta ativar "acesso a notificações" para a Lia TV. */
    fun start(): Boolean = try {
        msm.addOnActiveSessionsChangedListener(sessionsListener, component, handler)
        track(msm.getActiveSessions(component))
        true
    } catch (e: SecurityException) {
        Log.w(TAG, "Sem acesso a notificações: não dá para saber se há vídeo tocando")
        false
    }

    fun stop() {
        handler.removeCallbacks(settle)
        runCatching { msm.removeOnActiveSessionsChangedListener(sessionsListener) }
        for ((c, cb) in tracked.values) runCatching { c.unregisterCallback(cb) }
        tracked.clear()
    }

    private fun track(list: List<MediaController>) {
        val tokens = list.mapNotNull { it.sessionToken }.toSet()
        for (gone in tracked.keys.filter { it !in tokens }) {
            tracked.remove(gone)?.let { (c, cb) -> runCatching { c.unregisterCallback(cb) } }
        }
        for (c in list) {
            val token = c.sessionToken ?: continue
            if (tracked.containsKey(token)) continue
            val cb = object : MediaController.Callback() {
                override fun onPlaybackStateChanged(state: PlaybackState?) = evaluate()
                override fun onSessionDestroyed() = evaluate()
            }
            c.registerCallback(cb, handler)
            tracked[token] = c to cb
        }
        evaluate()
    }

    private fun compute(): Pair<MediaState, String?> {
        var best = MediaState.NONE
        var app: String? = null
        for ((c, _) in tracked.values) {
            val m = when (c.playbackState?.state) {
                PlaybackState.STATE_PLAYING,
                PlaybackState.STATE_BUFFERING,
                PlaybackState.STATE_FAST_FORWARDING,
                PlaybackState.STATE_REWINDING -> MediaState.PLAYING
                PlaybackState.STATE_PAUSED -> MediaState.PAUSED
                else -> MediaState.NONE
            }
            if (m.ordinal > best.ordinal) {   // NONE < PAUSED < PLAYING
                best = m
                app = c.packageName
            }
        }
        return best to app
    }

    private fun evaluate() {
        val cur = compute()
        if (cur.first == MediaState.PLAYING) {
            settling = false
            handler.removeCallbacks(settle)
            publish(cur)
            return
        }
        if (settling) return
        if (last?.first == MediaState.PLAYING) {
            settling = true
            handler.postDelayed(settle, SETTLE_MS)
            return
        }
        publish(cur)
    }

    private fun publish(cur: Pair<MediaState, String?>) {
        if (cur == last) return
        last = cur
        onChange(cur.first, cur.second)
    }
}
