package com.lia.tv

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Tela simples da TV (controlável pelo controle remoto): mostra o que falta liberar
 * e liga o serviço. Sem layouts XML e sem bibliotecas, para ficar leve.
 */
class TvMainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

        status = TextView(this).apply {
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(24))
        }
        val title = TextView(this).apply {
            text = "Lia TV"
            textSize = 34f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(16))
        }
        val bOverlay = Button(this).apply {
            text = "1. Permitir sobreposição (Lia por cima do vídeo)"
            setOnClickListener {
                openSettings(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        val bNotif = Button(this).apply {
            text = "2. Permitir acesso a notificações (detectar vídeo tocando)"
            setOnClickListener { openSettings(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        val bRestart = Button(this).apply {
            text = "3. Reiniciar serviço"
            setOnClickListener { startLia(); refresh() }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF06070C.toInt())
            setPadding(dp(64), dp(32), dp(64), dp(32))
            addView(title)
            addView(status)
            addView(bOverlay)
            addView(bNotif)
            addView(bRestart)
        })
    }

    override fun onResume() {
        super.onResume()
        startLia()
        refresh()
    }

    private fun startLia() {
        startForegroundService(Intent(this, LiaTvService::class.java))
    }

    private fun refresh() {
        val overlayOk = Settings.canDrawOverlays(this)
        val notifOk = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true

        val sb = StringBuilder()
        sb.append(if (overlayOk) "✔ Sobreposição liberada\n" else "✘ Sobreposição NÃO liberada\n")
        sb.append(if (notifOk) "✔ Acesso a notificações liberado\n" else "✘ Acesso a notificações NÃO liberado\n")
        sb.append("\nO serviço fica rodando em segundo plano. Pode fechar esta tela.\n")
        if (!overlayOk || !notifOk) {
            sb.append("\nSe os botões não abrirem nada nesta TV, libere pelo computador com adb:\n")
            sb.append("adb shell appops set $packageName SYSTEM_ALERT_WINDOW allow\n")
            sb.append("adb shell cmd notification allow_listener $packageName/$packageName.LiaNotificationListener\n")
        }
        status.text = sb.toString()
    }

    private fun openSettings(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            status.text = "Esta TV não tem essa tela de ajustes. Use os comandos adb abaixo.\n\n" +
                "adb shell appops set $packageName SYSTEM_ALERT_WINDOW allow\n" +
                "adb shell cmd notification allow_listener $packageName/$packageName.LiaNotificationListener"
        }
    }
}
