package com.lia.tv

import android.service.notification.NotificationListenerService

/**
 * Não faz nada sozinho. Existe porque o Android só deixa um app ler as sessões de mídia
 * (YouTube, Netflix…) se ele tiver "acesso a notificações" ativado. É daí que a Lia descobre
 * se há vídeo tocando, para ir sozinha para o canto.
 */
class LiaNotificationListener : NotificationListenerService()
