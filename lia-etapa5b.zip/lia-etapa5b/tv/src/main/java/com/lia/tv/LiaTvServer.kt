package com.lia.tv

import android.util.Log
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest

private const val TAG = "LiaTV"

/**
 * Servidor TCP simples (JSON por linha). Aceita um celular por vez e só depois do HELLO com o token certo.
 * As mensagens chegam em threads próprias: quem usa deve repassar à thread principal.
 */
class LiaTvServer(
    private val token: String,
    private val onCommand: (TvCommand) -> Unit,
    private val onClientConnected: () -> Unit
) {
    @Volatile private var running = false
    private var serverSocket: ServerSocket? = null
    @Volatile private var client: Socket? = null
    private var out: BufferedWriter? = null

    fun start() {
        if (running) return
        running = true
        Thread({ acceptLoop() }, "lia-tv-accept").apply { isDaemon = true }.start()
    }

    fun stop() {
        running = false
        runCatching { serverSocket?.close() }
        runCatching { client?.close() }
    }

    fun send(event: TvEvent) {
        synchronized(this) {
            try {
                out?.let {
                    it.write(event.toJson())
                    it.write("\n")
                    it.flush()
                }
            } catch (_: IOException) {
            }
        }
    }

    private fun acceptLoop() {
        try {
            val ss = ServerSocket(TV_PORT)
            serverSocket = ss
            Log.d(TAG, "Servidor ouvindo na porta $TV_PORT")
            while (running) {
                val s = ss.accept()
                runCatching { client?.close() }          // só um celular por vez
                client = s
                Thread({ serve(s) }, "lia-tv-client").apply { isDaemon = true }.start()
            }
        } catch (e: IOException) {
            if (running) Log.e(TAG, "Servidor parou: ${e.message}")
        }
    }

    private fun serve(s: Socket) {
        try {
            s.soTimeout = 90_000   // o celular fecha antes (45 s sem uso); isto só limpa conexões mortas
            val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
            val writer = BufferedWriter(OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8))

            val hello = reader.readLine()?.let(::parseCommand) as? TvCommand.Hello
            if (hello == null || !MessageDigest.isEqual(hello.token.toByteArray(), token.toByteArray())) {
                writer.write(TvEvent.Error("token").toJson())
                writer.write("\n")
                writer.flush()
                return
            }
            synchronized(this) { out = writer }
            onClientConnected()

            while (true) {
                val line = reader.readLine() ?: break
                val cmd = parseCommand(line) ?: continue
                if (cmd is TvCommand.Ping) send(TvEvent.Pong) else onCommand(cmd)
            }
        } catch (_: IOException) {
        } finally {
            synchronized(this) { if (client === s) out = null }
            runCatching { s.close() }
        }
    }
}
