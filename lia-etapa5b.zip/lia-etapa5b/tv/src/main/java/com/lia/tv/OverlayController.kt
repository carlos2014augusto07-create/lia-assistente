package com.lia.tv

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

private const val TAG = "LiaTV"
private const val CORNER_MAX_CHARS = 60

/**
 * Desenha a Lia numa JANELA SOBREPOSTA (não numa Activity).
 * Esta é a regra que impede de pausar vídeos: a janela é "não focável" e "não tocável",
 * então o YouTube continua sendo o app em foco e nunca recebe sinal de pausa.
 *
 * Três aparências:
 *   FULL   = painel em tela cheia (menus, nada tocando)
 *   CORNER = bolinha + balão de texto no canto superior direito (vídeo tocando)
 *   DOT    = só a bolinha discreta no canto (repouso nos menus)
 * Quem decide QUANDO mostrar, recolher ou sumir é o LiaTvService (inclusive os 50 s de inatividade).
 * Tudo aqui roda na thread principal.
 */
class OverlayController(private val ctx: Context) {

    private enum class Kind { FULL, CORNER, DOT }

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val orb = OrbView(ctx)
    private val label = TextView(ctx).apply {
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        maxLines = 3
        ellipsize = TextUtils.TruncateAt.END
    }
    private val root = LinearLayout(ctx).apply { gravity = Gravity.CENTER }

    private var attached = false
    private var shownKind: Kind? = null

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    /** Painel ativo. [mode] já vem resolvido (FULLSCREEN ou CORNER_BUBBLE). */
    fun show(state: LiaState, text: String, mode: TvMode) {
        present(if (mode == TvMode.CORNER_BUBBLE) Kind.CORNER else Kind.FULL, state, text)
    }

    /** Repouso nos menus: só a bolinha discreta no canto. */
    fun showDot() = present(Kind.DOT, LiaState.IDLE, "")

    fun hide() {
        if (!attached) return
        attached = false
        shownKind = null
        root.animate().alpha(0f).setDuration(180).withEndAction {
            if (!attached) runCatching { wm.removeViewImmediate(root) }
        }.start()
    }

    private fun present(kind: Kind, state: LiaState, text: String) {
        if (!Settings.canDrawOverlays(ctx)) {
            Log.w(TAG, "Sem permissão de sobreposição: a Lia não pode aparecer na tela")
            return
        }
        orb.state = state
        label.text = if (kind == Kind.CORNER && text.length > CORNER_MAX_CHARS)
            text.take(CORNER_MAX_CHARS - 1) + "…" else text
        label.visibility = if (kind == Kind.DOT || label.text.isEmpty()) View.GONE else View.VISIBLE
        if (!attached || shownKind != kind) layout(kind)
    }

    private fun layout(kind: Kind) {
        val full = kind == Kind.FULL

        root.removeAllViews()
        root.orientation = if (full) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        root.setBackgroundColor(if (full) 0xE606070C.toInt() else Color.TRANSPARENT)

        val orbSize = dp(when (kind) { Kind.FULL -> 220; Kind.CORNER -> 52; Kind.DOT -> 34 })
        orb.layoutParams = LinearLayout.LayoutParams(orbSize, orbSize)
        orb.alpha = if (kind == Kind.DOT) 0.8f else 1f

        label.textSize = if (full) 30f else 16f
        label.maxWidth = dp(if (full) 900 else 420)
        label.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { if (!full) marginEnd = dp(10) }
        if (full) {
            label.background = null
            label.setPadding(dp(32), dp(24), dp(32), 0)
        } else {
            label.background = GradientDrawable().apply {
                setColor(0xE611131C.toInt())
                cornerRadius = dp(14).toFloat()
            }
            label.setPadding(dp(14), dp(8), dp(14), dp(8))
        }

        if (full) { root.addView(orb); root.addView(label) } else { root.addView(label); root.addView(orb) }

        val params = windowParams(full)
        if (attached) {
            wm.updateViewLayout(root, params)
        } else {
            root.animate().cancel()
            runCatching { wm.removeViewImmediate(root) }   // caso o fade-out anterior ainda não tenha terminado
            root.alpha = 0f
            wm.addView(root, params)
            attached = true
            root.animate().alpha(1f).setDuration(150).start()
        }
        shownKind = kind
    }

    private fun windowParams(full: Boolean): WindowManager.LayoutParams {
        // Sem FLAG_NOT_FOCUSABLE o vídeo perderia o foco e pausaria. Nunca remova estas flags.
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

        return if (full) {
            WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
            )
        } else {
            WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = dp(32)
                y = dp(24)
            }
        }
    }
}
