import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

fun setting(name: String, default: String = ""): String =
    System.getenv(name)?.takeIf { it.isNotBlank() }
        ?: (project.findProperty(name) as String?)?.takeIf { it.isNotBlank() }
        ?: default

android {
    namespace = "com.lia.tv"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.lia.tv"
        minSdk = 26
        targetSdk = 36
        versionCode = 6
        versionName = "0.5.0"

        buildConfigField("String", "LIA_TOKEN", "\"${setting("LIA_TOKEN", "lia-dev")}\"")
    }

    signingConfigs {
        // Chave de debug FIXA (debug.keystore na raiz): todo build sai com a mesma assinatura,
        // então o APK novo instala por cima do antigo sem precisar desinstalar.
        getByName("debug") {
            storeFile = rootProject.file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildFeatures { buildConfig = true }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
}
