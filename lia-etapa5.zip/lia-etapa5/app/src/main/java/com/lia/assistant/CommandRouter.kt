package com.lia.assistant

import com.lia.assistant.ai.AiAssistant
import com.lia.assistant.esp.Esp32Manager
import com.lia.assistant.net.TvMode
import com.lia.assistant.tv.TvManager

/** [sleep] = depois de falar, a Lia entra em descanso (microfone desligado, bolinha some). */
data class Reply(val text: String, val sleep: Boolean = false)

/**
 * Primeiro tenta as regras locais (rápidas, funcionam sem internet): modo escola, TV, luz...
 * O que não for comando vai para a IA. Por isso as regras locais só valem para frases CURTAS e exatas,
 * senão "como desativo o alarme?" viraria "desativar a Lia".
 */
class CommandRouter(
    private val tv: TvManager,
    private val esp: Esp32Manager,
    private val ai: AiAssistant
) {

    suspend fun handle(raw: String, onThinking: suspend () -> Unit = {}): Reply {
        val t = normalize(raw)
        val words = t.split(" ").filter { it.isNotEmpty() }
        val short = words.size <= 6

        if (SLEEP.matches(t)) return Reply("Tá bom, até logo!", sleep = true)

        val app = APPS.firstOrNull { it.first in t }
        val text = when {
            short && app != null && words.any { it in OPEN_WORDS } -> {
                tv.openApp(app.first)
                "Abrindo ${app.second} na TV."
            }
            short && "modo automatico" in t -> { tv.setMode(TvMode.AUTO); "Modo automático ligado." }
            short && "tela cheia" in t -> { tv.setMode(TvMode.FULLSCREEN); "Tela cheia." }
            short && "modo" in words && ("canto" in words || "discreto" in words) -> {
                tv.setMode(TvMode.CORNER_BUBBLE); "Modo discreto no canto."
            }
            words.size <= 3 && words.firstOrNull() == "status" -> tv.status()
            else -> esp.handle(t) ?: ai.answer(raw, onThinking)
        }
        return Reply(text)
    }

    private companion object {
        val SLEEP = Regex(
            "^(lia )?(pode |vai |vamos )?(descansar|descansa|dormir|desativar|desativa|tchau|ate logo|ate mais|modo escola)( lia| agora| um pouco)?$"
        )
        val OPEN_WORDS = setOf("abrir", "abre", "abra")

        // chave enviada à TV → como a Lia fala
        val APPS = listOf(
            "youtube" to "o YouTube",
            "netflix" to "a Netflix",
            "prime" to "o Prime Video"
        )
    }
}
