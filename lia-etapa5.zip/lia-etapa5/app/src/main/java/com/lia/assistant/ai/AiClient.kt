package com.lia.assistant.ai

import com.lia.assistant.LiaLog
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Turn(val role: String, val text: String)

sealed interface AiResult {
    data class Ok(val text: String) : AiResult
    /** [spoken] = o que a Lia fala; [detail] = o motivo técnico, para o registro. */
    data class Fail(val spoken: String, val detail: String) : AiResult
}

/**
 * Fala com a API de mensagens da Anthropic (Claude) por HTTPS. Bloqueante: chame fora da thread principal.
 *
 * Pedido "enxuto" para voz: sem raciocínio estendido (thinking desativado) e esforço baixo, para a resposta vir rápido.
 * Se o modelo recusar esses parâmetros (HTTP 400), repete com o pedido simples.
 * Sem temperature/top_p/top_k e sem "prefill": os modelos 5.x recusam.
 */
class AiClient {

    fun ask(apiKey: String, model: String, history: List<Turn>, question: String): AiResult {
        return try {
            var raw = post(buildBody(model, history, question, lean = true), apiKey)
            if (raw.code == 400 && !raw.body.contains("credit balance", ignoreCase = true)) {
                LiaLog.w("Lia", "IA: pedido enxuto recusado (${errorMessage(raw.body)}); tentando o pedido simples")
                raw = post(buildBody(model, history, question, lean = false), apiKey)
            }
            interpret(raw)
        } catch (e: IOException) {
            LiaLog.w("Lia", "IA: sem conexão (${e.javaClass.simpleName}: ${e.message})")
            AiResult.Fail("Estou sem conexão com a internet agora.", "rede: ${e.message}")
        } catch (e: Exception) {
            LiaLog.e("Lia", "IA: erro inesperado (${e.javaClass.simpleName}: ${e.message})")
            AiResult.Fail("Tive um problema para pensar nisso agora. Veja o registro no app.", "${e.message}")
        }
    }

    private class Raw(val code: Int, val body: String)

    private fun buildBody(model: String, history: List<Turn>, question: String, lean: Boolean): JSONObject {
        val messages = JSONArray()
        history.forEach { messages.put(JSONObject().put("role", it.role).put("content", it.text)) }
        messages.put(JSONObject().put("role", "user").put("content", question))

        val body = JSONObject()
            .put("model", model)
            .put("system", systemPrompt())
            .put("messages", messages)
        if (lean) {
            body.put("max_tokens", 1024)
            body.put("thinking", JSONObject().put("type", "disabled"))
            body.put("output_config", JSONObject().put("effort", "low"))
        } else {
            body.put("max_tokens", 4096)   // o raciocínio automático também conta nesse limite
        }
        return body
    }

    private fun post(body: JSONObject, apiKey: String): Raw {
        val c = URL(ENDPOINT).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 8_000
            c.readTimeout = 40_000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", apiKey)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Raw(code, text)
        } finally {
            c.disconnect()
        }
    }

    private fun interpret(raw: Raw): AiResult {
        if (raw.code in 200..299) {
            val text = extractText(raw.body)
            return if (text.isNullOrBlank()) {
                LiaLog.w("Lia", "IA: resposta sem texto")
                AiResult.Fail("Não consegui montar uma resposta agora.", "resposta sem bloco de texto")
            } else {
                AiResult.Ok(cleanForSpeech(text))
            }
        }

        val msg = errorMessage(raw.body)
        LiaLog.w("Lia", "IA: erro HTTP ${raw.code}: $msg")
        val spoken = when {
            raw.code == 401 || raw.code == 403 ->
                "A minha chave de inteligência artificial não foi aceita. Confira a chave na tela do app."
            raw.code == 429 ->
                "Estou recebendo pedidos demais agora. Tente de novo em instantes."
            raw.code == 404 ->
                "O modelo de inteligência artificial escolhido não está disponível para a sua conta."
            msg.contains("credit balance", ignoreCase = true) ->
                "A conta da inteligência artificial está sem crédito. Adicione saldo no site da Anthropic."
            raw.code == 529 || raw.code >= 500 ->
                "O serviço de inteligência artificial está instável agora. Tente de novo daqui a pouco."
            else ->
                "O pedido à inteligência artificial foi recusado. Veja o registro no app."
        }
        return AiResult.Fail(spoken, "HTTP ${raw.code}: $msg")
    }

    /** Junta só os blocos de texto: a resposta pode começar com blocos de raciocínio. */
    private fun extractText(body: String): String? = try {
        val content = JSONObject(body).getJSONArray("content")
        buildString {
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") append(block.optString("text"))
            }
        }
    } catch (e: Exception) {
        null
    }

    private fun errorMessage(body: String): String = try {
        JSONObject(body).getJSONObject("error").optString("message", body.take(200))
    } catch (e: Exception) {
        body.take(200)
    }

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE, d 'de' MMMM 'de' yyyy, HH:mm", Locale.forLanguageTag("pt-BR")).format(Date())
        return """
            Você é a Lia, uma assistente de voz pessoal. Fale sempre em português do Brasil, de forma natural, simpática e direta.
            Suas respostas serão FALADAS em voz alta por um sintetizador de voz: use no máximo três frases curtas, sem markdown, sem listas, sem emojis, sem links e sem símbolos. Escreva números, horas e unidades do jeito que se fala, por exemplo "três e meia" ou "vinte graus".
            Se a pergunta for ambígua, faça uma pergunta curta de volta. Se não souber ou não tiver como saber, por exemplo notícias de agora ou a previsão do tempo, porque você não tem acesso à internet em tempo real, diga isso com honestidade em vez de inventar.
            Você não controla a TV nem os aparelhos da casa por esta conversa. Se a pessoa pedir algo assim, diga o comando que ela pode falar: "abrir YouTube", "liga a luz", "desliga o ventilador", "tela cheia", "modo discreto no canto" ou "descansar".
            Agora são: $now.
        """.trimIndent()
    }

    companion object {
        private const val ENDPOINT = "https://api.anthropic.com/v1/messages"

        private val LINK = Regex("\\[([^\\]]+)\\]\\([^)]*\\)")
        private val URL_RX = Regex("https?://\\S+")
        private val BULLET = Regex("(?m)^\\s*[-•]\\s+")
        private val EMOJI = Regex("[\\x{1F300}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}]")
        private val MARKS = Regex("[*_#`>~|]+")

        /** Tira o que um sintetizador leria errado (markdown, links, emojis). */
        fun cleanForSpeech(s: String): String = s
            .replace(LINK, "\$1")
            .replace(URL_RX, "")
            .replace(BULLET, "")
            .replace(EMOJI, "")
            .replace(MARKS, "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
