package com.lia.assistant

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.lia.assistant.ai.AiClient
import com.lia.assistant.ai.AiResult
import com.lia.assistant.ai.AiSettings
import com.lia.assistant.net.LiaState
import com.lia.assistant.ui.OrbView

/**
 * Tela principal da Lia. Ela NÃO fecha sozinha: mostra o estado, permite testar e
 * mostra qualquer erro. O trabalho de verdade continua no LiaService (segundo plano).
 * Visual montado em código (sem XML e sem bibliotecas), para ficar leve.
 */
class MainActivity : ComponentActivity() {

    private val bg = 0xFF06070C.toInt()
    private val panel = 0xFF10121B.toInt()
    private val line = 0xFF252A3D.toInt()
    private val ink = 0xFFE9EBF7.toInt()
    private val muted = 0xFF8B90A8.toInt()
    private val accent = 0xFF3EE3FF.toInt()
    private val danger = 0xFFFF8A80.toInt()

    private lateinit var orb: OrbView
    private lateinit var stateView: TextView
    private lateinit var lastView: TextView
    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var crashCard: LinearLayout
    private lateinit var crashView: TextView
    private lateinit var micBtn: Button
    private lateinit var pauseBtn: Button
    private lateinit var input: EditText
    private lateinit var aiKeyInput: EditText
    private lateinit var aiInfo: TextView
    private lateinit var modelBtn: Button

    private val onStatus: () -> Unit = { refresh() }

    private val askPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val micDenied = result.isNotEmpty() && result[Manifest.permission.RECORD_AUDIO] == false
            if (micDenied && !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                // "Não perguntar de novo": só dá para liberar nas configurações do app.
                toast("Libere o microfone nas configurações do app.")
                openAppSettings()
            }
            ensureService()
            refresh()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        requestMissingPermissionsOrStart()
    }

    override fun onStart() {
        super.onStart()
        LiaStatus.add(onStatus)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        // Voltou das configurações com o microfone liberado: liga a Lia.
        if (micGranted() && !LiaService.running) ensureService()
        refresh()
    }

    override fun onStop() {
        LiaStatus.remove(onStatus)
        super.onStop()
    }

    // ---------- permissões e serviço ----------

    private fun micGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun notifGranted() = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun requestMissingPermissionsOrStart() {
        val missing = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT >= 37) add("android.permission.ACCESS_LOCAL_NETWORK")
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }

        if (missing.isEmpty()) ensureService() else askPermissions.launch(missing.toTypedArray())
    }

    /** Liga o serviço (só com o microfone liberado). Pode ser chamado várias vezes sem problema. */
    private fun ensureService() {
        if (!micGranted()) return
        sendToService(null, null)
    }

    private fun sendToService(action: String?, text: String?) {
        if (!micGranted()) { toast("Libere o microfone primeiro."); return }
        try {
            val i = Intent(this, LiaService::class.java)
            if (action != null) i.action = action
            if (text != null) i.putExtra(LiaService.EXTRA_TEXT, text)
            ContextCompat.startForegroundService(this, i)
        } catch (e: Throwable) {
            LiaLog.e("Lia", "Não consegui iniciar o serviço: ${e.message}")
            toast("Não consegui iniciar a Lia. Veja o registro abaixo.")
        }
        refresh()
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    // ---------- tela ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, stroke: Int = line) = GradientDrawable().apply {
        setColor(fill)
        setStroke(dp(1), stroke)
        cornerRadius = dp(14).toFloat()
    }

    private fun text(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(ink)
        background = rounded(panel)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setOnClickListener { onClick() }
    }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEachIndexed { i, v ->
            addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) marginStart = dp(8)
            })
        }
    }

    private fun card(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(panel)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        views.forEach { addView(it) }
    }

    private fun gap(h: Int = 12) = View(this).apply { minimumHeight = dp(h) }

    private fun buildUi(): View {
        val version = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull() ?: ""

        orb = OrbView(this)
        stateView = text(16f, ink, bold = true).apply { gravity = Gravity.CENTER }
        lastView = text(15f, muted).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(4), dp(8), 0) }

        micBtn = button("Permitir microfone") { requestMissingPermissionsOrStart() }
        pauseBtn = button("Descansar") {
            sendToService(if (LiaPrefs.isPaused(this)) LiaService.ACTION_RESUME else LiaService.ACTION_PAUSE, null)
        }
        val listenBtn = button("Ouvir agora") { sendToService(LiaService.ACTION_SIMULATE_WAKE, null) }
        val stopBtn = button("Parar a Lia") {
            stopService(Intent(this, LiaService::class.java))   // parar não pode usar startForegroundService
            refresh()
        }
        val batteryBtn = button("Bateria: sem restrições") {
            runCatching { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                .onFailure { openAppSettings() }
        }

        input = EditText(this).apply {
            hint = "Digite um comando (ex.: status)"
            setHintTextColor(muted)
            setTextColor(ink)
            textSize = 16f
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            background = rounded(panel)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setSingleLine()
            setOnEditorActionListener { _, _, _ -> sendTyped(); true }
        }
        val sendBtn = button("Enviar") { sendTyped() }
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(sendBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
        }

        statusView = text(14f, ink).apply { setLineSpacing(0f, 1.25f) }
        logView = text(12f, muted).apply { typeface = android.graphics.Typeface.MONOSPACE }
        val copyLog = button("Copiar registro") { copy(LiaLog.snapshot().reversed().joinToString("\n")) }

        crashView = text(12f, ink).apply { typeface = android.graphics.Typeface.MONOSPACE }
        val copyCrash = button("Copiar erro") { CrashLog.read(this)?.let { copy(it) } }
        val clearCrash = button("Apagar") { CrashLog.clear(this); refresh() }
        crashCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, danger)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            addView(text(15f, danger, bold = true).apply { text = "O app fechou por erro na última vez" })
            addView(text(13f, muted).apply { text = "Copie e envie este texto para corrigirmos:" })
            addView(crashView)
            addView(gap(8))
            addView(row(copyCrash, clearCrash))
        }

        // ----- cartão da inteligência artificial -----
        aiInfo = text(13f, muted).apply { setLineSpacing(0f, 1.2f) }
        aiKeyInput = EditText(this).apply {
            hint = "Cole aqui a chave da API (sk-ant-…)"
            setHintTextColor(muted)
            setTextColor(ink)
            textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            background = rounded(bg)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setSingleLine()
        }
        val saveKey = button("Salvar chave") {
            val k = aiKeyInput.text.toString().trim()
            if (k.isEmpty()) {
                toast("Cole a chave primeiro.")
            } else {
                AiSettings(this).apiKey = k
                aiKeyInput.text.clear()
                toast("Chave salva neste aparelho.")
                refresh()
            }
        }
        val removeKey = button("Apagar chave") { AiSettings(this).clearKey(); toast("Chave apagada."); refresh() }
        modelBtn = button("") {
            val s = AiSettings(this)
            s.model = if (s.model == AiSettings.MODEL_FAST) AiSettings.MODEL_SMART else AiSettings.MODEL_FAST
            refresh()
        }
        val testBtn = button("Testar a IA") { testAi() }
        val aiCard = card(
            text(15f, ink, bold = true).apply { text = "Inteligência artificial" },
            gap(4), aiInfo, gap(8), aiKeyInput, gap(8),
            row(saveKey, removeKey), gap(8), row(modelBtn, testBtn)
        )

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
            addView(text(24f, ink, bold = true).apply { text = "Lia" })
            addView(text(13f, muted).apply { text = "assistente de voz  ·  versão $version" })
            addView(gap(8))
            addView(crashCard)
            addView(orb, LinearLayout.LayoutParams(dp(150), dp(150)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dp(20); bottomMargin = dp(20)
            })
            addView(stateView)
            addView(lastView)
            addView(gap(16))
            addView(row(listenBtn, pauseBtn))
            addView(gap(8))
            addView(micBtn)
            addView(gap(8))
            addView(inputRow)
            addView(gap(16))
            addView(card(text(15f, ink, bold = true).apply { text = "Situação" }, gap(6), statusView, gap(10), row(batteryBtn, stopBtn)))
            addView(gap(12))
            addView(aiCard)
            addView(gap(12))
            addView(card(text(15f, ink, bold = true).apply { text = "Registro" }, gap(6), logView, gap(10), copyLog))
        }

        return ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
            clipToPadding = false
            addView(content)
            // A tela desenha atrás das barras do sistema (Android 15+): empurra o conteúdo para dentro.
            ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
                val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
                val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
                v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
                insets
            }
        }
    }

    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.text.clear()
        if (LiaPrefs.isPaused(this)) toast("A Lia está descansando. Toque em Acordar.")
        sendToService(LiaService.ACTION_COMMAND, t)
    }

    private fun refresh() {
        if (!::orb.isInitialized) return
        val running = LiaService.running
        val paused = LiaPrefs.isPaused(this)
        val active = running && !paused

        orb.state = if (active) LiaStatus.state else LiaState.IDLE
        orb.alpha = if (active) 1f else 0.35f

        stateView.text = when {
            !running -> "Parada"
            paused -> "Descansando (microfone desligado)"
            else -> when (LiaStatus.state) {
                LiaState.IDLE -> "Em espera"
                LiaState.LISTENING -> "Ouvindo…"
                LiaState.RESPONDING -> "Respondendo…"
            }
        }
        lastView.text = LiaStatus.text.ifBlank { "Toque em “Ouvir agora” e fale, ou digite um comando." }
        pauseBtn.text = if (paused) "Acordar" else "Descansar"
        micBtn.visibility = if (micGranted()) View.GONE else View.VISIBLE

        statusView.text = listOf(
            "Microfone: " + if (micGranted()) "permitido ✔" else "NÃO permitido ✘",
            "Notificações: " + if (notifGranted()) "permitidas ✔" else "não permitidas (a Lia funciona, mas não mostra o aviso)",
            "Serviço: " + if (running) "rodando ✔" else "parado ✘",
            LiaStatus.wakeInfo,
            LiaStatus.tvInfo,
            aiStatusLine()
        ).joinToString("\n")

        val ai = AiSettings(this)
        val smart = ai.model == AiSettings.MODEL_SMART
        modelBtn.text = if (smart) "Modelo: mais inteligente" else "Modelo: rápido"
        aiInfo.text = if (ai.apiKey.isBlank())
            "Sem chave. Crie uma em console.anthropic.com, cole acima e toque em Salvar. A chave fica só neste aparelho."
        else
            "Chave salva (${ai.masked()}). Modelo: ${ai.model}. O que você falar e não for comando vai para a IA pela internet."

        logView.text = LiaLog.snapshot().takeLast(30).reversed().joinToString("\n").ifEmpty { "Sem mensagens ainda." }

        val crash = CrashLog.read(this)
        crashCard.visibility = if (crash != null) View.VISIBLE else View.GONE
        crashView.text = crash?.take(1800) ?: ""
    }

    private fun aiStatusLine(): String {
        val ai = AiSettings(this)
        return "IA: " + if (ai.apiKey.isBlank()) "sem chave ✘ (cadastre abaixo)" else "pronta ✔"
    }

    /** Faz uma pergunta curta à IA, fora da thread principal, e mostra o resultado e o registro. */
    private fun testAi() {
        val ai = AiSettings(this)
        if (ai.apiKey.isBlank()) { toast("Cadastre a chave primeiro."); return }
        toast("Testando a IA…")
        Thread {
            val r = AiClient().ask(ai.apiKey, ai.model, emptyList(), "Diga olá em uma frase curta e diga que está funcionando.")
            val msg = when (r) {
                is AiResult.Ok -> "IA respondeu: ${r.text}"
                is AiResult.Fail -> "IA falhou: ${r.detail}"
            }
            LiaLog.d("Lia", msg)
            runOnUiThread {
                LiaStatus.set(LiaStatus.state, msg)
                toast(if (r is AiResult.Ok) "A IA está funcionando ✔" else "A IA falhou. Veja o registro.")
            }
        }.start()
    }

    private fun copy(text: String) {
        getSystemService(Context.CLIPBOARD_SERVICE).let { it as ClipboardManager }
            .setPrimaryClip(ClipData.newPlainText("Lia", text))
        toast("Copiado.")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
