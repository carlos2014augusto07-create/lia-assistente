package com.lia.assistant.ai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Responde o que as regras locais (TV, luz, modo) não cobrem, lembrando das últimas trocas da conversa. */
class AiAssistant(ctx: Context) {

    private val settings = AiSettings(ctx)
    private val client = AiClient()
    private val history = ArrayList<Turn>()
    private var lastAt = 0L

    suspend fun answer(question: String, onThinking: suspend () -> Unit): String {
        val key = settings.apiKey
        if (key.isBlank()) {
            return "Para eu responder perguntas, cadastre a minha chave de inteligência artificial na tela principal do app."
        }
        onThinking()

        val now = System.currentTimeMillis()
        if (now - lastAt > CONVERSATION_MEMORY_MS) history.clear()   // 10 min parada: começa conversa nova

        val result = withContext(Dispatchers.IO) {
            client.ask(key, settings.model, history.toList(), question)
        }
        return when (result) {
            is AiResult.Ok -> {
                history.add(Turn("user", question))
                history.add(Turn("assistant", result.text))
                while (history.size > MAX_TURNS) { history.removeAt(0); history.removeAt(0) }
                lastAt = now
                result.text
            }
            is AiResult.Fail -> result.spoken
        }
    }

    private companion object {
        const val MAX_TURNS = 12                       // 6 trocas de ida e volta
        const val CONVERSATION_MEMORY_MS = 10 * 60_000L
    }
}
