package com.lia.assistant.ai

import android.content.Context
import com.lia.assistant.BuildConfig

/**
 * Chave e modelo da IA. A chave digitada no app fica só na memória privada do aparelho
 * (não vai para o GitHub nem dentro do APK). BuildConfig.LIA_AI_KEY é só um plano B, não recomendado.
 */
class AiSettings(ctx: Context) {
    private val prefs = ctx.applicationContext.getSharedPreferences("lia_ai", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString("key", null)?.trim()?.takeIf { it.isNotEmpty() } ?: BuildConfig.LIA_AI_KEY.trim()
        set(value) { prefs.edit().putString("key", value.trim()).apply() }

    var model: String
        get() = prefs.getString("model", null)?.takeIf { it.isNotBlank() }
            ?: BuildConfig.LIA_AI_MODEL.ifBlank { MODEL_FAST }
        set(value) { prefs.edit().putString("model", value).apply() }

    fun clearKey() { prefs.edit().remove("key").apply() }

    /** "sk-ant-…ab12": o suficiente para você reconhecer a chave, sem expô-la. */
    fun masked(): String {
        val k = apiKey
        return if (k.length <= 8) "" else k.take(7) + "…" + k.takeLast(4)
    }

    companion object {
        const val MODEL_FAST = "claude-haiku-5-5"    // rápido e barato: o ideal para voz
        const val MODEL_SMART = "claude-sonnet-5-5"  // mais inteligente, um pouco mais lento
    }
}
