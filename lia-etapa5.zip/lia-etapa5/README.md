# Lia — Etapa 5 (versão 0.5.0): a Lia agora responde de verdade com IA

**Por que ela só dizia "Ainda não sei fazer isso":** a Lia só conhecia os comandos fixos (TV, luz, modo discreto, descansar).
Tudo o que não era comando caía nessa resposta. Agora, o que não for comando vai para a **IA (Claude, da Anthropic)** pela internet.

## Como ativar (uma vez)
1. Em **console.anthropic.com** crie uma conta e uma **chave de API** (Settings → API keys). Se pedir, adicione um pouco de saldo (o uso é pago por consumo).
2. Abra o app da Lia → cartão **Inteligência artificial** → cole a chave → **Salvar chave** → **Testar a IA**.
3. Pronto: fale "Lia, quanto tempo leva para cozinhar arroz?" ou toque em **Ouvir agora**.
O resultado do teste (ou o motivo da falha) aparece no **Registro** da tela principal.

## Como funciona
- **Primeiro as regras locais** (rápidas, funcionam sem internet): abrir app na TV, modo de tela, status, ligar/desligar luz e ventilador, descansar.
  Agora elas só valem para frases **curtas e exatas**, para não confundir uma pergunta com um comando
  (ex.: "como desativo o alarme?" vai para a IA; só "descansar" põe a Lia para dormir).
- **Depois a IA:** a Lia mostra "Pensando…" (bolinha laranja, na tela e na TV), espera a resposta e fala.
- **Memória curta:** lembra das últimas 6 trocas da conversa; depois de 10 minutos sem falar, começa uma conversa nova.
- **Respostas feitas para voz:** no máximo três frases, sem listas, símbolos, emojis ou links (o app ainda filtra o que sobrar).
- **Modelos:** **rápido** = `claude-haiku-5-5` (padrão: mais barato e veloz, ideal para voz) ou **mais inteligente** = `claude-sonnet-5-5`
  (um pouco mais lento). Troque no botão "Modelo". A Lia pede à IA respostas sem "raciocínio estendido" para ganhar velocidade; se o modelo recusar
  esse formato, ela tenta de novo no formato simples sozinha.
- **Erros falados com clareza:** sem internet, chave inválida, sem crédito, limite de pedidos e instabilidade do serviço têm mensagens próprias.

## Chave, privacidade e custo
- A chave digitada no app fica **só no armazenamento privado do seu celular**. Não vai para o GitHub nem dentro do APK. Se o celular for compartilhado ou
  tiver root, trate a chave como exposta. **Se vazar, apague-a no console e crie outra.** Dica: defina um limite de gastos mensal no console.
- Há um plano B (`LIA_AI_KEY` nos *Secrets*), mas **não recomendado**: a chave ficaria dentro do APK.
- **Privacidade:** o que você fala (já em texto) e a hora atual são enviados à Anthropic para gerar a resposta. Comandos locais não saem do celular.
- **Custo:** o Haiku 5.5 é o modelo mais barato; uma pergunta curta custa uma fração de centavo (confira os preços atuais no console).

## O que a IA ainda NÃO faz
- Não tem internet em tempo real: não sabe notícias de agora nem previsão do tempo (ela avisa em vez de inventar).
- Não controla a TV nem a casa por conta própria; só os comandos fixos fazem isso. (Próximo passo possível: dar à IA "ferramentas" para ela mesma ligar a luz ou abrir apps a partir de frases livres.)
- A resposta chega inteira antes de ser falada (sem transmissão em tempo real): costuma levar alguns segundos.

**Atualizar:** instale o APK novo por cima (a assinatura é a mesma da versão 0.4.1). No modo celular, suba o novo `lia-etapa5.zip`, troque o conteúdo do
`.github/workflows/build-from-zip.yml` pelo novo (ele usa sempre o ZIP mais novo) e apague o ZIP antigo se quiser.

---

## (Etapa 4, versão 0.4.1)

## Correção desta versão: o app fechava logo depois de pedir o microfone
**Causa:** a tela inicial da versão 0.4.0 era uma Activity transparente e sem interface, feita só para pedir permissões,
ligar o serviço e chamar `finish()`. Ou seja, fechar era o comportamento programado, e a Lia ficava rodando em segundo plano
com um aviso minimizado (fácil de não ver).
**Agora:** o app abre numa **tela principal** que não fecha sozinha, com:
- a bolinha e o estado (em espera, ouvindo, respondendo, descansando, parada);
- botões **Ouvir agora** (testa a voz completa sem precisar da palavra "Lia"), **Descansar/Acordar**, **Parar a Lia** e **Bateria**;
- campo para digitar comandos;
- **Situação**: microfone, notificações, serviço, palavra "Lia", TV;
- **Registro** das últimas mensagens e, se o app fechar por erro, o **motivo aparece na tela** na próxima abertura, com botão **Copiar erro**.
Também corrigido: a voz da Lia precisava de uma declaração no manifesto para o Android 11+ enxergar o motor de voz.

**Primeira instalação desta versão:** desinstale o app Lia antigo antes (a chave de assinatura mudou).
Daqui para frente a chave é fixa (`debug.keystore`), e cada APK novo instala por cima do anterior.

> Abrir o app **não acorda mais** a Lia automaticamente: use o botão **Acordar**, a notificação ou o botão rápido.

# Etapa 4: pronta para o GitHub Actions

Novidades desta etapa
1. **Voz mais natural** (pt-BR): escolhe a melhor voz instalada, fala frase por frase e corrige "Wi-Fi", "TV" e "ESP32".
2. **50 s de inatividade** depois de cada interação (vídeo tocando: a Lia some; menus: fica só a bolinha no canto).
3. **Modo escola / pausa**: por voz ("Lia, descansar"), pelo botão rápido, ou pela notificação. Desliga o microfone e esconde a bolinha na hora.
4. **Workflow do GitHub Actions** que gera os dois APKs (`app-debug.apk` do celular e `tv-debug.apk` da Aiwa).

```
lia-etapa4/
├── app/                       app do CELULAR (com.lia.assistant)
├── tv/                        app da AIWA TV (com.lia.tv)
├── esp32/lia_esp32/           firmware do ESP32
├── tools/fake_tv.py           TV de mentira para testes
├── .github/workflows/build-apk.yml           build (projeto completo no repositório)
└── github-modo-celular/build-from-zip.yml    build a partir do ZIP (só pelo celular)
```

> **Ainda não foi compilado** (não existe Android SDK onde eu trabalho). Se o primeiro build no GitHub falhar, abra o log da etapa
> "Compilar", copie as linhas com `e:` (erros do Kotlin) ou `FAILED` e me mande: corrijo na hora.

## Gerar o APK no GitHub

### Modo celular (só com o navegador do celular)
1. Crie uma conta e um repositório **privado** em github.com (ex.: `lia`).
2. **Add file → Upload files** e envie o `lia-etapa4.zip` *sem extrair*. (Opcional: envie também o `lia_android.ppn`.)
3. **Add file → Create new file**. No nome digite `.github/workflows/build-from-zip.yml` e cole o conteúdo de `github-modo-celular/build-from-zip.yml`. Salve (commit).
4. Aba **Actions** → "Build APKs (a partir do ZIP)" → **Run workflow**. Leva uns 5 a 10 minutos.
5. Abra o build concluído → **Artifacts → lia-apks** → baixe, extraia e você terá `app-debug.apk` e `tv-debug.apk`.

### Modo computador
Extraia o ZIP e envie **tudo** para o repositório (a pasta `.github` precisa ir junto). O build roda sozinho a cada envio.
Não use os dois modos no mesmo repositório.

### Segredos (opcional, em Settings → Secrets and variables → Actions)
`LIA_TOKEN` (igual no firmware do ESP32), `LIA_PICOVOICE_KEY`, `LIA_TV_HOST`, `LIA_ESP_HOST`, `LIA_TTS_VOICE`.
Se não criar nenhum, vale o padrão do `gradle.properties` (token `troque-este-token`; funciona, mas troque).
O arquivo `lia_android.ppn` (palavra "Lia") vai na **raiz do repositório**; o workflow o coloca dentro do app.

### Instalar
- **Celular:** abra o `app-debug.apk` e permita "instalar de fontes desconhecidas". Abra o app uma vez e aceite microfone e notificações.
- **TV:** instale o `tv-debug.apk` por pendrive, por um app de arquivos na TV, ou `adb install tv-debug.apk`.
  Abra **Lia TV** e libere sobreposição e acesso a notificações (ou use os comandos `adb` que aparecem na própria tela).
- Celular e TV no mesmo Wi-Fi. O resto (token, descoberta da TV, ESP32) está no README da Etapa 3, que continua valendo.

## 1. Voz mais natural
- O app escolhe a melhor voz pt-BR: dá preferência às vozes de rede do Google quando há internet, e às locais quando não há.
- **O que mais melhora:** Configurações do Android → Idioma → Saída de texto para voz → motor **Google** → Instalar dados de voz → Português (Brasil) → baixar a voz de alta qualidade e escolher a variante que preferir.
- Os nomes das vozes aparecem no Logcat (filtro `Lia`: "Vozes pt-BR disponíveis…"). Para fixar uma: `LIA_TTS_VOICE=<nome>`.
- Ritmo e tom: `setSpeechRate(0.95f)` e `setPitch(1.0f)` em `voice/Speaker.kt`.
- Limite: o app usa a voz do sistema. Não existe voz "humana" garantida; a qualidade final depende das vozes instaladas no seu celular.

## 2. Inatividade de 50 segundos (na TV)
A contagem começa quando a interação termina e reinicia se você falar de novo.
| Situação na TV | Depois de 50 s sem voz |
|---|---|
| Vídeo tocando | a Lia some por completo |
| Menus / nada tocando | o painel recolhe e fica só a **bolinha discreta** no canto superior direito |
- A bolinha de repouso só aparece depois da primeira fala (ou ao acordar). Se um vídeo começar com a bolinha na tela, ela some; se o vídeo acabar, ela volta.
- Para mudar o tempo: `IDLE_TIMEOUT_MS` no topo de `tv/.../LiaTvService.kt`.
- Teste sem TV: `FAKE_REST=5 python3 tools/fake_tv.py` usa 5 s no lugar de 50 s.

## 3. Modo escola / pausa
Desliga o microfone e esconde a bolinha da TV na hora.
- **Voz:** "Lia, descansar" (também funciona "modo escola", "desativar", "dormir", "tchau").
- **Notificação:** botão **Descansar** (e **Acordar** quando pausada).
- **Botão rápido:** puxe a barra superior → editar (lápis) → arraste o bloco **Lia**. Um toque pausa ou acorda.
- **Acordar:** pelo botão **Acordar** da tela principal, pelo botão rápido ou pela notificação. **Não dá para acordar por voz**, porque o microfone está desligado de propósito.
- O estado de descanso é lembrado mesmo se o celular reiniciar o serviço. O serviço fica vivo (sem ouvir nada) para o botão rápido acordar a Lia sem abrir o app; o consumo é mínimo. "Parar" na notificação encerra o serviço de vez.
- Se o celular estiver sem Wi-Fi ao pausar, o aviso à TV não chega; a bolinha some sozinha pelo temporizador (ou no vídeo).

## Limites que continuam valendo
Ícone verde de microfone enquanto escuta; depois de reiniciar o celular, abra o app uma vez; reconhecimento de fala pelo serviço do Android/Google;
sobreposição na TV pode exigir `adb`; segurança por token em rede doméstica. Detalhes na Etapa 3.
