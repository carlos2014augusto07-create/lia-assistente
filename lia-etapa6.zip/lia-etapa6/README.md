# Lia — Etapa 6 (versão 0.6.0)

> **Não foi compilado nem testado em aparelho** (não há Android SDK onde eu trabalho). O que foi testado aqui: o interpretador de alarmes
> (55 frases, em protótipo Python; as expressões regulares do Kotlin são as mesmas), o fatiador de frases do streaming e a sintaxe dos arquivos.
> Se o build falhar, mande as linhas com `e:` do log. Itens que dependem do seu aparelho estão marcados com **(não verificado)**.

## 1. O nome "Lia" é obrigatório
- **Digitado:** sem "Lia" na frase, **nada acontece** e a IA não é chamada (aparece só um aviso na tela e uma linha no Registro). Com "Lia", ela age:
  "Lia, que horas são", "Ei, Lia, liga a luz". Digitar só "Lia" faz ela começar a ouvir. Vale também para o comando por `adb`.
- **Voz:** quem garante o nome é a **palavra de ativação "Lia"**. O que você fala *depois* dela não precisa repetir o nome (se repetir, ela ignora o chamado).
  O botão **Ouvir agora** e o botão da notificação contam como chamar a Lia (você tocou de propósito).
- Detalhe técnico: `NameGate.kt`. A checagem vale para a palavra inteira (não confunde com "olia", "lição" etc.).

## 2. Notificação de estado
A notificação fixa muda na hora: **"Lia está escutando…"** assim que ela é chamada, **"Lia está pensando…"**, **"Lia está respondendo…"** (ou **"lendo…"**),
e volta a **"Aguardando “Lia”…"** depois. Também mostra "Descansando" quando pausada. Os botões mudam conforme o estado (**Calar** aparece enquanto ela lê).
O canal da notificação passou a ter importância "baixa" (sem som), para o ícone aparecer na barra de status. O canal antigo é apagado.
Depois do "Lia", a escuta da sua frase começa em ~0,2 s e toca um **toque curtinho** de "pode falar" (desligável em **Escuta → Som ao começar a ouvir**).
Fale com uma micro-pausa depois de "Lia": o microfone troca de dono entre a palavra de ativação e o reconhecimento de fala.

## 3. Fim da fala em 1,5 s de silêncio
A captura termina ~1,5 s depois que você para de falar, por dois caminhos juntos: (a) pedido ao reconhecedor do Android
(`EXTRA_SPEECH_INPUT_*_SILENCE_LENGTH_MILLIS = 1500`; alguns aparelhos **ignoram** esse pedido) e (b) a própria Lia fecha a captura quando o texto parcial fica
1,5 s sem mudar, o que funciona em qualquer reconhecedor que envie texto parcial **(não verificado em aparelho)**.
Se ninguém falar em 6 s, ela encerra **sem reclamar**. Teto de 20 s por frase.

## 4. Respostas rápidas em temas avançados + leitura de textos e imagens
- **Perguntas avançadas** ("explique…", "por que…", "como funciona…", cálculo, ciência, programação, frases longas) usam um modelo mais capaz primeiro
  (`gemini-3.5-flash`), com um pouco de raciocínio (`LOW`), prazo de 12 s e resposta de até ~700 tokens. As simples seguem no modelo mais rápido.
  A instrução pede **conclusão primeiro, só o detalhe essencial, no máximo 3 frases**. A escolha simples/avançada é uma heurística: o Registro mostra o modelo e o tempo da 1ª frase.
- **Ler um texto:** cartão **Ler e descrever** → cole ou digite → **Ler em voz alta** (a Lia só lê) ou **Resumir e ler** (a IA resume em 3 frases). **Calar** corta a leitura.
  Frase por frase, com pausas; até 30 000 caracteres por vez.
- **Ler a imagem pela câmera ou galeria:** **Câmera** (abre a câmera do sistema; o app não pede permissão de câmera) ou **Imagem da galeria**.
  A foto é reduzida a 1600 px e enviada ao Gemini, que devolve só o texto lido (a Lia fala enquanto chega). O botão **Câmera e imagem** alterna entre **ler o texto** e **descrever a imagem**.
- **Por voz:** "Lia, leia o que está escrito aqui", "Lia, leia o texto da câmera", "Lia, descreva o que a câmera está vendo".
  O Android só deixa o app abrir a câmera **com a tela da Lia aberta**. Se não estiver, ela deixa um **atalho na notificação** e avisa. Não dá para ler a área de transferência por voz (o Android bloqueia em segundo plano): use **Colar**.
- Imagens e textos vão ao Google para serem processados. Não envie documentos sensíveis.

## 5. Alarmes e temporizadores por voz (app de Relógio do Android)
Exemplos que ela entende: "Lia, alarme para as sete e meia", "me acorda às 6h", "alarme às 7:30", "alarme para as oito da noite",
"alarme quinze para as sete", "alarme meio-dia", "alarme daqui a vinte minutos", "alarme daqui a uma hora e meia", "temporizador de 5 minutos".
Sem período ("da manhã/tarde/noite"), vale o horário como dito (7 = 07:00); ela repete o horário por extenso para você conferir ("7 horas e 30 minutos da manhã").
Só age em frases de comando; perguntas ("como configuro um alarme?") vão para a IA. Não cria alarmes repetidos nem cancela alarmes.
**Como o Android deixa abrir o Relógio:** (1) com a tela da Lia aberta, abre direto; (2) com a tela apagada, se você liberar **Exibir sobre outros apps** (botão na tela principal),
ela usa uma janela invisível de 1 pixel para ganhar a permissão **(não verificado: o Android 15 ou mais novo restringe isso)**; (3) senão, deixa um aviso para tocar uma vez.
Ela só diz "Pronto" quando conseguiu *pedir* ao Relógio; o Android não informa se o alarme foi mesmo criado, então confira no app de Relógio na primeira vez.

## 6. Ativar por voz com a tela apagada
O que o serviço faz: continua em primeiro plano com o microfone liberado, segura um **WakeLock** (processador acordado) enquanto ela escuta (opção **Escuta → Escuta com a tela apagada**),
e o app pede para sair da **economia de bateria** (botão **Bateria** na tela principal, mostra se está liberado).
**Importante:** a ativação por voz sem tocar em nada depende da **palavra de ativação (Porcupine)**, que precisa de uma **chave** e do arquivo **lia_android.ppn**.
Sem eles, a Lia **não escuta o tempo todo** (a notificação avisa) e só funciona pelo botão **Ouvir agora**. Como configurar, pelo celular:
1. console.picovoice.ai → crie uma conta → copie a **AccessKey**.
2. Em "Porcupine" → crie a palavra **Lia** (idioma português) para **Android** → baixe o `.ppn` e renomeie para `lia_android.ppn`.
3. Suba o `lia_android.ppn` na raiz do repositório e crie o *Secret* `LIA_PICOVOICE_KEY` com a AccessKey. Rode o build de novo.
Limites: gasta mais bateria com a tela apagada; alguns fabricantes ainda matam apps em segundo plano (veja dontkillmyapp.com); o ícone verde de microfone fica ligado;
o reconhecimento de fala depois do "Lia" com a tela apagada **(não verificado em aparelho)**.

## Atualizar
Instale o APK por cima (mesma assinatura). No modo celular, suba o `lia-etapa6.zip` (o workflow usa o ZIP de nome mais novo) e rode o build.

---

# Lia — Etapa 5 (versão 0.5.1): Google Gemini e respostas bem mais rápidas

## O que mudou
- **IA do Google (Gemini) no lugar da Anthropic.** Funciona com a chave gratuita do Google AI Studio, tanto `AIza…` quanto `AQ…`
  (o app não confere o formato da chave, só a envia ao Google).
- **Aviso na hora:** assim que a Lia entende a pergunta, ela diz "Só um segundo." (os avisos se revezam: "Deixa eu ver.", "Já te respondo.", "Um instante.")
  e mostra "Pensando…" na tela do app e na TV. Se a IA não estiver configurada, não há aviso.
- **Streaming:** a Lia começa a falar a **primeira frase assim que ela chega**, sem esperar o texto inteiro. Frases muito curtas são juntadas para a voz não falar picotado.
- **Limite de espera:** se nenhum texto chegar em **10 segundos**, a Lia desiste e avisa ("A internet está lenta…"). A resposta inteira tem teto de 20 s.
  Se a conexão cair no meio, ela usa o que já chegou.
- **Respostas curtas:** a instrução enviada ao Gemini pede **no máximo 2 ou 3 frases**, diretas e naturais, e o app limita o tamanho da resposta.
  O raciocínio interno do modelo vem no mínimo (mais rápido).
- **Conexão aquecida:** quando a Lia começa a ouvir, o app já abre a conexão segura com o Google enquanto você ainda fala.
- **Medição:** o **Registro** da tela principal mostra, a cada pergunta, qual modelo respondeu e em quantos milissegundos chegou a primeira frase.

## Sobre os modelos (importante)
O `gemini-1.5-flash` **já foi desligado** pelo Google (dá erro 404) e o `gemini-2.5-flash` tem desligamento programado em 2026, então não dá para depender deles.
Por isso o app usa **modo automático**: tenta, em ordem, `gemini-3.5-flash-lite`, `gemini-3.1-flash-lite`, `gemini-3-flash-preview`, `gemini-3.5-flash` e
`gemini-2.5-flash`. Modelo que não existe (404), sem cota (429) ou sobrecarregado (503) é pulado sozinho, e o último que funcionou passa a ser o primeiro da fila.
O botão **Modelo** da tela principal permite travar um modelo específico. Quais modelos são gratuitos muda com o tempo: confira em aistudio.google.com.

## Como ativar (uma vez)
1. Abra **aistudio.google.com/apikey**, entre com sua conta Google e crie uma chave.
2. No app da Lia → cartão **Inteligência artificial (Google Gemini)** → cole a chave → **Salvar chave** → **Testar a IA**.
3. Fale ou toque em **Ouvir agora**. O resultado do teste (ou o motivo da falha) aparece no **Registro**.
Se o teste disser "ACCESS_TOKEN_TYPE_UNSUPPORTED" (erro 401) com uma chave `AQ…`, é um problema conhecido de algumas contas no lançamento das chaves novas:
apague as chaves antigas no AI Studio e crie uma nova pelo próprio site.

## Limites e cuidados
- **Plano gratuito:** tem limite de pedidos por minuto e por dia (aparece no AI Studio). Ao estourar, a Lia avisa. Confira os termos do Google sobre o uso dos dados no nível gratuito.
- **Privacidade:** o que você fala (em texto) e a hora atual vão ao Google para gerar a resposta. Comandos locais (TV, luz, descansar) não saem do celular.
- **Chave:** fica só no armazenamento privado do celular, nunca no GitHub nem no APK. Se vazar, apague-a no AI Studio e crie outra.
  (Plano B não recomendado: `LIA_AI_KEY` nos *Secrets* coloca a chave dentro do APK.)
- A Lia continua **sem internet em tempo real** (notícias, tempo) e **sem controlar a casa pela IA**: só os comandos fixos fazem isso.
- A velocidade real depende da sua internet e do Google. Não prometo um tempo exato: o Registro mostra os milissegundos de cada resposta para você acompanhar.

**Atualizar:** instale o APK novo por cima (mesma assinatura). No modo celular, suba o `lia-etapa5b.zip` (o workflow usa sempre o ZIP de nome mais novo; pode apagar os antigos).

---

## (Etapa 4, versão 0.4.1)

## Correção desta versão: o app fechava logo depois de pedir o microfone
**Causa:** a tela inicial da versão 0.4.0 era uma Activity transparente e sem interface, feita só para pedir permissões,
ligar o serviço e chamar `finish()`. Ou seja, fechar era o comportamento programado, e a Lia ficava rodando em segundo plano
com um aviso minimizado (fácil de não ver).
**Agora:** o app abre numa **tela principal** que não fecha sozinha, com:
- a bolinha e o estado (em espera, ouvindo, respondendo, descansando, parada);
- botões **Ouvir agora** (testa a voz completa sem precisar da palavra "Lia"), **Descansar/Acordar**, **Parar a Lia** e **Bateria**;
- campo para digitar comandos;
- **Situação**: microfone, notificações, serviço, palavra "Lia", TV;
- **Registro** das últimas mensagens e, se o app fechar por erro, o **motivo aparece na tela** na próxima abertura, com botão **Copiar erro**.
Também corrigido: a voz da Lia precisava de uma declaração no manifesto para o Android 11+ enxergar o motor de voz.

**Primeira instalação desta versão:** desinstale o app Lia antigo antes (a chave de assinatura mudou).
Daqui para frente a chave é fixa (`debug.keystore`), e cada APK novo instala por cima do anterior.

> Abrir o app **não acorda mais** a Lia automaticamente: use o botão **Acordar**, a notificação ou o botão rápido.

# Etapa 4: pronta para o GitHub Actions

Novidades desta etapa
1. **Voz mais natural** (pt-BR): escolhe a melhor voz instalada, fala frase por frase e corrige "Wi-Fi", "TV" e "ESP32".
2. **50 s de inatividade** depois de cada interação (vídeo tocando: a Lia some; menus: fica só a bolinha no canto).
3. **Modo escola / pausa**: por voz ("Lia, descansar"), pelo botão rápido, ou pela notificação. Desliga o microfone e esconde a bolinha na hora.
4. **Workflow do GitHub Actions** que gera os dois APKs (`app-debug.apk` do celular e `tv-debug.apk` da Aiwa).

```
lia-etapa4/
├── app/                       app do CELULAR (com.lia.assistant)
├── tv/                        app da AIWA TV (com.lia.tv)
├── esp32/lia_esp32/           firmware do ESP32
├── tools/fake_tv.py           TV de mentira para testes
├── .github/workflows/build-apk.yml           build (projeto completo no repositório)
└── github-modo-celular/build-from-zip.yml    build a partir do ZIP (só pelo celular)
```

> **Ainda não foi compilado** (não existe Android SDK onde eu trabalho). Se o primeiro build no GitHub falhar, abra o log da etapa
> "Compilar", copie as linhas com `e:` (erros do Kotlin) ou `FAILED` e me mande: corrijo na hora.

## Gerar o APK no GitHub

### Modo celular (só com o navegador do celular)
1. Crie uma conta e um repositório **privado** em github.com (ex.: `lia`).
2. **Add file → Upload files** e envie o `lia-etapa4.zip` *sem extrair*. (Opcional: envie também o `lia_android.ppn`.)
3. **Add file → Create new file**. No nome digite `.github/workflows/build-from-zip.yml` e cole o conteúdo de `github-modo-celular/build-from-zip.yml`. Salve (commit).
4. Aba **Actions** → "Build APKs (a partir do ZIP)" → **Run workflow**. Leva uns 5 a 10 minutos.
5. Abra o build concluído → **Artifacts → lia-apks** → baixe, extraia e você terá `app-debug.apk` e `tv-debug.apk`.

### Modo computador
Extraia o ZIP e envie **tudo** para o repositório (a pasta `.github` precisa ir junto). O build roda sozinho a cada envio.
Não use os dois modos no mesmo repositório.

### Segredos (opcional, em Settings → Secrets and variables → Actions)
`LIA_TOKEN` (igual no firmware do ESP32), `LIA_PICOVOICE_KEY`, `LIA_TV_HOST`, `LIA_ESP_HOST`, `LIA_TTS_VOICE`.
Se não criar nenhum, vale o padrão do `gradle.properties` (token `troque-este-token`; funciona, mas troque).
O arquivo `lia_android.ppn` (palavra "Lia") vai na **raiz do repositório**; o workflow o coloca dentro do app.

### Instalar
- **Celular:** abra o `app-debug.apk` e permita "instalar de fontes desconhecidas". Abra o app uma vez e aceite microfone e notificações.
- **TV:** instale o `tv-debug.apk` por pendrive, por um app de arquivos na TV, ou `adb install tv-debug.apk`.
  Abra **Lia TV** e libere sobreposição e acesso a notificações (ou use os comandos `adb` que aparecem na própria tela).
- Celular e TV no mesmo Wi-Fi. O resto (token, descoberta da TV, ESP32) está no README da Etapa 3, que continua valendo.

## 1. Voz mais natural
- O app escolhe a melhor voz pt-BR: dá preferência às vozes de rede do Google quando há internet, e às locais quando não há.
- **O que mais melhora:** Configurações do Android → Idioma → Saída de texto para voz → motor **Google** → Instalar dados de voz → Português (Brasil) → baixar a voz de alta qualidade e escolher a variante que preferir.
- Os nomes das vozes aparecem no Logcat (filtro `Lia`: "Vozes pt-BR disponíveis…"). Para fixar uma: `LIA_TTS_VOICE=<nome>`.
- Ritmo e tom: `setSpeechRate(0.95f)` e `setPitch(1.0f)` em `voice/Speaker.kt`.
- Limite: o app usa a voz do sistema. Não existe voz "humana" garantida; a qualidade final depende das vozes instaladas no seu celular.

## 2. Inatividade de 50 segundos (na TV)
A contagem começa quando a interação termina e reinicia se você falar de novo.
| Situação na TV | Depois de 50 s sem voz |
|---|---|
| Vídeo tocando | a Lia some por completo |
| Menus / nada tocando | o painel recolhe e fica só a **bolinha discreta** no canto superior direito |
- A bolinha de repouso só aparece depois da primeira fala (ou ao acordar). Se um vídeo começar com a bolinha na tela, ela some; se o vídeo acabar, ela volta.
- Para mudar o tempo: `IDLE_TIMEOUT_MS` no topo de `tv/.../LiaTvService.kt`.
- Teste sem TV: `FAKE_REST=5 python3 tools/fake_tv.py` usa 5 s no lugar de 50 s.

## 3. Modo escola / pausa
Desliga o microfone e esconde a bolinha da TV na hora.
- **Voz:** "Lia, descansar" (também funciona "modo escola", "desativar", "dormir", "tchau").
- **Notificação:** botão **Descansar** (e **Acordar** quando pausada).
- **Botão rápido:** puxe a barra superior → editar (lápis) → arraste o bloco **Lia**. Um toque pausa ou acorda.
- **Acordar:** pelo botão **Acordar** da tela principal, pelo botão rápido ou pela notificação. **Não dá para acordar por voz**, porque o microfone está desligado de propósito.
- O estado de descanso é lembrado mesmo se o celular reiniciar o serviço. O serviço fica vivo (sem ouvir nada) para o botão rápido acordar a Lia sem abrir o app; o consumo é mínimo. "Parar" na notificação encerra o serviço de vez.
- Se o celular estiver sem Wi-Fi ao pausar, o aviso à TV não chega; a bolinha some sozinha pelo temporizador (ou no vídeo).

## Limites que continuam valendo
Ícone verde de microfone enquanto escuta; depois de reiniciar o celular, abra o app uma vez; reconhecimento de fala pelo serviço do Android/Google;
sobreposição na TV pode exigir `adb`; segurança por token em rede doméstica. Detalhes na Etapa 3.
