package com.lia.assistant.voice

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.lia.assistant.LiaLog as Log
import com.lia.assistant.LiaPrefs

private const val SILENCE_MS = 1_500L        // fim da fala: 1,5 s depois que a pessoa para de falar
private const val NO_SPEECH_MS = 6_000L      // ninguém falou nada: encerra sem reclamar
private const val MAX_LISTEN_MS = 20_000L    // teto de uma frase

/**
 * Escuta UMA frase depois do "Lia", usando o reconhecimento de fala do Android.
 * Fim da fala em ~1,5 s de silêncio, por dois caminhos juntos:
 *  1) pede ao reconhecedor (EXTRA_SPEECH_INPUT_*_SILENCE_LENGTH_MILLIS = 1500), mas alguns aparelhos ignoram o pedido;
 *  2) por segurança, a própria Lia fecha a captura quando o texto parcial fica 1,5 s sem mudar.
 * Prefere o reconhecimento no próprio aparelho. Precisa ser chamado na thread principal.
 */
class CommandListener(private val ctx: Context) {

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private val timers = ArrayList<Runnable>()

    /** [onFail] recebe silent=true quando a pessoa não falou nada (encerra sem dizer "não entendi"). */
    fun listen(onText: (String) -> Unit, onFail: (silent: Boolean) -> Unit) {
        cancel()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            Log.w("Lia", "Sem serviço de reconhecimento de fala neste aparelho")
            onFail(false)
            return
        }

        val r = if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx)) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
        } else {
            SpeechRecognizer.createSpeechRecognizer(ctx)
        }
        recognizer = r

        var finished = false      // evita responder duas vezes (onError + onResults)
        var spoke = false
        var lastPartial = ""

        fun timer(ms: Long, block: () -> Unit) {
            val run = Runnable { block() }
            timers.add(run)
            main.postDelayed(run, ms)
        }
        val closeCapture = Runnable { runCatching { r.stopListening() } }   // gera onResults com o que já foi dito

        fun finish(block: () -> Unit) {
            if (finished) return
            finished = true
            clearTimers()
            block()
        }

        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                beep()
                timer(NO_SPEECH_MS) { if (!spoke) finish { cancel(); onFail(true) } }
                timer(MAX_LISTEN_MS) { if (!finished) closeCapture.run() }
            }

            override fun onBeginningOfSpeech() { spoke = true }

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (t.isNotBlank() && t != lastPartial) {
                    lastPartial = t
                    spoke = true
                    main.removeCallbacks(closeCapture)               // falou de novo: reinicia a contagem
                    timers.add(closeCapture)
                    main.postDelayed(closeCapture, SILENCE_MS)       // 1,5 s sem mudar: fecha a captura
                }
            }

            override fun onResults(results: Bundle?) {
                finish {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        ?: lastPartial
                    if (text.isBlank()) onFail(!spoke) else onText(text)
                }
            }

            override fun onError(error: Int) {
                finish {
                    Log.w("Lia", "Reconhecimento de fala: código $error")
                    val silent = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                    if (lastPartial.isNotBlank()) onText(lastPartial) else onFail(silent)
                }
            }

            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, SILENCE_MS)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, SILENCE_MS)
        }
        r.startListening(intent)
    }

    /** Toque curtinho: "pode falar". Respeita o modo silencioso (usa o volume de notificação). */
    private fun beep() {
        if (!LiaPrefs.beepOnListen(ctx)) return
        runCatching {
            val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 60)
            tone.startTone(ToneGenerator.TONE_PROP_ACK, 120)
            main.postDelayed({ runCatching { tone.release() } }, 400)
        }
    }

    private fun clearTimers() {
        timers.forEach { main.removeCallbacks(it) }
        timers.clear()
    }

    fun cancel() {
        clearTimers()
        recognizer?.let {
            runCatching { it.cancel() }
            runCatching { it.destroy() }
        }
        recognizer = null
    }
}
