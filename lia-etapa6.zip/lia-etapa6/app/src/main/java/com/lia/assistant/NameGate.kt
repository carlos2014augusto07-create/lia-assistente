package com.lia.assistant

/**
 * Regra da Lia: ela só age se o nome "Lia" for dito ou escrito.
 *  - por voz, quem garante isso é a palavra de ativação (ou o botão "Ouvir agora");
 *  - por texto digitado, é esta checagem. Sem "Lia", nada acontece e a IA não é chamada.
 */
object NameGate {
    private const val WORD = "(?<![\\p{L}\\p{N}])lia(?![\\p{L}\\p{N}])"
    private val HAS = Regex(WORD, RegexOption.IGNORE_CASE)
    // "Lia", "Ei Lia", "Oi, Lia", "Ok Lia"...
    private val CALL = Regex(
        "((?<![\\p{L}\\p{N}])(ei|ô|oi|olá|ola|hey|ok)[\\s,]+)?$WORD",
        RegexOption.IGNORE_CASE
    )

    fun has(text: String): Boolean = HAS.containsMatchIn(text)

    /** Tira o chamado ("Ei, Lia,") e deixa só o pedido. Vazio = a pessoa só chamou a Lia. */
    fun strip(text: String): String =
        text.replaceFirst(CALL, " ")
            .replace(Regex("^[\\s,.:;!?\\-]+"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
}
