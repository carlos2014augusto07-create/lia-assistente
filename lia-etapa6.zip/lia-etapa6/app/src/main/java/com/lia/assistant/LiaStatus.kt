package com.lia.assistant

import android.os.Handler
import android.os.Looper
import com.lia.assistant.net.LiaState
import java.util.concurrent.CopyOnWriteArraySet

/** O serviço escreve aqui; a tela principal e a notificação leem e se atualizam. Sem bibliotecas, sem polling. */
object LiaStatus {
    @Volatile var state: LiaState = LiaState.IDLE
    @Volatile var text: String = ""
    @Volatile var wakeInfo: String = "Palavra “Lia”: ainda não iniciada"
    @Volatile var tvInfo: String = "TV: ainda sem contato"

    /** A tela principal está visível? (Só com ela visível o Android deixa abrir o relógio/câmera direto.) */
    @Volatile var activityVisible: Boolean = false

    /** A Lia está lendo um texto em voz alta (mostra "Calar" na notificação). */
    @Volatile var reading: Boolean = false

    /** Imagem (JPEG em base64) esperando a leitura: é grande demais para ir dentro de um Intent. */
    @Volatile var pendingImage: String? = null

    /** Registrado pela tela principal enquanto visível: abre a câmera. Recebe "descrever?" e devolve se abriu. */
    @Volatile var cameraRequester: ((Boolean) -> Boolean)? = null

    private val listeners = CopyOnWriteArraySet<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    fun set(newState: LiaState, newText: String) {
        state = newState
        if (newText.isNotEmpty()) text = newText
        notifyChanged()
    }

    fun add(l: () -> Unit) { listeners.add(l) }
    fun remove(l: () -> Unit) { listeners.remove(l) }
    fun notifyChanged() { main.post { listeners.forEach { it() } } }
}
