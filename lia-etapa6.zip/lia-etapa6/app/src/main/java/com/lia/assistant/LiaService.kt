package com.lia.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import android.service.quicksettings.TileService
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.lia.assistant.LiaLog as Log
import com.lia.assistant.net.LiaState

/**
 * Serviço leve em primeiro plano: sem tela, só uma notificação que mostra o que a Lia está fazendo.
 * O trabalho de verdade é do LiaEngine.
 *
 * Tela apagada: o serviço é "em primeiro plano" do tipo microfone (o Android mantém o app vivo e o microfone liberado)
 * e segura um WakeLock parcial enquanto a Lia está ouvindo (desligável na tela principal).
 */
class LiaService : Service() {

    private var engine: LiaEngine? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastNotificationText = ""
    private val statusListener: () -> Unit = { updateNotification() }

    override fun onCreate() {
        super.onCreate()
        running = true
        createChannel()
        LiaStatus.add(statusListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Quem chama startForegroundService precisa chegar aqui em até 5 s.
        if (!enterForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }

        val e = engine ?: LiaEngine(applicationContext) { paused -> onPausedChanged(paused) }
            .also { engine = it; it.start() }

        when (intent?.action) {
            ACTION_SIMULATE_WAKE -> e.onWake()
            ACTION_COMMAND -> e.runText(intent.getStringExtra(EXTRA_TEXT).orEmpty())
            ACTION_PAUSE -> e.pause()
            ACTION_RESUME -> e.resume()
            ACTION_TOGGLE_PAUSE -> e.togglePause()
            ACTION_READ_TEXT -> e.readAloud(intent.getStringExtra(EXTRA_TEXT).orEmpty(), intent.getBooleanExtra(EXTRA_FLAG, false))
            ACTION_READ_IMAGE -> e.readImage(intent.getBooleanExtra(EXTRA_FLAG, false))
            ACTION_STOP_SPEECH -> e.stopSpeaking()
            ACTION_REFRESH -> {}   // só reaplica as preferências (WakeLock)
        }
        applyWakeLock()
        refreshTile()
        updateNotification(force = true)
        return START_STICKY
    }

    // ----- notificação: reflete o estado em tempo real -----

    private fun statusText(): String {
        if (LiaPrefs.isPaused(this)) return "Descansando: microfone desligado"
        return when (LiaStatus.state) {
            LiaState.LISTENING -> "Lia está escutando…"
            LiaState.RESPONDING -> when {
                LiaStatus.reading -> "Lia está lendo…"
                LiaStatus.text == "Pensando…" -> "Lia está pensando…"
                else -> "Lia está respondendo…"
            }
            LiaState.IDLE ->
                if (LiaStatus.wakeInfo.contains("ativa")) "Aguardando “Lia”…"
                else "Palavra “Lia” desligada: toque em Ouvir agora"
        }
    }

    private fun updateNotification(force: Boolean = false) {
        val text = statusText()
        if (!force && text == lastNotificationText) return
        lastNotificationText = text
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    private fun onPausedChanged(@Suppress("UNUSED_PARAMETER") paused: Boolean) {
        applyWakeLock()
        updateNotification(force = true)
        refreshTile()
    }

    private fun refreshTile() {
        runCatching {
            TileService.requestListeningState(this, ComponentName(this, LiaTileService::class.java))
        }
    }

    // ----- tela apagada -----

    /** Só segura o processador acordado enquanto a Lia está ouvindo (não pausada) e se a opção estiver ligada. */
    private fun applyWakeLock() {
        val want = running && !LiaPrefs.isPaused(this) && LiaPrefs.keepAwake(this)
        val held = wakeLock?.isHeld == true
        if (want && !held) {
            wakeLock = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Lia::escuta")
                .apply { setReferenceCounted(false); acquire() }
            Log.d(TAG, "Escuta com a tela apagada: processador mantido acordado")
        } else if (!want && held) {
            runCatching { wakeLock?.release() }
            wakeLock = null
            Log.d(TAG, "WakeLock liberado")
        }
    }

    private fun enterForeground(): Boolean = try {
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(statusText()),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
        true
    } catch (e: Exception) {
        Log.e(TAG, "Não foi possível iniciar em primeiro plano: ${e.message}")
        false
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.deleteNotificationChannel("lia_listening")   // canal antigo (importância mínima, sem ícone na barra)
        // LOW: o ícone aparece na barra de status e o texto muda sem som nem vibração.
        val channel = NotificationChannel(CHANNEL_ID, "Estado da Lia", NotificationManager.IMPORTANCE_LOW)
            .apply { setShowBadge(false) }
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        fun action(label: String, action: String) = NotificationCompat.Action.Builder(
            0, label,
            PendingIntent.getService(
                this, action.hashCode(),
                Intent(this, LiaService::class.java).setAction(action),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        ).build()

        // Tocar na notificação abre a tela principal.
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("Lia")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)

        if (LiaPrefs.isPaused(this)) {
            b.addAction(action("Acordar", ACTION_RESUME))
        } else {
            b.addAction(action("Descansar", ACTION_PAUSE))
            if (LiaStatus.reading) b.addAction(action("Calar", ACTION_STOP_SPEECH))
            else b.addAction(action("Ouvir agora", ACTION_SIMULATE_WAKE))
        }
        b.addAction(action("Parar", ACTION_STOP))
        return b.build()
    }

    override fun onDestroy() {
        running = false
        LiaStatus.remove(statusListener)
        runCatching { wakeLock?.release() }
        wakeLock = null
        engine?.stop()
        engine = null
        refreshTile()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val TAG = "Lia"
        const val ACTION_STOP = "com.lia.assistant.STOP"
        const val ACTION_SIMULATE_WAKE = "com.lia.assistant.SIMULATE_WAKE"
        const val ACTION_COMMAND = "com.lia.assistant.COMMAND"
        const val ACTION_PAUSE = "com.lia.assistant.PAUSE"
        const val ACTION_RESUME = "com.lia.assistant.RESUME"
        const val ACTION_TOGGLE_PAUSE = "com.lia.assistant.TOGGLE_PAUSE"
        const val ACTION_READ_TEXT = "com.lia.assistant.READ_TEXT"
        const val ACTION_READ_IMAGE = "com.lia.assistant.READ_IMAGE"
        const val ACTION_STOP_SPEECH = "com.lia.assistant.STOP_SPEECH"
        const val ACTION_REFRESH = "com.lia.assistant.REFRESH"
        const val EXTRA_TEXT = "text"
        const val EXTRA_FLAG = "flag"                 // ler texto: resumir? | ler imagem: descrever?
        private const val CHANNEL_ID = "lia_estado"
        private const val NOTIF_ID = 1

        /** O botão rápido (outro componente do mesmo app) usa isto para saber se o serviço existe. */
        @Volatile var running = false
            private set
    }
}
