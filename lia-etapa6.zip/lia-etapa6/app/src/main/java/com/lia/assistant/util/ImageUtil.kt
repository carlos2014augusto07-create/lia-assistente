package com.lia.assistant.util

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.max

object ImageUtil {

    /**
     * Abre a imagem, corrige a rotação da foto, reduz para no máximo [maxSide] pixels no lado maior
     * (suficiente para ler texto e leve para enviar) e devolve JPEG em base64. null = não deu para ler.
     */
    fun toBase64Jpeg(cr: ContentResolver, uri: Uri, maxSide: Int = 1600): String? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            null
        } else {
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) > maxSide) sample *= 2

            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            if (bmp == null) {
                null
            } else {
                val rotation = runCatching {
                    cr.openInputStream(uri)?.use {
                        when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                            else -> 0f
                        }
                    } ?: 0f
                }.getOrDefault(0f)

                val longest = max(bmp.width, bmp.height)
                val scale = if (longest > maxSide) maxSide.toFloat() / longest else 1f
                if (rotation != 0f || scale != 1f) {
                    val m = Matrix().apply { postScale(scale, scale); postRotate(rotation) }
                    bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                }
                val out = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
                Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            }
        }
    } catch (e: Throwable) {   // inclui falta de memória em fotos enormes
        null
    }
}
