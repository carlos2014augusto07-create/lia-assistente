package com.lia.assistant.alarm

import java.text.Normalizer
import java.util.Calendar

sealed interface AlarmCommand {
    /** [spoken] = o horário como a Lia fala ("7 horas e 30 minutos da manhã"). */
    data class Alarm(val hour: Int, val minute: Int, val spoken: String) : AlarmCommand
    data class Timer(val seconds: Int, val spoken: String) : AlarmCommand
    /** Pediu alarme/temporizador mas não deu para entender o horário ou o tempo. */
    data object NeedTime : AlarmCommand
}

/**
 * Entende, em português falado: "alarme para as sete e meia", "me acorda às 6h", "alarme quinze para as sete",
 * "alarme daqui a uma hora e meia", "temporizador de 5 minutos".
 * Só age em frases de COMANDO (curtas, com verbo ou começando por "alarme"): perguntas como
 * "como configuro um alarme?" vão para a IA. A lógica foi testada com ~55 frases antes de virar Kotlin.
 */
object AlarmParser {

    private val UNITS = mapOf(
        "zero" to 0, "um" to 1, "uma" to 1, "dois" to 2, "duas" to 2, "tres" to 3, "quatro" to 4, "cinco" to 5,
        "seis" to 6, "sete" to 7, "oito" to 8, "nove" to 9, "dez" to 10, "onze" to 11, "doze" to 12, "treze" to 13,
        "catorze" to 14, "quatorze" to 14, "quinze" to 15, "dezesseis" to 16, "dezessete" to 17, "dezoito" to 18,
        "dezenove" to 19
    )
    private val TENS = mapOf("vinte" to 20, "trinta" to 30, "quarenta" to 40, "cinquenta" to 50)

    private val COMMAND_VERBS = setOf(
        "cria", "crie", "criar", "coloca", "coloque", "colocar", "poe", "ponha", "programa", "programe", "programar",
        "define", "defina", "configura", "configure", "agenda", "agende", "marca", "marque", "faz", "faca", "ajusta",
        "ajuste", "acorda", "acorde", "acordar", "desperta", "desperte", "quero", "preciso", "gostaria", "bota", "bote"
    )
    private val WAKE_VERBS = setOf("acorda", "acorde", "desperta", "desperte", "acordar")
    private val NOUN_STARTS = setOf("alarme", "alarmes", "despertador", "temporizador", "timer")
    private val QUESTION_STARTS = setOf("como", "qual", "quais", "quando", "quanto", "quantos", "quantas", "porque", "quem", "onde")

    fun parse(raw: String, now: Calendar = Calendar.getInstance()): AlarmCommand? {
        val words = prep(raw).split(" ").filter { it.isNotEmpty() }
        if (words.isEmpty()) return null

        val isTimer = words.any { it == "temporizador" || it == "timer" }
        val isAlarm = "alarme" in words || "alarmes" in words || "despertador" in words ||
            ("me" in words && words.any { it in WAKE_VERBS })
        if (!isTimer && !isAlarm) return null
        if (!commandLike(words)) return null

        val s = normalizeTimeWords(raw)

        if (isTimer) {
            var minutes = relative(s)
            if (minutes == null) {
                val m = Regex("\\b(\\d+) (horas?|minutos?)\\b").find(s)
                if (m != null) {
                    val n = m.groupValues[1].toIntOrNull() ?: return AlarmCommand.NeedTime
                    minutes = (if (m.groupValues[2].startsWith("hora")) n * 60L else n.toLong())
                }
            }
            if (minutes == null || minutes <= 0 || minutes > 24 * 60) return AlarmCommand.NeedTime
            return AlarmCommand.Timer(minutes.toInt() * 60, durationPhrase(minutes.toInt()))
        }

        val rel = relative(s)
        if (rel != null) {
            if (rel <= 0 || rel > 24 * 60) return AlarmCommand.NeedTime
            val at = (now.clone() as Calendar).apply { add(Calendar.MINUTE, rel.toInt()) }
            val h = at.get(Calendar.HOUR_OF_DAY)
            val m = at.get(Calendar.MINUTE)
            return AlarmCommand.Alarm(h, m, "daqui a ${durationPhrase(rel.toInt())}, às ${phrase(h, m)}")
        }

        val abs = absolute(s) ?: return AlarmCommand.NeedTime
        var h = abs.first
        val m = abs.second
        if (h == 24) h = 0
        h = applyPeriod(h, s)
        if (h !in 0..23 || m !in 0..59) return AlarmCommand.NeedTime
        return AlarmCommand.Alarm(h, m, "para ${phrase(h, m)}")
    }

    private fun commandLike(words: List<String>): Boolean {
        if (words.size > 12) return false
        if (words[0] in QUESTION_STARTS) return false
        if (words.size >= 2 && ((words[0] == "por" && words[1] == "que") || (words[0] == "o" && words[1] == "que"))) return false
        return words[0] in NOUN_STARTS || words.any { it in COMMAND_VERBS }
    }

    // ---------- texto → números ----------

    private fun prep(raw: String): String {
        var s = Normalizer.normalize(raw.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        s = Regex("(\\d)\\s*h\\s*(\\d{2})\\b").replace(s, "\$1:\$2")     // 7h30 → 7:30
        s = Regex("(\\d)\\s*h\\b").replace(s, "\$1 horas")               // 7h → 7 horas
        s = Regex("[^a-z0-9: ]+").replace(s, " ")
        return Regex("\\s+").replace(s, " ").trim()
    }

    private fun numAt(t: List<String>, i: Int): Pair<Int, Int>? {
        val w = t[i]
        if (w.isNotEmpty() && w.all { it.isDigit() }) {
            val v = w.toIntOrNull() ?: return null
            return v to (i + 1)
        }
        val tens = TENS[w]
        if (tens != null) {
            if (i + 2 < t.size && t[i + 1] == "e") {
                val u = UNITS[t[i + 2]]
                if (u != null && u in 1..9) return (tens + u) to (i + 3)
            }
            return tens to (i + 1)
        }
        val unit = UNITS[w]
        if (unit != null) return unit to (i + 1)
        return null
    }

    private fun wordsToDigits(s: String): String {
        val t = s.split(" ")
        val out = ArrayList<String>()
        var i = 0
        while (i < t.size) {
            val n = if (t[i].isNotEmpty()) numAt(t, i) else null
            if (n != null) { out.add(n.first.toString()); i = n.second } else { out.add(t[i]); i += 1 }
        }
        return out.joinToString(" ")
    }

    private fun normalizeTimeWords(raw: String): String {
        var s = wordsToDigits(prep(raw))
        s = Regex("\\bmeio dia\\b").replace(s, "12:00")
        s = Regex("\\bmeia noite\\b").replace(s, "0:00")
        s = Regex("\\b1 quarto de hora\\b").replace(s, "15 minutos")
        s = Regex("\\bmeia hora\\b").replace(s, "30 minutos")
        s = Regex("(horas?) e meia\\b").replace(s, "\$1 e 30 minutos")
        s = Regex("\\be meia\\b").replace(s, "e 30")
        s = Regex("\\be 1 quarto\\b").replace(s, "e 15")
        s = Regex("\\b1 quarto (?:para|pra)\\b").replace(s, "15 para")
        return s
    }

    // ---------- horários ----------

    private fun applyPeriod(h0: Int, s: String): Int {
        var h = h0
        if (Regex("\\b(?:da|de) tarde\\b").containsMatchIn(s)) {
            if (h < 12) h += 12
        } else if (Regex("\\b(?:da|de) noite\\b").containsMatchIn(s)) {
            if (h in 6..11) h += 12 else if (h == 12) h = 0
        } else if (Regex("\\b(?:da|de) madrugada\\b").containsMatchIn(s)) {
            if (h == 12) h = 0
        }
        return h % 24
    }

    private fun absolute(s: String): Pair<Int, Int>? {
        var m = Regex("\\b(\\d{1,2}) (?:para|pra) (?:as |a )?(\\d{1,2})\\b").find(s)
        if (m != null) {
            val mins = m.groupValues[1].toInt()
            if (mins in 1..59) return Math.floorMod(m.groupValues[2].toInt() - 1, 24) to (60 - mins)
        }
        m = Regex("\\b(\\d{1,2}) menos (\\d{1,2})\\b").find(s)
        if (m != null) {
            val mins = m.groupValues[2].toInt()
            if (mins in 1..59) return Math.floorMod(m.groupValues[1].toInt() - 1, 24) to (60 - mins)
        }
        m = Regex("\\b(\\d{1,2}):(\\d{2})\\b").find(s)
        if (m != null) return m.groupValues[1].toInt() to m.groupValues[2].toInt()
        m = Regex("\\b(\\d{1,2}) horas? e (\\d{1,2})(?: minutos?)?\\b").find(s)
        if (m != null) return m.groupValues[1].toInt() to m.groupValues[2].toInt()
        m = Regex("\\b(\\d{1,2}) e (\\d{1,2})\\b").find(s)
        if (m != null && m.groupValues[2].toInt() <= 59) return m.groupValues[1].toInt() to m.groupValues[2].toInt()
        m = Regex("\\b(\\d{1,2}) horas?\\b").find(s)
        if (m != null) return m.groupValues[1].toInt() to 0
        m = Regex("\\b(\\d{1,2}) em ponto\\b").find(s)
        if (m != null) return m.groupValues[1].toInt() to 0
        m = Regex("\\b(?:as|para as|pras|para|pra|a) (\\d{1,2})\\b").find(s)
        if (m != null) return m.groupValues[1].toInt() to 0
        return null
    }

    /** "daqui a 20 minutos", "em uma hora e meia"... → total de minutos. */
    private fun relative(s: String): Long? {
        val m = Regex("\\b(?:daqui a|daqui|em|de aqui a|de) (\\d+ (?:horas?|minutos?)(?: e \\d+ (?:horas?|minutos?))*)").find(s)
            ?: return null
        var total = 0L
        for (part in Regex("(\\d+) (horas?|minutos?)").findAll(m.groupValues[1])) {
            val n = part.groupValues[1].toLongOrNull() ?: return null
            total += if (part.groupValues[2].startsWith("hora")) n * 60 else n
        }
        return total
    }

    // ---------- frases de confirmação ----------

    fun phrase(h: Int, m: Int): String {
        if (h == 0 && m == 0) return "meia-noite"
        if (h == 12 && m == 0) return "meio-dia"
        val period = when {
            h < 6 -> "da madrugada"
            h < 12 -> "da manhã"
            h < 18 -> "da tarde"
            else -> "da noite"
        }
        val h12 = if (h % 12 == 0) 12 else h % 12
        val hours = "$h12 hora" + if (h12 != 1) "s" else ""
        return hours + (if (m != 0) " e $m minutos" else "") + " " + period
    }

    fun durationPhrase(totalMinutes: Int): String {
        val h = totalMinutes / 60
        val m = totalMinutes % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add("$h hora" + if (h != 1) "s" else "")
        if (m > 0) parts.add("$m minuto" + if (m != 1) "s" else "")
        return parts.joinToString(" e ")
    }
}
