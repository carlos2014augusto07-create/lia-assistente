package com.lia.assistant.ai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Responde o que as regras locais não cobrem, lembrando das últimas trocas da conversa. */
class AiAssistant(ctx: Context) {

    private val settings = AiSettings(ctx)
    private val client = AiClient()
    private val history = ArrayList<Turn>()
    private var lastAt = 0L

    fun isConfigured() = settings.apiKey.isNotBlank()

    /** Chame assim que a Lia começar a ouvir: prepara a conexão segura enquanto você ainda fala. */
    suspend fun warmUp() {
        if (isConfigured()) withContext(Dispatchers.IO) { client.warmUp() }
    }

    /**
     * Pergunta com memória curta. Perguntas avançadas usam os modelos mais capazes (com pouco "pensamento"),
     * as simples usam o mais rápido. [onSentence] é chamado a cada frase pronta (streaming), em outra thread.
     */
    suspend fun answer(question: String, onSentence: (String) -> Unit): AiResult {
        val key = settings.apiKey
        if (key.isBlank()) return noKey()

        val now = System.currentTimeMillis()
        if (now - lastAt > CONVERSATION_MEMORY_MS) history.clear()   // 10 min parada: conversa nova

        val deep = isAdvanced(question)
        val result = withContext(Dispatchers.IO) {
            client.ask(
                key, settings.modelsToTry(deep), history.toList(), question, onSentence,
                { if (deep) settings.lastGoodDeep = it else settings.lastGood = it },
                if (deep) AiMode.DEEP else AiMode.CHAT
            )
        }
        if (result is AiResult.Ok) {
            history.add(Turn("user", question))
            history.add(Turn("model", result.text))
            while (history.size > MAX_TURNS) { history.removeAt(0); history.removeAt(0) }
            lastAt = now
        }
        return result
    }

    /** Lê (ou descreve) o conteúdo de uma imagem. [imageBase64] = JPEG em base64. */
    suspend fun readImage(imageBase64: String, describe: Boolean, onSentence: (String) -> Unit): AiResult {
        val key = settings.apiKey
        if (key.isBlank()) return noKey()
        val prompt = if (describe) "Descreva esta imagem." else "Leia o texto desta imagem."
        return withContext(Dispatchers.IO) {
            client.ask(
                key, settings.modelsToTry(deep = true), emptyList(), prompt, onSentence,
                { settings.lastGoodDeep = it },
                if (describe) AiMode.DESCRIBE_IMAGE else AiMode.READ_IMAGE, imageBase64
            )
        }
    }

    /** Resume um texto (a pedido do botão "Resumir e ler"). */
    suspend fun summarize(text: String, onSentence: (String) -> Unit): AiResult {
        val key = settings.apiKey
        if (key.isBlank()) return noKey()
        return withContext(Dispatchers.IO) {
            client.ask(
                key, settings.modelsToTry(deep = true), emptyList(),
                "Resuma o texto abaixo em no máximo 3 frases curtas.\n\n" + text.take(20_000), onSentence,
                { settings.lastGoodDeep = it }, AiMode.DEEP
            )
        }
    }

    private fun noKey() = AiResult.Fail(
        "Para eu responder perguntas, cadastre a chave do Google na tela principal do app.", "sem chave"
    )

    private companion object {
        const val MAX_TURNS = 12                       // 6 trocas de ida e volta
        const val CONVERSATION_MEMORY_MS = 10 * 60_000L

        // Sinais de pergunta que pede raciocínio. A decisão é só uma heurística: errar para um lado ou outro não quebra nada.
        val ADVANCED = Regex(
            "explique|explica|por que|porque|como funciona|diferenca entre|compare|calcule|demonstre|resolva|analise|" +
                "vantagens|desvantagens|passo a passo|equacao|teorema|algoritmo|derivada|integral|probabilidade|" +
                "estatistica|quimic|fisic|biologi|economi|filosofi|historia d|programa|codigo|diagnostico"
        )
    }

    private fun isAdvanced(question: String): Boolean {
        val n = com.lia.assistant.normalize(question)
        return n.split(" ").size >= 16 || ADVANCED.containsMatchIn(n)
    }
}
