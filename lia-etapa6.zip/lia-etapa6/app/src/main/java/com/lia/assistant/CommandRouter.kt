package com.lia.assistant

import com.lia.assistant.alarm.AlarmCommand
import com.lia.assistant.alarm.AlarmParser
import com.lia.assistant.esp.Esp32Manager
import com.lia.assistant.net.TvMode
import com.lia.assistant.tv.TvManager

/**
 * [sleep]  = depois de falar, a Lia entra em descanso.
 * [askAi]  = não é comando: [text] é a pergunta, e o motor leva para a IA (aviso rápido + voz em streaming).
 * [alarm]  = criar alarme/temporizador no Relógio do Android.
 * [camera] = abrir a câmera para ler ([describe] = descrever em vez de ler).
 */
data class Reply(
    val text: String,
    val sleep: Boolean = false,
    val askAi: Boolean = false,
    val alarm: AlarmCommand? = null,
    val camera: Boolean = false,
    val describe: Boolean = false
)

/**
 * Primeiro tenta as regras locais (rápidas, funcionam sem internet): modo escola, alarmes, câmera, TV, luz...
 * Elas só valem para frases CURTAS e exatas, senão "como desativo o alarme?" viraria "desativar a Lia".
 * O que não for comando vira pergunta para a IA. O nome "Lia" já foi conferido (e retirado) antes de chegar aqui.
 */
class CommandRouter(private val tv: TvManager, private val esp: Esp32Manager) {

    suspend fun handle(raw: String): Reply {
        val t = normalize(raw)
        val words = t.split(" ").filter { it.isNotEmpty() }
        val short = words.size <= 6

        if (SLEEP.matches(t)) return Reply("Tá bom, até logo!", sleep = true)

        AlarmParser.parse(raw)?.let { cmd ->
            return if (cmd == AlarmCommand.NeedTime) {
                Reply("Para criar o alarme, diga o horário. Por exemplo: alarme para as sete e meia, ou daqui a vinte minutos.")
            } else {
                Reply("", alarm = cmd)
            }
        }

        if (words.size <= 9 && isReadRequest(words, t)) {
            val describe = words.any { it in DESCRIBE_WORDS } || "vendo" in words
            return Reply("", camera = true, describe = describe)
        }

        val app = APPS.firstOrNull { it.first in t }
        val local: String? = when {
            short && app != null && words.any { it in OPEN_WORDS } -> {
                tv.openApp(app.first)
                "Abrindo ${app.second} na TV."
            }
            short && "modo automatico" in t -> { tv.setMode(TvMode.AUTO); "Modo automático ligado." }
            short && "tela cheia" in t -> { tv.setMode(TvMode.FULLSCREEN); "Tela cheia." }
            short && "modo" in words && ("canto" in words || "discreto" in words) -> {
                tv.setMode(TvMode.CORNER_BUBBLE); "Modo discreto no canto."
            }
            words.size <= 3 && words.firstOrNull() == "status" -> tv.status()
            else -> esp.handle(t)
        }
        return if (local != null) Reply(local) else Reply(raw, askAi = true)
    }

    /** "leia o que está escrito aqui", "ler o texto da câmera", "descreva o que a câmera está vendo"... */
    private fun isReadRequest(words: List<String>, t: String): Boolean {
        val reads = words.any { it in READ_VERBS }
        val describes = words.any { it in DESCRIBE_WORDS }
        return (("camera" in words) && (reads || describes)) ||
            (reads && words.any { it in READ_OBJECTS }) ||
            t.startsWith("o que esta escrito") ||
            (describes && words.any { it in setOf("imagem", "foto", "isso", "isto", "aqui") })
    }

    private companion object {
        val SLEEP = Regex(
            "^(pode |vai |vamos )?(descansar|descansa|dormir|desativar|desativa|tchau|ate logo|ate mais|modo escola)( agora| um pouco)?$"
        )
        val OPEN_WORDS = setOf("abrir", "abre", "abra")
        val READ_VERBS = setOf("leia", "le", "ler", "leio")
        val DESCRIBE_WORDS = setOf("descreva", "descrever", "descreve")
        val READ_OBJECTS = setOf("texto", "escrito", "papel", "placa", "imagem", "foto", "isso", "isto", "aqui", "rotulo", "embalagem")

        // chave enviada à TV → como a Lia fala
        val APPS = listOf(
            "youtube" to "o YouTube",
            "netflix" to "a Netflix",
            "prime" to "o Prime Video"
        )
    }
}
