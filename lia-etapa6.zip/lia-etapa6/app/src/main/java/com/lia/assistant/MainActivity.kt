package com.lia.assistant

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.lia.assistant.ai.AiClient
import com.lia.assistant.ai.AiResult
import com.lia.assistant.ai.AiSettings
import com.lia.assistant.net.LiaState
import com.lia.assistant.ui.OrbView
import com.lia.assistant.util.ImageUtil
import java.io.File

/**
 * Tela principal da Lia. Ela NÃO fecha sozinha: mostra o estado, permite testar, ler textos e imagens
 * e mostra qualquer erro. O trabalho de verdade continua no LiaService (segundo plano).
 * Visual montado em código (sem XML e sem bibliotecas), para ficar leve.
 */
class MainActivity : ComponentActivity() {

    private val bg = 0xFF06070C.toInt()
    private val panel = 0xFF10121B.toInt()
    private val line = 0xFF252A3D.toInt()
    private val ink = 0xFFE9EBF7.toInt()
    private val muted = 0xFF8B90A8.toInt()
    private val danger = 0xFFFF8A80.toInt()

    private lateinit var orb: OrbView
    private lateinit var stateView: TextView
    private lateinit var lastView: TextView
    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var crashCard: LinearLayout
    private lateinit var crashView: TextView
    private lateinit var micBtn: Button
    private lateinit var pauseBtn: Button
    private lateinit var input: EditText
    private lateinit var aiKeyInput: EditText
    private lateinit var aiInfo: TextView
    private lateinit var modelBtn: Button
    private lateinit var readInput: EditText
    private lateinit var keepAwakeBtn: Button
    private lateinit var beepBtn: Button
    private lateinit var imageModeBtn: Button
    private lateinit var wakeHelpBtn: Button

    private var photoUri: Uri? = null
    private var imageDescribe = false

    private val onStatus: () -> Unit = { refresh() }

    private val askPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val micDenied = result.isNotEmpty() && result[Manifest.permission.RECORD_AUDIO] == false
            if (micDenied && !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                toast("Libere o microfone nas configurações do app.")
                openAppSettings()
            }
            ensureService()
            refresh()
        }

    private val takePhoto =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) photoUri?.let { handleImage(it) }
        }

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) handleImage(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        requestMissingPermissionsOrStart()
        handleLaunchIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleLaunchIntent(intent)
    }

    /** Vindo do atalho da notificação ("Toque para abrir a câmera da Lia"). */
    private fun handleLaunchIntent(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_OPEN_CAMERA, false) == true) {
            i.removeExtra(EXTRA_OPEN_CAMERA)
            launchCamera(i.getBooleanExtra(EXTRA_DESCRIBE, false))
        }
    }

    override fun onStart() {
        super.onStart()
        LiaStatus.activityVisible = true
        LiaStatus.cameraRequester = { describe -> launchCamera(describe) }
        LiaStatus.add(onStatus)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (micGranted() && !LiaService.running) ensureService()
        refresh()
    }

    override fun onStop() {
        LiaStatus.activityVisible = false
        LiaStatus.cameraRequester = null
        LiaStatus.remove(onStatus)
        super.onStop()
    }

    // ---------- permissões e serviço ----------

    private fun micGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun notifGranted() = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun requestMissingPermissionsOrStart() {
        val missing = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT >= 37) add("android.permission.ACCESS_LOCAL_NETWORK")
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }

        if (missing.isEmpty()) ensureService() else askPermissions.launch(missing.toTypedArray())
    }

    private fun ensureService() {
        if (!micGranted()) return
        sendToService(null, null)
    }

    private fun sendToService(action: String?, text: String?, flag: Boolean = false) {
        if (!micGranted()) { toast("Libere o microfone primeiro."); return }
        try {
            val i = Intent(this, LiaService::class.java)
            if (action != null) i.action = action
            if (text != null) i.putExtra(LiaService.EXTRA_TEXT, text)
            if (flag) i.putExtra(LiaService.EXTRA_FLAG, true)
            ContextCompat.startForegroundService(this, i)
        } catch (e: Throwable) {
            LiaLog.e("Lia", "Não consegui iniciar o serviço: ${e.message}")
            toast("Não consegui iniciar a Lia. Veja o registro abaixo.")
        }
        refresh()
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun batteryOk(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    private fun requestBattery() {
        try {
            if (!batteryOk()) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } else {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        } catch (e: Exception) {
            openAppSettings()
        }
    }

    private fun requestOverlay() {
        runCatching {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }.onFailure { openAppSettings() }
    }

    // ---------- câmera e imagens ----------

    /** Abre a câmera do sistema. Devolve true se abriu. Também é chamado pela voz ("Lia, leia o que está escrito"). */
    private fun launchCamera(describe: Boolean): Boolean {
        imageDescribe = describe
        return try {
            val dir = File(cacheDir, "images").apply { mkdirs() }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", File(dir, "lia_foto.jpg"))
            photoUri = uri
            takePhoto.launch(uri)
            refresh()
            true
        } catch (e: Throwable) {
            LiaLog.e("Lia", "Não consegui abrir a câmera: ${e.message}")
            toast("Não consegui abrir a câmera.")
            false
        }
    }

    private fun handleImage(uri: Uri) {
        val describe = imageDescribe
        toast(if (describe) "Olhando a imagem…" else "Lendo a imagem…")
        Thread {
            val b64 = ImageUtil.toBase64Jpeg(contentResolver, uri)
            runOnUiThread {
                if (b64 == null) {
                    toast("Não consegui abrir essa imagem.")
                } else {
                    LiaStatus.pendingImage = b64
                    sendToService(LiaService.ACTION_READ_IMAGE, null, describe)
                }
            }
        }.start()
    }

    // ---------- tela ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, stroke: Int = line) = GradientDrawable().apply {
        setColor(fill)
        setStroke(dp(1), stroke)
        cornerRadius = dp(14).toFloat()
    }

    private fun text(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(ink)
        background = rounded(panel)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setOnClickListener { onClick() }
    }

    private fun field(hintText: String, multiline: Boolean = false) = EditText(this).apply {
        hint = hintText
        setHintTextColor(muted)
        setTextColor(ink)
        textSize = 15f
        background = rounded(bg)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        if (multiline) {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            maxLines = 7
            gravity = Gravity.TOP
        } else {
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
    }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEachIndexed { i, v ->
            addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) marginStart = dp(8)
            })
        }
    }

    private fun card(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(panel)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        views.forEach { addView(it) }
    }

    private fun gap(h: Int = 12) = View(this).apply { minimumHeight = dp(h) }

    private fun buildUi(): View {
        val version = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull() ?: ""

        orb = OrbView(this)
        stateView = text(16f, ink, bold = true).apply { gravity = Gravity.CENTER }
        lastView = text(15f, muted).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(4), dp(8), 0) }

        micBtn = button("Permitir microfone") { requestMissingPermissionsOrStart() }
        pauseBtn = button("Descansar") {
            sendToService(if (LiaPrefs.isPaused(this)) LiaService.ACTION_RESUME else LiaService.ACTION_PAUSE, null)
        }
        val listenBtn = button("Ouvir agora") { sendToService(LiaService.ACTION_SIMULATE_WAKE, null) }
        val stopBtn = button("Parar a Lia") {
            stopService(Intent(this, LiaService::class.java))   // parar não pode usar startForegroundService
            refresh()
        }
        val batteryBtn = button("Bateria: sem restrições") { requestBattery() }
        val overlayBtn = button("Exibir sobre outros apps") { requestOverlay() }
        wakeHelpBtn = button("Configurar a palavra “Lia”") {
            runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://console.picovoice.ai/"))) }
        }

        // ----- digitar um comando (exige o nome "Lia") -----
        input = field("Digite: Lia, que horas são").apply {
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, _, _ -> sendTyped(); true }
        }
        val sendBtn = button("Enviar") { sendTyped() }
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(sendBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
        }

        statusView = text(14f, ink).apply { setLineSpacing(0f, 1.25f) }
        logView = text(12f, muted).apply { typeface = Typeface.MONOSPACE }
        val copyLog = button("Copiar registro") { copy(LiaLog.snapshot().reversed().joinToString("\n")) }

        // ----- ajustes de escuta -----
        keepAwakeBtn = button("") {
            LiaPrefs.setKeepAwake(this, !LiaPrefs.keepAwake(this))
            sendToService(LiaService.ACTION_REFRESH, null)
        }
        beepBtn = button("") {
            LiaPrefs.setBeepOnListen(this, !LiaPrefs.beepOnListen(this))
            refresh()
        }

        // ----- ler e descrever -----
        readInput = field("Cole ou digite um texto para a Lia ler em voz alta", multiline = true)
        val pasteBtn = button("Colar") {
            val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val pasted = clip.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
            if (pasted.isBlank()) toast("Nada copiado.") else readInput.setText(pasted)
        }
        val readBtn = button("Ler em voz alta") {
            val t = readInput.text.toString().trim()
            if (t.isEmpty()) toast("Digite ou cole um texto.") else sendToService(LiaService.ACTION_READ_TEXT, t, false)
        }
        val summaryBtn = button("Resumir e ler") {
            val t = readInput.text.toString().trim()
            if (t.isEmpty()) toast("Digite ou cole um texto.") else sendToService(LiaService.ACTION_READ_TEXT, t, true)
        }
        val calarBtn = button("Calar") { sendToService(LiaService.ACTION_STOP_SPEECH, null) }
        val cameraBtn = button("Câmera") { launchCamera(imageDescribe) }
        val galleryBtn = button("Imagem da galeria") { pickImage.launch("image/*") }
        imageModeBtn = button("") { imageDescribe = !imageDescribe; refresh() }

        // ----- IA -----
        aiInfo = text(13f, muted).apply { setLineSpacing(0f, 1.2f) }
        aiKeyInput = field("Cole aqui a chave do Google (AQ… ou AIza…)").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val saveKey = button("Salvar chave") {
            val k = aiKeyInput.text.toString().trim()
            if (k.isEmpty()) {
                toast("Cole a chave primeiro.")
            } else {
                AiSettings(this).apiKey = k
                aiKeyInput.text.clear()
                toast("Chave salva neste aparelho.")
                refresh()
            }
        }
        val removeKey = button("Apagar chave") { AiSettings(this).clearKey(); toast("Chave apagada."); refresh() }
        modelBtn = button("") { AiSettings(this).cycleModel(); refresh() }
        val testBtn = button("Testar a IA") { testAi() }

        crashView = text(12f, ink).apply { typeface = Typeface.MONOSPACE }
        val copyCrash = button("Copiar erro") { CrashLog.read(this)?.let { copy(it) } }
        val clearCrash = button("Apagar") { CrashLog.clear(this); refresh() }
        crashCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, danger)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            addView(text(15f, danger, bold = true).apply { text = "O app fechou por erro na última vez" })
            addView(text(13f, muted).apply { text = "Copie e envie este texto para corrigirmos:" })
            addView(crashView)
            addView(gap(8))
            addView(row(copyCrash, clearCrash))
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
            addView(text(24f, ink, bold = true).apply { text = "Lia" })
            addView(text(13f, muted).apply { text = "assistente de voz  ·  versão $version" })
            addView(gap(8))
            addView(crashCard)
            addView(orb, LinearLayout.LayoutParams(dp(150), dp(150)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dp(20); bottomMargin = dp(20)
            })
            addView(stateView)
            addView(lastView)
            addView(gap(16))
            addView(row(listenBtn, pauseBtn))
            addView(gap(8))
            addView(micBtn)
            addView(gap(8))
            addView(inputRow)
            addView(gap(16))
            addView(card(
                text(15f, ink, bold = true).apply { text = "Situação" }, gap(6), statusView, gap(10),
                row(batteryBtn, overlayBtn), gap(8), wakeHelpBtn, gap(8), stopBtn
            ))
            addView(gap(12))
            addView(card(
                text(15f, ink, bold = true).apply { text = "Escuta" }, gap(8),
                keepAwakeBtn, gap(8), beepBtn
            ))
            addView(gap(12))
            addView(card(
                text(15f, ink, bold = true).apply { text = "Ler e descrever" }, gap(6),
                text(13f, muted).apply { text = "Texto: a Lia lê em voz alta. Câmera ou imagem: a IA lê o texto da foto (ou descreve)." },
                gap(8), readInput, gap(8), row(pasteBtn, calarBtn), gap(8), row(readBtn, summaryBtn),
                gap(8), row(cameraBtn, galleryBtn), gap(8), imageModeBtn
            ))
            addView(gap(12))
            addView(card(
                text(15f, ink, bold = true).apply { text = "Inteligência artificial (Google Gemini)" },
                gap(4), aiInfo, gap(8), aiKeyInput, gap(8),
                row(saveKey, removeKey), gap(8), row(modelBtn, testBtn)
            ))
            addView(gap(12))
            addView(card(text(15f, ink, bold = true).apply { text = "Registro" }, gap(6), logView, gap(10), copyLog))
        }

        return ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
            clipToPadding = false
            addView(content)
            // A tela desenha atrás das barras do sistema (Android 15+): empurra o conteúdo para dentro.
            ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
                val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
                val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
                v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
                insets
            }
        }
    }

    /** Texto digitado: sem o nome "Lia", nada acontece (e a IA não é chamada). */
    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        if (!NameGate.has(t)) {
            LiaLog.d("Lia", "Ignorado (sem “Lia”): $t")
            toast("Sem o nome “Lia”, ela não faz nada. Escreva, por exemplo: Lia, que horas são")
            return
        }
        input.text.clear()
        if (LiaPrefs.isPaused(this)) toast("A Lia está descansando. Toque em Acordar.")
        sendToService(LiaService.ACTION_COMMAND, t)
    }

    private fun refresh() {
        if (!::orb.isInitialized) return
        val running = LiaService.running
        val paused = LiaPrefs.isPaused(this)
        val active = running && !paused

        orb.state = if (active) LiaStatus.state else LiaState.IDLE
        orb.alpha = if (active) 1f else 0.35f

        stateView.text = when {
            !running -> "Parada"
            paused -> "Descansando (microfone desligado)"
            else -> when (LiaStatus.state) {
                LiaState.IDLE -> "Em espera"
                LiaState.LISTENING -> "Ouvindo…"
                LiaState.RESPONDING -> if (LiaStatus.reading) "Lendo…" else "Respondendo…"
            }
        }
        lastView.text = LiaStatus.text.ifBlank { "Diga “Lia” e um pedido, toque em “Ouvir agora” ou digite um comando com “Lia”." }
        pauseBtn.text = if (paused) "Acordar" else "Descansar"
        micBtn.visibility = if (micGranted()) View.GONE else View.VISIBLE
        wakeHelpBtn.visibility = if (LiaStatus.wakeInfo.contains("ativa")) View.GONE else View.VISIBLE

        keepAwakeBtn.text = "Escuta com a tela apagada: " + if (LiaPrefs.keepAwake(this)) "ligada" else "desligada"
        beepBtn.text = "Som ao começar a ouvir: " + if (LiaPrefs.beepOnListen(this)) "ligado" else "desligado"
        imageModeBtn.text = "Câmera e imagem: " + if (imageDescribe) "descrever a imagem" else "ler o texto da imagem"

        statusView.text = listOf(
            "Microfone: " + if (micGranted()) "permitido ✔" else "NÃO permitido ✘",
            "Notificações: " + if (notifGranted()) "permitidas ✔" else "não permitidas (a Lia funciona, mas não mostra o aviso)",
            "Serviço: " + if (running) "rodando ✔" else "parado ✘",
            LiaStatus.wakeInfo,
            "Bateria: " + if (batteryOk()) "sem restrições ✔" else "com restrições ✘ (o Android pode parar a Lia com a tela apagada)",
            "Alarmes com a tela apagada: " + if (Settings.canDrawOverlays(this)) "liberado ✔" else "não liberado (a Lia deixa um aviso para você tocar)",
            LiaStatus.tvInfo,
            aiStatusLine()
        ).joinToString("\n")

        val ai = AiSettings(this)
        modelBtn.text = if (ai.model.isBlank()) "Modelo: automático" else "Modelo: ${ai.model}"
        aiInfo.text = if (ai.apiKey.isBlank())
            "Sem chave. Crie uma grátis em aistudio.google.com/apikey, cole acima e toque em Salvar. A chave fica só neste aparelho."
        else
            "Chave salva (${ai.masked()}). " +
                (if (ai.lastGood.isNotBlank() && ai.model.isBlank()) "Último modelo rápido: ${ai.lastGood}. " else "") +
                "Perguntas simples usam o modelo mais rápido; as avançadas e as imagens, um modelo mais capaz."

        logView.text = LiaLog.snapshot().takeLast(30).reversed().joinToString("\n").ifEmpty { "Sem mensagens ainda." }

        val crash = CrashLog.read(this)
        crashCard.visibility = if (crash != null) View.VISIBLE else View.GONE
        crashView.text = crash?.take(1800) ?: ""
    }

    private fun aiStatusLine(): String {
        val ai = AiSettings(this)
        return "IA: " + if (ai.apiKey.isBlank()) "sem chave ✘ (cadastre abaixo)" else "pronta ✔"
    }

    /** Faz uma pergunta curta à IA, fora da thread principal, e mostra o resultado e o registro. */
    private fun testAi() {
        val ai = AiSettings(this)
        if (ai.apiKey.isBlank()) { toast("Cadastre a chave primeiro."); return }
        toast("Testando a IA…")
        Thread {
            val r = AiClient().ask(
                ai.apiKey, ai.modelsToTry(), emptyList(),
                "Diga olá em uma frase curta e diga que está funcionando.", {}, { ai.lastGood = it }
            )
            val msg = when (r) {
                is AiResult.Ok -> "IA respondeu (${ai.lastGood}): ${r.text}"
                is AiResult.Fail -> "IA falhou: ${r.detail}"
            }
            LiaLog.d("Lia", msg)
            runOnUiThread {
                LiaStatus.set(LiaStatus.state, msg)
                toast(if (r is AiResult.Ok) "A IA está funcionando ✔" else "A IA falhou. Veja o registro.")
            }
        }.start()
    }

    private fun copy(text: String) {
        getSystemService(Context.CLIPBOARD_SERVICE).let { it as ClipboardManager }
            .setPrimaryClip(ClipData.newPlainText("Lia", text))
        toast("Copiado.")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        const val EXTRA_OPEN_CAMERA = "open_camera"
        const val EXTRA_DESCRIBE = "describe"
    }
}
