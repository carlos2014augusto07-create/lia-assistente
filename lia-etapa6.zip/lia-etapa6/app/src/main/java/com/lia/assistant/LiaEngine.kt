package com.lia.assistant

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import com.lia.assistant.LiaLog as Log
import com.lia.assistant.ai.AiAssistant
import com.lia.assistant.ai.AiResult
import com.lia.assistant.alarm.AlarmLauncher
import com.lia.assistant.esp.Esp32Manager
import com.lia.assistant.net.ESP_SERVICE_TYPE
import com.lia.assistant.net.Esp32Link
import com.lia.assistant.net.LanDiscovery
import com.lia.assistant.net.LiaState
import com.lia.assistant.net.TV_SERVICE_TYPE
import com.lia.assistant.net.TvSocketLink
import com.lia.assistant.tv.TvManager
import com.lia.assistant.util.ActionNotifier
import com.lia.assistant.voice.CommandListener
import com.lia.assistant.voice.Speaker
import com.lia.assistant.wake.WakeWordEngine
import com.lia.assistant.wake.WakeWordFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val TAG = "Lia"
private const val SESSION_TIMEOUT_MS = 25_000L        // escutar a frase
private const val RESPONSE_TIMEOUT_MS = 90_000L       // pensar (IA) + falar a resposta
private const val READ_TIMEOUT_MS = 20 * 60_000L      // ler um texto longo em voz alta
private const val MAX_READ_CHARS = 30_000

/** Avisos falados na hora em que a pergunta é entendida (revezam para não ficar repetitivo). */
private val ACKS = listOf("Só um segundo.", "Deixa eu ver.", "Já te respondo.", "Um instante.")

/**
 * Fluxo de uma interação:
 *   "Lia" (palavra de ativação) → notificação "Lia está escutando…" → escuta a frase (fecha após 1,5 s de silêncio)
 *   → decide → fala (a IA em streaming) → volta a escutar "Lia".
 *
 * Regra do nome: por VOZ, a palavra de ativação (ou o botão "Ouvir agora") garante que a Lia foi chamada;
 * por TEXTO digitado, [runText] só age se a frase tiver "Lia". Sem o nome, não faz nada e não chama a IA.
 *
 * Modo escola / pausa: pause() desliga o microfone e esconde a Lia da TV na hora.
 * Tudo que mexe em microfone roda na thread principal; a rede roda numa fila única,
 * para as mensagens chegarem à TV na ordem certa.
 */
class LiaEngine(
    private val ctx: Context,
    private val onPausedChanged: (Boolean) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default.limitedParallelism(1))
    private val discovery = LanDiscovery(ctx)

    private val ai = AiAssistant(ctx)
    private var ackIndex = 0
    private lateinit var tv: TvManager
    private lateinit var router: CommandRouter
    private val listener = CommandListener(ctx)
    private val speaker = Speaker(ctx)
    private var wake: WakeWordEngine? = null
    private var busy = false

    @Volatile var paused: Boolean = LiaPrefs.isPaused(ctx)
        private set

    private val watchdog = Runnable {
        Log.w(TAG, "Interação demorou demais: reiniciando a escuta")
        speaker.stop()
        end()
    }

    init {
        val tvLink = TvSocketLink(
            findHost = { force -> discovery.find(TV_SERVICE_TYPE, BuildConfig.LIA_TV_HOST, "tv", force) },
            token = BuildConfig.LIA_TOKEN
        ) { event -> tv.onEvent(event) }
        tv = TvManager(ctx, tvLink)

        val espLink = Esp32Link(
            findHost = { force -> discovery.find(ESP_SERVICE_TYPE, BuildConfig.LIA_ESP_HOST, "esp", force) },
            token = BuildConfig.LIA_TOKEN
        )
        router = CommandRouter(tv, Esp32Manager(ctx, espLink))
    }

    /** Thread principal. */
    fun start() {
        if (wake == null) wake = WakeWordFactory.create(ctx) { onWake() }
        if (paused) Log.d(TAG, "Iniciada em descanso: microfone desligado") else wake?.start()
    }

    // ----- entradas -----

    /** A palavra "Lia" foi dita (Porcupine, de qualquer thread) ou o botão "Ouvir agora" foi tocado. */
    fun onWake() { main.post { if (!busy && !paused) begin(null) } }

    /** Texto digitado (ou enviado por adb): só vale se tiver o nome "Lia". */
    fun runText(raw: String) {
        main.post {
            if (paused) return@post
            if (!NameGate.has(raw)) {
                Log.d(TAG, "Ignorado (sem “Lia”): $raw")
                return@post
            }
            if (busy) return@post
            val command = NameGate.strip(raw)
            if (command.isBlank()) begin(null) else begin(command)   // só "Lia": começa a ouvir
        }
    }

    // ----- ler textos e imagens em voz alta -----

    /** Lê um texto em voz alta (ou, com [summarize], resume com a IA e lê o resumo). */
    fun readAloud(text: String, summarize: Boolean) {
        main.post {
            if (paused || busy || text.isBlank()) return@post
            beginReading(if (summarize) "Resumindo o texto…" else "Lendo o texto…")
            if (summarize) {
                scope.launch {
                    if (ai.isConfigured()) speaker.speakAck("Já vou resumir.")
                    streamAnswer { cb -> ai.summarize(text, cb) }
                }
            } else {
                speaker.startStream { end() }
                splitForReading(text).forEach { speaker.streamSentence(it) }
                speaker.endStream()
            }
        }
    }

    /** Lê (ou descreve) a imagem que a tela principal deixou em [LiaStatus.pendingImage]. */
    fun readImage(describe: Boolean) {
        main.post {
            val img = LiaStatus.pendingImage
            if (img == null || paused || busy) return@post
            LiaStatus.pendingImage = null
            beginReading(if (describe) "Olhando a imagem…" else "Lendo a imagem…")
            scope.launch {
                if (ai.isConfigured()) speaker.speakAck(if (describe) "Já vou olhar." else "Já vou ler.")
                streamAnswer { cb -> ai.readImage(img, describe, cb) }
            }
        }
    }

    /** Corta a fala na hora (botão "Calar"). */
    fun stopSpeaking() {
        main.post {
            if (!busy) return@post
            speaker.stop()
            end()
        }
    }

    // ----- modo escola / pausa -----

    fun pause() { main.post { doPause(null) } }
    fun resume() { main.post { doResume() } }
    fun togglePause() { main.post { if (paused) doResume() else doPause(null) } }

    /** Thread principal. [goodbye] = frase falada depois de já ter calado o microfone. */
    private fun doPause(goodbye: String?) {
        if (paused && goodbye == null) return
        paused = true
        LiaPrefs.setPaused(ctx, true)
        main.removeCallbacks(watchdog)
        busy = false
        LiaStatus.reading = false
        listener.cancel()
        wake?.stop()                                // solta o microfone na hora
        scope.launch { tv.sleep() }                 // some a bolinha da TV na hora
        if (goodbye != null) speaker.speak(goodbye) {} else speaker.stop()
        LiaStatus.set(LiaState.IDLE, "")
        onPausedChanged(true)
    }

    private fun doResume() {
        if (!paused) return
        paused = false
        LiaPrefs.setPaused(ctx, false)
        busy = false
        scope.launch { tv.wake() }                  // a TV mostra só a bolinha discreta
        wake?.start()
        LiaStatus.set(LiaState.IDLE, "")
        onPausedChanged(false)
    }

    fun stop() {
        main.removeCallbacks(watchdog)
        wake?.release()
        wake = null
        listener.cancel()
        speaker.shutdown()
        tv.close()
        scope.cancel()
        LiaStatus.reading = false
    }

    // ----- sessão (thread principal) -----

    private fun rearmWatchdog(ms: Long) {
        main.removeCallbacks(watchdog)
        main.postDelayed(watchdog, ms)
    }

    private fun begin(preset: String?) {
        busy = true
        // O estado muda ANTES de qualquer outra coisa: é isso que atualiza a notificação para "Lia está escutando…".
        LiaStatus.set(LiaState.LISTENING, "")
        rearmWatchdog(SESSION_TIMEOUT_MS)
        wake?.stop()                                // libera o microfone
        scope.launch { tv.show(LiaState.LISTENING) }
        scope.launch { ai.warmUp() }                // aquece a conexão da IA enquanto você ainda está falando

        if (preset != null) {
            scope.launch { respond(preset) }
            return
        }
        // pequena folga para o microfone ser liberado de verdade antes do reconhecimento
        main.postDelayed({
            if (!paused) listener.listen(
                onText = { text -> scope.launch { respond(text) } },
                onFail = { silent ->
                    scope.launch {
                        if (silent) end() else reply("Não entendi. Pode repetir?")   // ninguém falou: encerra sem reclamar
                    }
                }
            )
        }, 200)
    }

    private suspend fun respond(raw: String) {
        val text = NameGate.strip(raw)              // se a pessoa repetir "Lia, ..." tira o chamado
        if (text.isBlank()) { end(); return }

        main.post { rearmWatchdog(RESPONSE_TIMEOUT_MS) }   // ouviu a frase: vale o prazo maior (a IA pode demorar)
        LiaStatus.set(LiaState.LISTENING, "“$text”")
        tv.show(LiaState.LISTENING, "“$text”")

        val r = router.handle(text)
        when {
            r.sleep -> main.post { doPause(r.text) }
            r.askAi -> askAi(r.text)
            r.alarm != null -> {
                val spoken = withContext(Dispatchers.Main) { AlarmLauncher.create(ctx, r.alarm) }
                reply(spoken)
            }
            r.camera -> openCamera(r.describe)
            else -> reply(r.text)
        }
    }

    private suspend fun reply(text: String) {
        if (paused) return
        LiaStatus.set(LiaState.RESPONDING, text)
        tv.show(LiaState.RESPONDING, text)
        speaker.speak(text) { end() }
    }

    /** "Lia, leia o que está escrito aqui": abre a câmera se a tela da Lia estiver visível; senão deixa um atalho. */
    private suspend fun openCamera(describe: Boolean) {
        val opened = withContext(Dispatchers.Main) { LiaStatus.cameraRequester?.invoke(describe) == true }
        if (opened) {
            reply("Abrindo a câmera. Aponte para o texto e tire a foto.")
        } else {
            val open = Intent(ctx, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_OPEN_CAMERA, true)
                .putExtra(MainActivity.EXTRA_DESCRIBE, describe)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pi = PendingIntent.getActivity(ctx, 2002, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            ActionNotifier.post(ctx, 2002, "Toque para abrir a câmera da Lia.", pi)
            reply("O Android só deixa eu abrir a câmera com a minha tela aberta. Deixei um atalho na notificação.")
        }
    }

    /**
     * Pergunta para a IA sem deixar a pessoa no vazio:
     *  1) na hora: "Só um segundo." por voz e "Pensando…" na tela e na TV;
     *  2) a resposta chega em streaming e cada frase pronta já é falada;
     *  3) se a internet não responder em 10 s, a Lia avisa em vez de ficar parada.
     */
    private suspend fun askAi(question: String) {
        LiaStatus.set(LiaState.RESPONDING, "Pensando…")
        tv.show(LiaState.RESPONDING, "Pensando…")
        if (ai.isConfigured()) speaker.speakAck(ACKS[ackIndex++ % ACKS.size])
        streamAnswer { cb -> ai.answer(question, cb) }
    }

    /** Fala cada frase da IA assim que ela chega e mostra o texto na tela e na TV. */
    private suspend fun streamAnswer(call: suspend ((String) -> Unit) -> AiResult) {
        speaker.startStream { end() }
        var shown = ""
        val result = call { sentence ->
            speaker.streamSentence(sentence)
            shown = if (shown.isEmpty()) sentence else "$shown $sentence"
            val snapshot = shown
            LiaStatus.set(LiaState.RESPONDING, snapshot)
            scope.launch { tv.show(LiaState.RESPONDING, snapshot) }
        }
        when (result) {
            is AiResult.Ok -> speaker.endStream()
            is AiResult.Fail -> {
                speaker.streamSentence(result.spoken)
                LiaStatus.set(LiaState.RESPONDING, result.spoken)
                tv.show(LiaState.RESPONDING, result.spoken)
                speaker.endStream()
            }
        }
    }

    private fun beginReading(message: String) {
        busy = true
        LiaStatus.reading = true
        rearmWatchdog(READ_TIMEOUT_MS)
        wake?.stop()                                // não escutar a própria leitura
        LiaStatus.set(LiaState.RESPONDING, message)
        scope.launch { tv.show(LiaState.RESPONDING, message) }
    }

    /** Parágrafos viram pausas; frases muito longas são quebradas em vírgulas para a voz respirar. */
    private fun splitForReading(raw: String): List<String> {
        val truncated = raw.length > MAX_READ_CHARS
        val text = raw.take(MAX_READ_CHARS)
            .replace(Regex("\\r?\\n\\s*\\r?\\n"), ". ")
            .replace(Regex("\\s+"), " ")
            .trim()
        val out = ArrayList<String>()
        for (sentence in text.split(Regex("(?<=[.!?…])\\s+"))) {
            var s = sentence.trim()
            while (s.length > 300) {
                val cut = s.lastIndexOfAny(charArrayOf(',', ';', ':'), 300).let { if (it < 40) s.lastIndexOf(' ', 300) else it }
                val at = if (cut < 40) 300 else cut + 1
                out.add(s.substring(0, at).trim())
                s = s.substring(at).trim()
            }
            if (s.isNotEmpty()) out.add(s)
        }
        if (truncated) out.add("O texto era muito longo, li só o começo.")
        return out
    }

    private fun end() {
        main.removeCallbacks(watchdog)
        LiaStatus.reading = false
        if (paused) return
        LiaStatus.set(LiaState.IDLE, "")            // a notificação volta ao normal
        // O IDLE inicia, na TV, a contagem de 50 s de inatividade.
        scope.launch { tv.show(LiaState.IDLE) }
        main.post {
            listener.cancel()
            busy = false
            if (!paused) wake?.start()
        }
    }
}
