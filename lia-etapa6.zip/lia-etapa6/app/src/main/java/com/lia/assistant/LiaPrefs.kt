package com.lia.assistant

import android.content.Context

/** Guarda escolhas que precisam sobreviver a reinícios do serviço. */
object LiaPrefs {
    private fun prefs(c: Context) = c.getSharedPreferences("lia_state", Context.MODE_PRIVATE)

    fun isPaused(c: Context): Boolean = prefs(c).getBoolean("paused", false)
    fun setPaused(c: Context, v: Boolean) = prefs(c).edit().putBoolean("paused", v).apply()

    /** Mantém o processador acordado com a tela apagada (gasta mais bateria, mas a escuta fica estável). */
    fun keepAwake(c: Context): Boolean = prefs(c).getBoolean("keep_awake", true)
    fun setKeepAwake(c: Context, v: Boolean) = prefs(c).edit().putBoolean("keep_awake", v).apply()

    /** Toque curtinho quando a Lia começa a ouvir (ajuda a saber a hora de falar com a tela apagada). */
    fun beepOnListen(c: Context): Boolean = prefs(c).getBoolean("beep", true)
    fun setBeepOnListen(c: Context, v: Boolean) = prefs(c).edit().putBoolean("beep", v).apply()
}
