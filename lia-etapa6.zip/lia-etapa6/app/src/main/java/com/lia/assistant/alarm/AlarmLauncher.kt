package com.lia.assistant.alarm

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.lia.assistant.LiaLog
import com.lia.assistant.LiaStatus
import com.lia.assistant.util.ActionNotifier

/**
 * Cria o alarme/temporizador no app de Relógio do Android (o mesmo que você abre no celular).
 *
 * O Android só deixa um app abrir outra tela quando ele está visível. Por isso:
 *  1) tela da Lia aberta → abre o Relógio direto;
 *  2) tela apagada ou outro app na frente → se "Exibir sobre outros apps" estiver liberado, a Lia usa uma janela
 *     invisível de 1 pixel para ganhar essa permissão (funciona no Android 10 em diante; não consegui testar em aparelho);
 *  3) sem nenhuma das duas → deixa um aviso na notificação para você tocar uma vez.
 * Rode na thread principal. Devolve a frase que a Lia fala.
 */
object AlarmLauncher {

    fun create(ctx: Context, cmd: AlarmCommand): String {
        val intent = when (cmd) {
            is AlarmCommand.Alarm -> Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, cmd.hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, cmd.minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Lia")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            is AlarmCommand.Timer -> Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, cmd.seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Lia")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            AlarmCommand.NeedTime ->
                return "Para criar o alarme, diga o horário. Por exemplo: alarme para as sete e meia, ou daqui a vinte minutos."
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        val what = when (cmd) {
            is AlarmCommand.Alarm -> "o alarme ${cmd.spoken}"
            is AlarmCommand.Timer -> "o temporizador de ${cmd.spoken}"
            AlarmCommand.NeedTime -> ""
        }
        val done = when (cmd) {
            is AlarmCommand.Alarm -> "Pronto, alarme ${cmd.spoken}, no relógio."
            is AlarmCommand.Timer -> "Pronto, temporizador de ${cmd.spoken} no relógio."
            AlarmCommand.NeedTime -> ""
        }

        if (intent.resolveActivity(ctx.packageManager) == null) {
            return "Não encontrei um app de relógio neste celular para criar $what."
        }

        val visible = LiaStatus.activityVisible
        val canOverlay = Settings.canDrawOverlays(ctx)
        if (!visible && !canOverlay) return needsTap(ctx, intent, what)

        val guard = if (!visible) showTinyOverlay(ctx) else null
        return try {
            ctx.startActivity(intent)
            if (guard != null) {
                Handler(Looper.getMainLooper()).postDelayed({ removeOverlay(ctx, guard) }, 2500)
            }
            LiaLog.d("Lia", "Relógio acionado: $what")
            done
        } catch (e: Exception) {
            guard?.let { removeOverlay(ctx, it) }
            LiaLog.w("Lia", "Não consegui abrir o relógio: ${e.message}")
            needsTap(ctx, intent, what)
        }
    }

    private fun needsTap(ctx: Context, intent: Intent, what: String): String {
        val pi = PendingIntent.getActivity(ctx, intent.hashCode(), intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        ActionNotifier.post(ctx, 2001, "Toque para criar $what no relógio.", pi)
        return "Deixei $what na notificação. Toque nela para confirmar. Para eu criar sozinha, abra a tela da Lia ou libere exibir sobre outros apps."
    }

    private fun showTinyOverlay(ctx: Context): View? = runCatching {
        val wm = ctx.getSystemService(WindowManager::class.java)
        val v = View(ctx)
        val lp = WindowManager.LayoutParams(
            1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(v, lp)
        v
    }.getOrNull()

    private fun removeOverlay(ctx: Context, v: View) {
        runCatching { ctx.getSystemService(WindowManager::class.java).removeViewImmediate(v) }
    }
}
